"""
Repository para gerenciar transações.
"""

from typing import List, Optional
from database.manager import DatabaseManager
from database.models.transaction import TransactionModel
from utils.logger import setup_logger

logger = setup_logger(__name__)


class TransactionRepository:
    """Gerencia operações de transações financeiras."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    async def create_tables(self) -> None:
        """Cria a tabela de transações."""
        query = """
        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            discord_id INTEGER NOT NULL,
            server_id INTEGER NOT NULL,
            transaction_type TEXT NOT NULL,
            amount INTEGER NOT NULL,
            description TEXT NOT NULL,
            related_user_id INTEGER,
            created_at TEXT NOT NULL
        )
        """
        try:
            await self.db.execute(query)
            logger.info("✓ Tabela 'transactions' criada/verificada")
        except Exception as e:
            logger.error(f"Erro ao criar tabela de transações: {e}")
            raise

    async def add_transaction(self, transaction: TransactionModel) -> None:
        """Registra uma nova transação."""
        try:
            query = """
            INSERT INTO transactions (
                discord_id, server_id, transaction_type,
                amount, description, related_user_id, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """
            await self.db.execute(
                query,
                (
                    transaction.discord_id,
                    transaction.server_id,
                    transaction.transaction_type,
                    transaction.amount,
                    transaction.description,
                    transaction.related_user_id,
                    transaction.created_at,
                )
            )
            logger.info(f"✓ Transação registrada: {transaction.transaction_type}")
        except Exception as e:
            logger.error(f"Erro ao registrar transação: {e}")
            raise

    async def get_user_transactions(
        self,
        discord_id: int,
        server_id: int,
        limit: int = 50
    ) -> List[TransactionModel]:
        """Obtém o histórico de transações de um usuário."""
        try:
            query = """
            SELECT * FROM transactions
            WHERE discord_id = ? AND server_id = ?
            ORDER BY created_at DESC
            LIMIT ?
            """
            results = await self.db.fetch_all(query, (discord_id, server_id, limit))
            return [TransactionModel.from_dict(row) for row in results]
        except Exception as e:
            logger.error(f"Erro ao obter transações: {e}")
            raise

    async def get_total_earnings(
        self,
        discord_id: int,
        server_id: int
    ) -> int:
        """Obtém o total de ganhos de um usuário."""
        try:
            query = """
            SELECT COALESCE(SUM(amount), 0) as total FROM transactions
            WHERE discord_id = ? AND server_id = ?
            AND transaction_type IN ('salary', 'daily', 'transfer_received')
            """
            result = await self.db.fetch_one(query, (discord_id, server_id))
            return result["total"] if result else 0
        except Exception as e:
            logger.error(f"Erro ao calcular ganhos totais: {e}")
            raise
