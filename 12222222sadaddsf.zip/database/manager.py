"""
Gerenciador de banco de dados SQLite com async/await.
"""

import aiosqlite
from pathlib import Path
from typing import Any, List, Optional, Tuple
from utils.logger import setup_logger

logger = setup_logger(__name__)


class DatabaseManager:
    """Gerencia conexões e operações no banco de dados SQLite."""

    def __init__(self, database_path: Path):
        """
        Inicializa o gerenciador de banco de dados.

        Args:
            database_path: Caminho para o arquivo do banco de dados SQLite
        """
        self.database_path: Path = database_path
        self.connection: Optional[aiosqlite.Connection] = None

    async def connect(self) -> None:
        """Abre conexão com o banco de dados."""
        try:
            self.connection = await aiosqlite.connect(str(self.database_path))
            self.connection.row_factory = aiosqlite.Row
            logger.info(f"Conectado ao banco de dados: {self.database_path}")
        except Exception as e:
            logger.error(f"Erro ao conectar ao banco de dados: {e}")
            raise

    async def disconnect(self) -> None:
        """Fecha conexão com o banco de dados."""
        if self.connection:
            await self.connection.close()
            logger.info("Desconectado do banco de dados")

    async def execute(self, query: str, params: Tuple = ()) -> None:
        """
        Executa uma query sem retornar resultados.

        Args:
            query: String SQL
            params: Parâmetros para a query
        """
        if not self.connection:
            raise RuntimeError("Banco de dados não conectado")

        try:
            await self.connection.execute(query, params)
            await self.connection.commit()
        except Exception as e:
            logger.error(f"Erro ao executar query: {e}")
            raise

    async def fetch_one(self, query: str, params: Tuple = ()) -> Optional[dict]:
        """
        Executa uma query e retorna um resultado.

        Args:
            query: String SQL
            params: Parâmetros para a query

        Returns:
            Um dicionário com o resultado ou None
        """
        if not self.connection:
            raise RuntimeError("Banco de dados não conectado")

        try:
            cursor = await self.connection.execute(query, params)
            result = await cursor.fetchone()
            await cursor.close()
            return dict(result) if result else None
        except Exception as e:
            logger.error(f"Erro ao buscar um resultado: {e}")
            raise

    async def fetch_all(self, query: str, params: Tuple = ()) -> List[dict]:
        """
        Executa uma query e retorna todos os resultados.

        Args:
            query: String SQL
            params: Parâmetros para a query

        Returns:
            Lista de dicionários com os resultados
        """
        if not self.connection:
            raise RuntimeError("Banco de dados não conectado")

        try:
            cursor = await self.connection.execute(query, params)
            results = await cursor.fetchall()
            await cursor.close()
            return [dict(row) for row in results]
        except Exception as e:
            logger.error(f"Erro ao buscar múltiplos resultados: {e}")
            raise

    async def create_tables(self) -> None:
        """Cria as tabelas do banco de dados se não existirem."""
        if not self.connection:
            raise RuntimeError("Banco de dados não conectado")

        try:
            # As tabelas específicas serão criadas nos módulos respectivos
            logger.info("Tabelas do banco de dados prontas")
        except Exception as e:
            logger.error(f"Erro ao criar tabelas: {e}")
            raise

    async def execute_many(self, query: str, params_list: List[Tuple]) -> None:
        """
        Executa uma query múltiplas vezes com diferentes parâmetros.

        Args:
            query: String SQL
            params_list: Lista de tuplas com parâmetros
        """
        if not self.connection:
            raise RuntimeError("Banco de dados não conectado")

        try:
            await self.connection.executemany(query, params_list)
            await self.connection.commit()
        except Exception as e:
            logger.error(f"Erro ao executar múltiplas queries: {e}")
            raise
