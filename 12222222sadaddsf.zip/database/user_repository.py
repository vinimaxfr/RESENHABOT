"""
Repository para gerenciar usuários no banco de dados.
"""

from typing import Optional, List
from .manager import DatabaseManager
from .models.user import UserModel
from utils.logger import setup_logger
from datetime import datetime

logger = setup_logger(__name__)


class UserRepository:
    """Gerencia operações de usuários no banco de dados."""

    def __init__(self, db: DatabaseManager):
        """
        Inicializa o repository.

        Args:
            db: Gerenciador de banco de dados
        """
        self.db = db

    async def create_tables(self) -> None:
        """Cria a tabela de usuários se não existir."""
        create_table_query = """
        CREATE TABLE IF NOT EXISTS users (
            discord_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            money INTEGER DEFAULT 0,
            xp INTEGER DEFAULT 0,
            level INTEGER DEFAULT 1,
            commands_used INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            messages_count INTEGER DEFAULT 0,
            voice_calls INTEGER DEFAULT 0,
            minigames_wins INTEGER DEFAULT 0,
            palo_current INTEGER DEFAULT 0,
            palo_best INTEGER DEFAULT 0,
            palo_worst INTEGER DEFAULT 0,
            palo_last_measurement TEXT,
            updated_at TEXT NOT NULL
        )
        """
        try:
            await self.db.execute(create_table_query)
            logger.info("✓ Tabela 'users' criada/verificada")
        except Exception as e:
            logger.error(f"Erro ao criar tabela de usuários: {e}")
            raise

    async def create_user(self, discord_id: int, name: str) -> UserModel:
        """
        Cria um novo usuário no banco de dados.

        Args:
            discord_id: ID do usuário Discord
            name: Nome do usuário

        Returns:
            UserModel: Modelo do usuário criado
        """
        try:
            user = UserModel(
                discord_id=discord_id,
                name=name,
                created_at=datetime.now().isoformat(),
                updated_at=datetime.now().isoformat(),
            )

            query = """
            INSERT INTO users (
                discord_id, name, money, xp, level, commands_used,
                created_at, messages_count, voice_calls, minigames_wins,
                palo_current, palo_best, palo_worst, palo_last_measurement, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """

            await self.db.execute(
                query,
                (
                    user.discord_id,
                    user.name,
                    user.money,
                    user.xp,
                    user.level,
                    user.commands_used,
                    user.created_at,
                    user.messages_count,
                    user.voice_calls,
                    user.minigames_wins,
                    user.palo_current,
                    user.palo_best,
                    user.palo_worst,
                    user.palo_last_measurement,
                    user.updated_at,
                )
            )

            logger.info(f"✓ Usuário {discord_id} ({name}) criado")
            return user

        except Exception as e:
            logger.error(f"Erro ao criar usuário {discord_id}: {e}")
            raise

    async def get_user(self, discord_id: int) -> Optional[UserModel]:
        """
        Obtém um usuário pelo ID.

        Args:
            discord_id: ID do usuário Discord

        Returns:
            UserModel ou None se não encontrado
        """
        try:
            query = "SELECT * FROM users WHERE discord_id = ?"
            result = await self.db.fetch_one(query, (discord_id,))

            if result:
                return UserModel.from_dict(result)

            return None

        except Exception as e:
            logger.error(f"Erro ao buscar usuário {discord_id}: {e}")
            raise

    async def get_or_create_user(self, discord_id: int, name: str) -> UserModel:
        """
        Obtém um usuário ou cria um novo.

        Args:
            discord_id: ID do usuário Discord
            name: Nome do usuário

        Returns:
            UserModel: Usuário existente ou novo
        """
        user = await self.get_user(discord_id)

        if not user:
            user = await self.create_user(discord_id, name)

        return user

    async def update_user(self, user: UserModel) -> None:
        """
        Atualiza um usuário no banco de dados.

        Args:
            user: Modelo do usuário com dados atualizados
        """
        try:
            query = """
            UPDATE users SET
                name = ?,
                money = ?,
                xp = ?,
                level = ?,
                commands_used = ?,
                messages_count = ?,
                voice_calls = ?,
                minigames_wins = ?,
                palo_current = ?,
                palo_best = ?,
                palo_worst = ?,
                palo_last_measurement = ?,
                updated_at = ?
            WHERE discord_id = ?
            """

            await self.db.execute(
                query,
                (
                    user.name,
                    user.money,
                    user.xp,
                    user.level,
                    user.commands_used,
                    user.messages_count,
                    user.voice_calls,
                    user.minigames_wins,
                    user.palo_current,
                    user.palo_best,
                    user.palo_worst,
                    user.palo_last_measurement,
                    datetime.now().isoformat(),
                    user.discord_id,
                )
            )

            logger.info(f"✓ Usuário {user.discord_id} atualizado")

        except Exception as e:
            logger.error(f"Erro ao atualizar usuário {user.discord_id}: {e}")
            raise

    async def add_money(self, discord_id: int, amount: int) -> Optional[UserModel]:
        """
        Adiciona dinheiro a um usuário.

        Args:
            discord_id: ID do usuário
            amount: Quantidade a adicionar (pode ser negativa)

        Returns:
            UserModel atualizado ou None
        """
        try:
            user = await self.get_user(discord_id)
            if not user:
                return None

            user.money = max(0, user.money + amount)  # Não pode ser negativo
            await self.update_user(user)

            return user

        except Exception as e:
            logger.error(f"Erro ao adicionar dinheiro: {e}")
            raise

    async def add_xp(self, discord_id: int, amount: int) -> Optional[UserModel]:
        """
        Adiciona XP a um usuário e atualiza o level se necessário.

        Args:
            discord_id: ID do usuário
            amount: Quantidade de XP

        Returns:
            UserModel atualizado ou None
        """
        try:
            user = await self.get_user(discord_id)
            if not user:
                return None

            user.xp += amount
            # Calcular novo level (100 XP por level)
            user.level = (user.xp // 100) + 1

            await self.update_user(user)

            return user

        except Exception as e:
            logger.error(f"Erro ao adicionar XP: {e}")
            raise

    async def increment_stat(self, discord_id: int, stat: str) -> Optional[UserModel]:
        """
        Incrementa uma estatística do usuário em 1.

        Args:
            discord_id: ID do usuário
            stat: Nome da estatística (commands_used, messages_count, etc)

        Returns:
            UserModel atualizado ou None
        """
        try:
            user = await self.get_user(discord_id)
            if not user:
                return None

            if hasattr(user, stat):
                setattr(user, stat, getattr(user, stat) + 1)
                await self.update_user(user)

            return user

        except Exception as e:
            logger.error(f"Erro ao incrementar estatística: {e}")
            raise

    async def get_top_users(self, field: str, limit: int = 10) -> List[UserModel]:
        """
        Obtém os usuários com maior valor em um campo.

        Args:
            field: Campo a ordenar (money, xp, level, etc)
            limit: Quantidade de resultados

        Returns:
            Lista de UserModel ordenada
        """
        try:
            query = f"SELECT * FROM users ORDER BY {field} DESC LIMIT ?"
            results = await self.db.fetch_all(query, (limit,))

            return [UserModel.from_dict(row) for row in results]

        except Exception as e:
            logger.error(f"Erro ao obter top usuários: {e}")
            raise

    async def get_user_rank(self, discord_id: int, field: str) -> int:
        """
        Obtém a posição de um usuário no ranking.

        Args:
            discord_id: ID do usuário
            field: Campo do ranking

        Returns:
            Posição no ranking (1-based)
        """
        try:
            user = await self.get_user(discord_id)
            if not user:
                return 0

            query = f"""
            SELECT COUNT(*) as rank FROM users
            WHERE {field} > ?
            """

            result = await self.db.fetch_one(query, (getattr(user, field),))
            return result["rank"] + 1 if result else 0

        except Exception as e:
            logger.error(f"Erro ao obter rank: {e}")
            raise
