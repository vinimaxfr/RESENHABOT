"""
Modelo de transação financeira.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class TransactionType(Enum):
    """Tipos de transações."""
    SALARY = "salary"              # Trabalho
    DAILY = "daily"                # Daily reward
    TRANSFER_SENT = "transfer_sent"  # Transferência enviada
    TRANSFER_RECEIVED = "transfer_received"  # Transferência recebida
    ROBBERY = "robbery"            # Roubo/Roubado
    PURCHASE = "purchase"          # Compra de item
    SALE = "sale"                  # Venda de item


@dataclass
class TransactionModel:
    """Modelo que representa uma transação."""

    discord_id: int
    server_id: int
    transaction_type: str
    amount: int
    description: str
    related_user_id: int = None  # Para transferências/roubos
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    @classmethod
    def from_dict(cls, data: dict) -> "TransactionModel":
        """Cria a partir de dicionário."""
        return cls(
            discord_id=data.get("discord_id"),
            server_id=data.get("server_id"),
            transaction_type=data.get("transaction_type"),
            amount=data.get("amount"),
            description=data.get("description"),
            related_user_id=data.get("related_user_id"),
            created_at=data.get("created_at", datetime.now().isoformat()),
        )
