"""
Modelo de inventário do usuário.
"""

from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class InventoryModel:
    """Modelo que representa o inventário de um usuário."""

    discord_id: int
    server_id: int
    item_id: str
    quantity: int = 1
    acquired_at: str = field(default_factory=lambda: datetime.now().isoformat())

    @classmethod
    def from_dict(cls, data: dict) -> "InventoryModel":
        """Cria a partir de dicionário."""
        return cls(
            discord_id=data.get("discord_id"),
            server_id=data.get("server_id"),
            item_id=data.get("item_id"),
            quantity=data.get("quantity", 1),
            acquired_at=data.get("acquired_at", datetime.now().isoformat()),
        )
