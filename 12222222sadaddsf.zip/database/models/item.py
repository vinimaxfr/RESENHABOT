"""
Modelo de item da loja.
"""

from dataclasses import dataclass
from enum import Enum


class ItemRarity(Enum):
    """Raridade dos itens."""
    COMUM = "comum"
    RARO = "raro"
    ÉPICO = "épico"
    LENDÁRIO = "lendário"


@dataclass
class ItemModel:
    """Modelo que representa um item."""

    item_id: str
    name: str
    description: str
    price: int
    rarity: str  # comum, raro, épico, lendário
    emoji: str
    stackable: bool = True

    @classmethod
    def from_dict(cls, data: dict) -> "ItemModel":
        """Cria a partir de dicionário."""
        return cls(
            item_id=data.get("item_id"),
            name=data.get("name"),
            description=data.get("description"),
            price=data.get("price"),
            rarity=data.get("rarity", "comum"),
            emoji=data.get("emoji", "📦"),
            stackable=data.get("stackable", True),
        )
