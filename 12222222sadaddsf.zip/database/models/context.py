"""
Modelo de contexto de conversa para IA.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List


@dataclass
class ContextMessage:
    """Representa uma mensagem no contexto."""

    author_id: int
    author_name: str
    content: str
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())


@dataclass
class ContextModel:
    """Modelo que representa o contexto de uma conversa."""

    discord_id: int
    server_id: int
    messages: List[ContextMessage] = field(default_factory=list)
    last_interaction: str = field(default_factory=lambda: datetime.now().isoformat())
    total_interactions: int = 0

    def add_message(self, author_id: int, author_name: str, content: str) -> None:
        """Adiciona uma mensagem ao contexto."""
        self.messages.append(
            ContextMessage(
                author_id=author_id,
                author_name=author_name,
                content=content
            )
        )

        # Manter apenas últimas 10 mensagens
        if len(self.messages) > 10:
            self.messages = self.messages[-10:]

        self.last_interaction = datetime.now().isoformat()
        self.total_interactions += 1

    def get_context_string(self) -> str:
        """Retorna as mensagens como string formatada."""
        context = ""
        for msg in self.messages:
            context += f"{msg.author_name}: {msg.content}\n"
        return context

    @classmethod
    def from_dict(cls, data: dict) -> "ContextModel":
        """Cria a partir de dicionário."""
        return cls(
            discord_id=data.get("discord_id"),
            server_id=data.get("server_id"),
            total_interactions=data.get("total_interactions", 0),
            last_interaction=data.get("last_interaction", datetime.now().isoformat()),
        )
