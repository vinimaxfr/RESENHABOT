"""
Modelo para armazenar medições de palo.
"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class EventType(Enum):
    """Tipos de eventos especiais."""
    NORMAL = "normal"
    JACKPOT = "jackpot"           # 5% - Ganho máximo
    CRITICAL_FAIL = "critical_fail"  # 10% - Perda máxima
    MULTIPLIER = "multiplier"      # 15% - Multiplicador 2x
    LEGENDARY = "legendary"        # 2% - Evento especial raro


@dataclass
class MeasurementModel:
    """Modelo que representa uma medição de palo."""

    discord_id: int
    server_id: int
    amount_change: int  # Positivo ou negativo
    new_total: int
    event_type: str  # normal, jackpot, critical_fail, multiplier, legendary
    message: str  # Mensagem personalizada do evento
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())

    @classmethod
    def from_dict(cls, data: dict) -> "MeasurementModel":
        """Cria uma instância a partir de um dicionário."""
        return cls(
            discord_id=data.get("discord_id"),
            server_id=data.get("server_id"),
            amount_change=data.get("amount_change", 0),
            new_total=data.get("new_total", 0),
            event_type=data.get("event_type", "normal"),
            message=data.get("message", ""),
            created_at=data.get("created_at", datetime.now().isoformat()),
        )

    def to_dict(self) -> dict:
        """Converte para dicionário."""
        return {
            "discord_id": self.discord_id,
            "server_id": self.server_id,
            "amount_change": self.amount_change,
            "new_total": self.new_total,
            "event_type": self.event_type,
            "message": self.message,
            "created_at": self.created_at,
        }
