"""
Modelo de usuário do Resenha Bot.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class UserModel:
    """Modelo que representa um usuário no banco de dados."""

    discord_id: int
    name: str
    money: int = 0
    xp: int = 0
    level: int = 1
    commands_used: int = 0
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    messages_count: int = 0
    voice_calls: int = 0
    minigames_wins: int = 0
    palo_current: int = 0
    palo_best: int = 0
    palo_worst: int = 0
    palo_last_measurement: Optional[str] = None
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    @classmethod
    def from_dict(cls, data: dict) -> "UserModel":
        """Cria uma instância a partir de um dicionário."""
        return cls(
            discord_id=data.get("discord_id"),
            name=data.get("name", "Unknown"),
            money=data.get("money", 0),
            xp=data.get("xp", 0),
            level=data.get("level", 1),
            commands_used=data.get("commands_used", 0),
            created_at=data.get("created_at", datetime.now().isoformat()),
            messages_count=data.get("messages_count", 0),
            voice_calls=data.get("voice_calls", 0),
            minigames_wins=data.get("minigames_wins", 0),
            palo_current=data.get("palo_current", 0),
            palo_best=data.get("palo_best", 0),
            palo_worst=data.get("palo_worst", 0),
            palo_last_measurement=data.get("palo_last_measurement"),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
        )

    def to_dict(self) -> dict:
        """Converte para dicionário."""
        return {
            "discord_id": self.discord_id,
            "name": self.name,
            "money": self.money,
            "xp": self.xp,
            "level": self.level,
            "commands_used": self.commands_used,
            "created_at": self.created_at,
            "messages_count": self.messages_count,
            "voice_calls": self.voice_calls,
            "minigames_wins": self.minigames_wins,
            "palo_current": self.palo_current,
            "palo_best": self.palo_best,
            "palo_worst": self.palo_worst,
            "palo_last_measurement": self.palo_last_measurement,
            "updated_at": self.updated_at,
        }
