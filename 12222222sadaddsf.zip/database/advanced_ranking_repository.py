"""
Ranking avançado com múltiplas categorias.
"""

from typing import List
from database.manager import DatabaseManager
from utils.logger import setup_logger

logger = setup_logger(__name__)


class AdvancedRankingRepository:
    """Repository para rankings avançados."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    async def get_top_by_infractions(self, server_id: int, limit: int = 10) -> List[dict]:
        """Top usuários por infrações."""
        try:
            rows = await self.db.fetch_all("""
                SELECT i.discord_id, COUNT(*) as total, 
                       (SELECT name FROM users WHERE discord_id = i.discord_id) as name
                FROM infractions i
                WHERE i.server_id = ?
                GROUP BY i.discord_id
                ORDER BY total DESC
                LIMIT ?
            """, (server_id, limit))
            return [dict(row) for row in rows] if rows else []
        except Exception as e:
            logger.error(f"Erro ao buscar ranking infrações: {e}")
            return []

    async def get_top_by_moderations(self, server_id: int, limit: int = 10) -> List[dict]:
        """Top moderadores por ações."""
        try:
            rows = await self.db.fetch_all("""
                SELECT moderator_id as discord_id, COUNT(*) as total,
                       (SELECT name FROM users WHERE discord_id = moderator_id) as name
                FROM infractions
                WHERE server_id = ?
                GROUP BY moderator_id
                ORDER BY total DESC
                LIMIT ?
            """, (server_id, limit))
            return [dict(row) for row in rows] if rows else []
        except Exception as e:
            logger.error(f"Erro ao buscar ranking moderações: {e}")
            return []

    async def get_economy_stats(self, server_id: int) -> List[dict]:
        """Stats de economia."""
        try:
            rows = await self.db.fetch_all("""
                SELECT discord_id, money, xp, level, minigames_wins
                FROM users
                WHERE discord_id IN (
                    SELECT discord_id FROM users WHERE discord_id > 0
                )
                ORDER BY money DESC
                LIMIT 20
            """)
            return [dict(row) for row in rows] if rows else []
        except Exception as e:
            logger.error(f"Erro ao buscar stats economia: {e}")
            return []
