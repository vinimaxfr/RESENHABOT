"""
Repository para gerenciar contextos de conversa.
"""

from typing import Dict, Optional
from database.models.context import ContextModel
from utils.logger import setup_logger

logger = setup_logger(__name__)


class ContextRepository:
    """Gerencia contextos de conversa em memória."""

    def __init__(self):
        """Inicializa o repository."""
        self.contexts: Dict[str, ContextModel] = {}

    def _get_key(self, discord_id: int, server_id: int) -> str:
        """Cria chave única para usuário+servidor."""
        return f"{discord_id}_{server_id}"

    async def get_or_create_context(
        self,
        discord_id: int,
        server_id: int
    ) -> ContextModel:
        """Obtém ou cria um contexto."""
        key = self._get_key(discord_id, server_id)

        if key not in self.contexts:
            self.contexts[key] = ContextModel(
                discord_id=discord_id,
                server_id=server_id
            )
            logger.info(f"Novo contexto criado: {key}")

        return self.contexts[key]

    async def add_message(
        self,
        discord_id: int,
        server_id: int,
        author_id: int,
        author_name: str,
        content: str
    ) -> None:
        """Adiciona uma mensagem ao contexto."""
        context = await self.get_or_create_context(discord_id, server_id)
        context.add_message(author_id, author_name, content)

    async def get_context_string(
        self,
        discord_id: int,
        server_id: int
    ) -> str:
        """Obtém o contexto formatado como string."""
        context = await self.get_or_create_context(discord_id, server_id)
        return context.get_context_string()

    async def clear_context(
        self,
        discord_id: int,
        server_id: int
    ) -> None:
        """Limpa o contexto."""
        key = self._get_key(discord_id, server_id)
        if key in self.contexts:
            self.contexts[key].messages = []
            logger.info(f"Contexto limpo: {key}")

    async def get_stats(
        self,
        discord_id: int,
        server_id: int
    ) -> dict:
        """Obtém estatísticas do contexto."""
        context = await self.get_or_create_context(discord_id, server_id)
        return {
            "total_interactions": context.total_interactions,
            "messages_count": len(context.messages),
            "last_interaction": context.last_interaction,
        }
