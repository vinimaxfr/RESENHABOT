"""
Repository para gerenciar inventário do usuário.
"""

from typing import List, Optional
from database.manager import DatabaseManager
from database.models.inventory import InventoryModel
from utils.logger import setup_logger

logger = setup_logger(__name__)


class InventoryRepository:
    """Gerencia operações de inventário."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    async def create_tables(self) -> None:
        """Cria a tabela de inventário."""
        query = """
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            discord_id INTEGER NOT NULL,
            server_id INTEGER NOT NULL,
            item_id TEXT NOT NULL,
            quantity INTEGER DEFAULT 1,
            acquired_at TEXT NOT NULL,
            UNIQUE(discord_id, server_id, item_id)
        )
        """
        try:
            await self.db.execute(query)
            logger.info("✓ Tabela 'inventory' criada/verificada")
        except Exception as e:
            logger.error(f"Erro ao criar tabela de inventário: {e}")
            raise

    async def add_item(
        self,
        discord_id: int,
        server_id: int,
        item_id: str,
        quantity: int = 1
    ) -> None:
        """Adiciona um item ao inventário do usuário."""
        try:
            # Verificar se já existe
            existing = await self.get_item(discord_id, server_id, item_id)

            if existing:
                # Atualizar quantidade
                query = """
                UPDATE inventory SET quantity = quantity + ?
                WHERE discord_id = ? AND server_id = ? AND item_id = ?
                """
                await self.db.execute(query, (quantity, discord_id, server_id, item_id))
            else:
                # Inserir novo
                inv = InventoryModel(
                    discord_id=discord_id,
                    server_id=server_id,
                    item_id=item_id,
                    quantity=quantity,
                )
                query = """
                INSERT INTO inventory (discord_id, server_id, item_id, quantity, acquired_at)
                VALUES (?, ?, ?, ?, ?)
                """
                await self.db.execute(
                    query,
                    (inv.discord_id, inv.server_id, inv.item_id, inv.quantity, inv.acquired_at),
                )

            logger.info(f"✓ Item {item_id} adicionado ao inventário")
        except Exception as e:
            logger.error(f"Erro ao adicionar item ao inventário: {e}")
            raise

    async def get_item(
        self,
        discord_id: int,
        server_id: int,
        item_id: str
    ) -> Optional[InventoryModel]:
        """Obtém um item do inventário."""
        try:
            query = """
            SELECT * FROM inventory
            WHERE discord_id = ? AND server_id = ? AND item_id = ?
            """
            result = await self.db.fetch_one(query, (discord_id, server_id, item_id))
            return InventoryModel.from_dict(result) if result else None
        except Exception as e:
            logger.error(f"Erro ao obter item do inventário: {e}")
            raise

    async def get_user_inventory(
        self,
        discord_id: int,
        server_id: int
    ) -> List[InventoryModel]:
        """Obtém todo o inventário de um usuário."""
        try:
            query = """
            SELECT * FROM inventory
            WHERE discord_id = ? AND server_id = ?
            ORDER BY acquired_at DESC
            """
            results = await self.db.fetch_all(query, (discord_id, server_id))
            return [InventoryModel.from_dict(row) for row in results]
        except Exception as e:
            logger.error(f"Erro ao obter inventário: {e}")
            raise

    async def remove_item(
        self,
        discord_id: int,
        server_id: int,
        item_id: str,
        quantity: int = 1
    ) -> bool:
        """Remove um item do inventário."""
        try:
            existing = await self.get_item(discord_id, server_id, item_id)

            if not existing or existing.quantity < quantity:
                return False

            if existing.quantity == quantity:
                # Deletar o item
                query = """
                DELETE FROM inventory
                WHERE discord_id = ? AND server_id = ? AND item_id = ?
                """
                await self.db.execute(query, (discord_id, server_id, item_id))
            else:
                # Decrementar quantidade
                query = """
                UPDATE inventory SET quantity = quantity - ?
                WHERE discord_id = ? AND server_id = ? AND item_id = ?
                """
                await self.db.execute(query, (quantity, discord_id, server_id, item_id))

            logger.info(f"✓ Item {item_id} removido do inventário")
            return True

        except Exception as e:
            logger.error(f"Erro ao remover item: {e}")
            raise
