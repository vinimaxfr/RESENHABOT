"""
Repository para gerenciar histórico de medições.
"""

from typing import Optional, List
from .manager import DatabaseManager
from .models.measurement import MeasurementModel
from utils.logger import setup_logger

logger = setup_logger(__name__)


class MeasurementRepository:
    """Gerencia operações de histórico de medições."""

    def __init__(self, db: DatabaseManager):
        """
        Inicializa o repository.

        Args:
            db: Gerenciador de banco de dados
        """
        self.db = db

    async def create_tables(self) -> None:
        """Cria a tabela de medições se não existir."""
        create_table_query = """
        CREATE TABLE IF NOT EXISTS measurements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            discord_id INTEGER NOT NULL,
            server_id INTEGER NOT NULL,
            amount_change INTEGER NOT NULL,
            new_total INTEGER NOT NULL,
            event_type TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
        """
        try:
            await self.db.execute(create_table_query)
            logger.info("✓ Tabela 'measurements' criada/verificada")
        except Exception as e:
            logger.error(f"Erro ao criar tabela de medições: {e}")
            raise

    async def add_measurement(self, measurement: MeasurementModel) -> None:
        """
        Adiciona uma nova medição ao histórico.

        Args:
            measurement: Modelo da medição
        """
        try:
            query = """
            INSERT INTO measurements (
                discord_id, server_id, amount_change, new_total,
                event_type, message, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """

            await self.db.execute(
                query,
                (
                    measurement.discord_id,
                    measurement.server_id,
                    measurement.amount_change,
                    measurement.new_total,
                    measurement.event_type,
                    measurement.message,
                    measurement.created_at,
                )
            )

            logger.info(f"✓ Medição registrada para {measurement.discord_id}")

        except Exception as e:
            logger.error(f"Erro ao adicionar medição: {e}")
            raise

    async def get_user_measurements(
        self,
        discord_id: int,
        server_id: int,
        limit: int = 50
    ) -> List[MeasurementModel]:
        """
        Obtém o histórico de medições de um usuário.

        Args:
            discord_id: ID do usuário
            server_id: ID do servidor
            limit: Quantidade máxima de resultados

        Returns:
            Lista de MeasurementModel
        """
        try:
            query = """
            SELECT * FROM measurements
            WHERE discord_id = ? AND server_id = ?
            ORDER BY created_at DESC
            LIMIT ?
            """

            results = await self.db.fetch_all(query, (discord_id, server_id, limit))
            return [MeasurementModel.from_dict(row) for row in results]

        except Exception as e:
            logger.error(f"Erro ao obter histórico de medições: {e}")
            raise

    async def get_last_measurement(
        self,
        discord_id: int,
        server_id: int
    ) -> Optional[MeasurementModel]:
        """
        Obtém a última medição de um usuário.

        Args:
            discord_id: ID do usuário
            server_id: ID do servidor

        Returns:
            MeasurementModel ou None
        """
        try:
            query = """
            SELECT * FROM measurements
            WHERE discord_id = ? AND server_id = ?
            ORDER BY created_at DESC
            LIMIT 1
            """

            result = await self.db.fetch_one(query, (discord_id, server_id))
            return MeasurementModel.from_dict(result) if result else None

        except Exception as e:
            logger.error(f"Erro ao obter última medição: {e}")
            raise

    async def delete_old_measurements(self, days: int = 90) -> None:
        """
        Deleta medições mais antigas que X dias.

        Args:
            days: Número de dias para manter
        """
        try:
            query = """
            DELETE FROM measurements
            WHERE datetime(created_at) < datetime('now', '-' || ? || ' days')
            """

            await self.db.execute(query, (days,))
            logger.info(f"✓ Medições com mais de {days} dias deletadas")

        except Exception as e:
            logger.error(f"Erro ao deletar medições antigas: {e}")
            raise

    async def get_top_measurements(
        self,
        server_id: int,
        limit: int = 10
    ) -> List[tuple]:
        """
        Obtém os maiores "palos" do servidor.

        Args:
            server_id: ID do servidor
            limit: Quantidade de resultados

        Returns:
            Lista de tuplas (discord_id, max_palo)
        """
        try:
            query = """
            SELECT discord_id, MAX(new_total) as max_palo
            FROM measurements
            WHERE server_id = ?
            GROUP BY discord_id
            ORDER BY max_palo DESC
            LIMIT ?
            """

            results = await self.db.fetch_all(query, (server_id, limit))
            return [(row["discord_id"], row["max_palo"]) for row in results]

        except Exception as e:
            logger.error(f"Erro ao obter top medições: {e}")
            raise
