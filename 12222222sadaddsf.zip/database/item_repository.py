"""
Repository para gerenciar itens da loja.
"""

from typing import List, Optional
from database.manager import DatabaseManager
from database.models.item import ItemModel
from utils.logger import setup_logger

logger = setup_logger(__name__)

# Itens padrão da loja
DEFAULT_ITEMS = [
    {
        "item_id": "lucky_coin",
        "name": "Moeda da Sorte",
        "description": "Aumenta suas chances em 10%",
        "price": 500,
        "rarity": "comum",
        "emoji": "🪙",
        "stackable": True,
    },
    {
        "item_id": "shield",
        "name": "Escudo Anti-Roubo",
        "description": "Protege seu dinheiro por 12 horas",
        "price": 1000,
        "rarity": "raro",
        "emoji": "🛡️",
        "stackable": True,
    },
    {
        "item_id": "magnifying_glass",
        "name": "Lupa do Detetive",
        "description": "Aumenta suas chances de roubo em 25%",
        "price": 2000,
        "rarity": "raro",
        "emoji": "🔍",
        "stackable": True,
    },
    {
        "item_id": "golden_ticket",
        "name": "Bilhete Dourado",
        "description": "Duplica seu ganho diário",
        "price": 5000,
        "rarity": "épico",
        "emoji": "🎫",
        "stackable": False,
    },
    {
        "item_id": "money_printer",
        "name": "Impressora de Dinheiro",
        "description": "Gera $100 por hora (até 10 uso)",
        "price": 10000,
        "rarity": "lendário",
        "emoji": "🖨️",
        "stackable": False,
    },
]


class ItemRepository:
    """Gerencia operações de itens."""

    def __init__(self, db: DatabaseManager):
        self.db = db

    async def create_tables(self) -> None:
        """Cria a tabela de itens."""
        query = """
        CREATE TABLE IF NOT EXISTS items (
            item_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT NOT NULL,
            price INTEGER NOT NULL,
            rarity TEXT NOT NULL,
            emoji TEXT NOT NULL,
            stackable BOOLEAN NOT NULL
        )
        """
        try:
            await self.db.execute(query)

            # Adicionar itens padrão se não existirem
            for item in DEFAULT_ITEMS:
                existing = await self.get_item(item["item_id"])
                if not existing:
                    await self.add_item(ItemModel(**item))

            logger.info("✓ Tabela 'items' criada/verificada")
        except Exception as e:
            logger.error(f"Erro ao criar tabela de itens: {e}")
            raise

    async def add_item(self, item: ItemModel) -> None:
        """Adiciona um item à loja."""
        try:
            query = """
            INSERT OR IGNORE INTO items (
                item_id, name, description, price, rarity, emoji, stackable
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """
            await self.db.execute(
                query,
                (
                    item.item_id,
                    item.name,
                    item.description,
                    item.price,
                    item.rarity,
                    item.emoji,
                    item.stackable,
                )
            )
            logger.info(f"✓ Item adicionado: {item.name}")
        except Exception as e:
            logger.error(f"Erro ao adicionar item: {e}")
            raise

    async def get_item(self, item_id: str) -> Optional[ItemModel]:
        """Obtém um item pelo ID."""
        try:
            query = "SELECT * FROM items WHERE item_id = ?"
            result = await self.db.fetch_one(query, (item_id,))
            return ItemModel.from_dict(result) if result else None
        except Exception as e:
            logger.error(f"Erro ao obter item: {e}")
            raise

    async def get_all_items(self) -> List[ItemModel]:
        """Obtém todos os itens da loja."""
        try:
            query = "SELECT * FROM items ORDER BY price ASC"
            results = await self.db.fetch_all(query)
            return [ItemModel.from_dict(row) for row in results]
        except Exception as e:
            logger.error(f"Erro ao obter itens: {e}")
            raise

    async def get_items_by_rarity(self, rarity: str) -> List[ItemModel]:
        """Obtém itens por raridade."""
        try:
            query = "SELECT * FROM items WHERE rarity = ? ORDER BY price ASC"
            results = await self.db.fetch_all(query, (rarity,))
            return [ItemModel.from_dict(row) for row in results]
        except Exception as e:
            logger.error(f"Erro ao obter itens por raridade: {e}")
            raise
