"""
Repository para gerenciar infrações de usuários.
"""

import aiosqlite
from datetime import datetime
from typing import Optional, List
from database.manager import DatabaseManager
from utils.logger import setup_logger

logger = setup_logger(__name__)


class InfractionRepository:
    """Repository para gerenciar infrações."""

    def __init__(self, db: DatabaseManager):
        """
        Inicializa o repository.

        Args:
            db: DatabaseManager instance
        """
        self.db = db

    async def create_tables(self) -> None:
        """Cria tabelas necessárias."""
        try:
            await self.db.execute("""
                CREATE TABLE IF NOT EXISTS infractions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    discord_id INTEGER NOT NULL,
                    server_id INTEGER NOT NULL,
                    infraction_type TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    moderator_id INTEGER NOT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (moderator_id) REFERENCES users(discord_id)
                )
            """)

            # Criar índices para performance
            await self.db.execute("""
                CREATE INDEX IF NOT EXISTS idx_infractions_user_server
                ON infractions(discord_id, server_id)
            """)

            logger.info("✓ Tabela infractions criada/verificada")

        except Exception as e:
            logger.error(f"Erro ao criar tabelas: {e}")
            raise

    async def add_infraction(
        self,
        discord_id: int,
        server_id: int,
        infraction_type: str,
        reason: str,
        moderator_id: int
    ) -> Optional[int]:
        """
        Adiciona uma infração.

        Args:
            discord_id: ID do usuário
            server_id: ID do servidor
            infraction_type: Tipo (kick, ban, mute, timeout, warn)
            reason: Motivo da infração
            moderator_id: ID do moderador

        Returns:
            ID da infração ou None
        """
        try:
            cursor = await self.db.execute("""
                INSERT INTO infractions
                (discord_id, server_id, infraction_type, reason, moderator_id)
                VALUES (?, ?, ?, ?, ?)
            """, (discord_id, server_id, infraction_type, reason, moderator_id))

            await self.db.conn.commit()
            logger.info(
                f"Infração adicionada: {infraction_type} para {discord_id}"
            )
            return cursor.lastrowid

        except Exception as e:
            logger.error(f"Erro ao adicionar infração: {e}")
            return None

    async def get_user_infractions(
        self,
        discord_id: int,
        server_id: int
    ) -> List[dict]:
        """
        Obtém infrações de um usuário.

        Args:
            discord_id: ID do usuário
            server_id: ID do servidor

        Returns:
            Lista de infrações
        """
        try:
            rows = await self.db.fetch_all("""
                SELECT * FROM infractions
                WHERE discord_id = ? AND server_id = ?
                ORDER BY created_at DESC
                LIMIT 20
            """, (discord_id, server_id))

            return [dict(row) for row in rows] if rows else []

        except Exception as e:
            logger.error(f"Erro ao obter infrações: {e}")
            return []

    async def get_total_infractions(
        self,
        discord_id: int,
        server_id: int
    ) -> int:
        """
        Obtém total de infrações de um usuário.

        Args:
            discord_id: ID do usuário
            server_id: ID do servidor

        Returns:
            Total de infrações
        """
        try:
            row = await self.db.fetch_one("""
                SELECT COUNT(*) as total FROM infractions
                WHERE discord_id = ? AND server_id = ?
            """, (discord_id, server_id))

            return row["total"] if row else 0

        except Exception as e:
            logger.error(f"Erro ao contar infrações: {e}")
            return 0

    async def get_server_infractions(self, server_id: int) -> List[dict]:
        """
        Obtém todas as infrações de um servidor.

        Args:
            server_id: ID do servidor

        Returns:
            Lista de infrações
        """
        try:
            rows = await self.db.fetch_all("""
                SELECT * FROM infractions
                WHERE server_id = ?
                ORDER BY created_at DESC
                LIMIT 50
            """, (server_id,))

            return [dict(row) for row in rows] if rows else []

        except Exception as e:
            logger.error(f"Erro ao obter infrações do servidor: {e}")
            return []

    async def get_warns_count(
        self,
        discord_id: int,
        server_id: int
    ) -> int:
        """
        Obtém contador de avisos.

        Args:
            discord_id: ID do usuário
            server_id: ID do servidor

        Returns:
            Total de avisos
        """
        try:
            row = await self.db.fetch_one("""
                SELECT COUNT(*) as total FROM infractions
                WHERE discord_id = ? AND server_id = ? AND infraction_type = 'warn'
            """, (discord_id, server_id))

            return row["total"] if row else 0

        except Exception as e:
            logger.error(f"Erro ao contar avisos: {e}")
            return 0
