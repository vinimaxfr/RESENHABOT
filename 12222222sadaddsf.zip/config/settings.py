"""
Configurações principais do Resenha Bot.
"""

import os
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv

# Carrega variáveis do arquivo .env
load_dotenv()


class Settings:
    """Classe para gerenciar todas as configurações do bot."""

    # Paths
    BASE_DIR: Path = Path(__file__).parent.parent
    DATABASE_DIR: Path = BASE_DIR / "database"
    LOGS_DIR: Path = BASE_DIR / "logs"
    ASSETS_DIR: Path = BASE_DIR / "assets"

    # Criar diretórios se não existirem
    DATABASE_DIR.mkdir(exist_ok=True)
    LOGS_DIR.mkdir(exist_ok=True)
    ASSETS_DIR.mkdir(exist_ok=True)

    # Discord
    DISCORD_TOKEN: str = os.getenv("DISCORD_TOKEN", "")
    DISCORD_GUILD_ID: Optional[int] = None
    guild_id_str = os.getenv("DISCORD_GUILD_ID", "")
    if guild_id_str:
        DISCORD_GUILD_ID = int(guild_id_str)

    # OpenAI
    GROQ_API_KEY: str = os.getenv("GROQ_API_KEY", "")

    # Database
    DATABASE_PATH: Path = Path(os.getenv("DATABASE_PATH", str(DATABASE_DIR / "resenhabot.db")))

    # Bot
    BOT_PREFIX: str = os.getenv("BOT_PREFIX", "!")
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

    # Voice Features
    ENABLE_VOICE_FEATURES: bool = os.getenv("ENABLE_VOICE_FEATURES", "false").lower() == "true"
    FFMPEG_PATH: str = os.getenv("FFMPEG_PATH", "ffmpeg")

    # Limits e Configurações de Jogo
    DAILY_REWARD: int = 1000
    MEDIR_PALO_DAILY_LIMIT: int = 1
    MEDIR_PALO_MIN_GAIN: int = -20
    MEDIR_PALO_MAX_GAIN: int = 50

    # Raridade de eventos especiais em porcentagem
    JACKPOT_CHANCE: float = 0.05  # 5%
    CRITICAL_FAIL_CHANCE: float = 0.10  # 10%
    MULTIPLIER_CHANCE: float = 0.15  # 15%
    LEGENDARY_CHANCE: float = 0.02  # 2%

    @classmethod
    def validate(cls) -> bool:
        """Valida se as configurações necessárias estão presentes."""
        if not cls.DISCORD_TOKEN:
            raise ValueError("DISCORD_TOKEN não foi configurada!")
        return True
