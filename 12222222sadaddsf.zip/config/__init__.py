"""
Módulo de configuração do Resenha Bot.
Gerencia todas as configurações globais do bot.
"""

from .settings import Settings

__all__ = ["Settings"]
