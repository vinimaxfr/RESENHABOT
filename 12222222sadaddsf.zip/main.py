"""
Resenha Bot - Bot Discord Profissional
Ponto de entrada principal do bot.
"""

import discord
from discord.ext import commands
import asyncio
from pathlib import Path
from typing import Optional
from config.settings import Settings
from database.manager import DatabaseManager
from utils.logger import setup_logger
from utils.ffmpeg_setup import ensure_ffmpeg

logger = setup_logger(__name__)

# Caminho do ffmpeg resolvido no startup (compartilhado com os cogs de voz)
FFMPEG_PATH: str = "ffmpeg"


class ResenhaBot(commands.Bot):
    """Classe principal do Resenha Bot."""

    def __init__(self):
        """Inicializa o bot com as configurações necessárias."""
        intents = discord.Intents.default()
        intents.message_content = True
        intents.members = True
        intents.voice_states = True

        super().__init__(
            command_prefix=Settings.BOT_PREFIX,
            intents=intents,
            help_command=None
        )

        self.db: Optional[DatabaseManager] = None
        self.ready = False
        self.ffmpeg_path: str = "ffmpeg"

    async def setup_hook(self) -> None:
        """Configuração inicial do bot antes de conectar."""
        try:
            logger.info("[INIT] Inicializando Resenha Bot...")

            # ── Garantir ffmpeg disponível ANTES de tudo ───────────────
            self.ffmpeg_path = await ensure_ffmpeg()
            logger.info(f"[FFMPEG] Usando: {self.ffmpeg_path}")

            # ── Banco de dados ─────────────────────────────────────────
            self.db = DatabaseManager(Settings.DATABASE_PATH)
            await self.db.connect()
            await self.db.create_tables()

            from database.user_repository import UserRepository
            from database.measurement_repository import MeasurementRepository
            from database.transaction_repository import TransactionRepository
            from database.item_repository import ItemRepository
            from database.inventory_repository import InventoryRepository
            from database.infraction_repository import InfractionRepository

            await UserRepository(self.db).create_tables()
            await MeasurementRepository(self.db).create_tables()
            await TransactionRepository(self.db).create_tables()
            await ItemRepository(self.db).create_tables()
            await InventoryRepository(self.db).create_tables()
            await InfractionRepository(self.db).create_tables()

            # ── Cogs ───────────────────────────────────────────────────
            await self.load_cogs()

            logger.info("[OK] Bot inicializado com sucesso!")

        except Exception as e:
            logger.error(f"[ERRO] Erro durante a inicializacao: {e}")
            raise

    async def load_cogs(self) -> None:
        """Carrega todos os cogs (módulos de funcionalidades)."""
        cogs_dir = Path(__file__).parent / "cogs"

        cog_folders = ["events", "fun", "economy", "moderation", "ai", "voice"]

        for folder in cog_folders:
            folder_path = cogs_dir / folder
            if not folder_path.exists():
                continue

            for file in folder_path.glob("*.py"):
                if file.name.startswith("_"):
                    continue

                cog_name = file.stem
                try:
                    await self.load_extension(f"cogs.{folder}.{cog_name}")
                    logger.info(f"[LOAD] cogs.{folder}.{cog_name}")
                except Exception as e:
                    logger.error(f"[ERRO] cogs.{folder}.{cog_name}: {e}")

    async def on_ready(self) -> None:
        if not self.ready:
            logger.info(f"[ONLINE] {self.user} esta online!")
            self.ready = True

    async def close(self) -> None:
        if self.db:
            await self.db.disconnect()
        await super().close()


async def main() -> None:
    """Funcao principal para executar o bot."""
    try:
        Settings.validate()
        bot = ResenhaBot()
        async with bot:
            await bot.start(Settings.DISCORD_TOKEN)
    except ValueError as e:
        logger.error(f"[ERRO_CONFIG] Erro de configuracao: {e}")
    except Exception as e:
        logger.error(f"[ERRO_FATAL] Erro fatal: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())
