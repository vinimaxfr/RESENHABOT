"""
Cog principal de moderação com 6 comandos.
"""

import discord
from discord.ext import commands
from discord import app_commands
from datetime import timedelta

from database.infraction_repository import InfractionRepository
from utils.logger import setup_logger
from utils.embeds import EmbedHelper

logger = setup_logger(__name__)


class ModerationCog(commands.Cog):
    """Cog com comandos de moderação."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.infraction_repo = InfractionRepository(bot.db)

    @app_commands.command(
        name="kick",
        description="Remove um usuário do servidor (pode retornar)"
    )
    @app_commands.describe(
        user="Usuário a remover",
        reason="Motivo (opcional)"
    )
    @app_commands.checks.has_permissions(kick_members=True)
    async def kick_command(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        reason: str = "Nenhum motivo fornecido"
    ) -> None:
        """Comando para dar kick em um usuário."""
        await interaction.response.defer()

        try:
            # Validações
            member = await interaction.guild.fetch_member(user.id)
            
            if member.id == interaction.user.id:
                embed = EmbedHelper.error(
                    "Não Pode",
                    "Você não pode dar kick em você mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            if member.id == self.bot.user.id:
                embed = EmbedHelper.error(
                    "Não Pode",
                    "Não posso dar kick em mim mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Verificar hierarquia
            if member.top_role.position >= interaction.user.top_role.position:
                embed = EmbedHelper.error(
                    "Permissão Insuficiente",
                    "Você não pode dar kick em alguém com role igual ou maior!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Registrar infração
            await self.infraction_repo.add_infraction(
                user.id,
                interaction.guild.id,
                "kick",
                reason,
                interaction.user.id
            )

            # Executar ação
            await member.kick(reason=f"{interaction.user.display_name}: {reason}")

            # Responder
            embed = discord.Embed(
                title="👢 Usuário Removido",
                description=f"**Usuário:** {user.mention}\n"
                           f"**Motivo:** {reason}\n"
                           f"**Moderador:** {interaction.user.mention}",
                color=discord.Color.orange()
            )
            embed.set_thumbnail(url=user.avatar.url)

            await interaction.followup.send(embed=embed)
            logger.info(f"Kick: {user.display_name} por {interaction.user.display_name}")

        except discord.Forbidden:
            embed = EmbedHelper.error(
                "Sem Permissão",
                "Não tenho permissão para fazer kick neste usuário!",
                interaction.user
            )
            await interaction.followup.send(embed=embed)
        except Exception as e:
            logger.error(f"Erro no kick: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="ban",
        description="Bane um usuário do servidor"
    )
    @app_commands.describe(
        user="Usuário a banir",
        reason="Motivo (opcional)",
        delete_days="Deletar mensagens dos últimos N dias (0-7)"
    )
    @app_commands.checks.has_permissions(ban_members=True)
    async def ban_command(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        reason: str = "Nenhum motivo fornecido",
        delete_days: int = 0
    ) -> None:
        """Comando para banir um usuário."""
        await interaction.response.defer()

        try:
            # Validações
            if user.id == interaction.user.id:
                embed = EmbedHelper.error(
                    "Não Pode",
                    "Você não pode banir a si mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            if user.id == self.bot.user.id:
                embed = EmbedHelper.error(
                    "Não Pode",
                    "Não posso banir a mim mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Tentar obter membro
            try:
                member = await interaction.guild.fetch_member(user.id)
                if member.top_role.position >= interaction.user.top_role.position:
                    embed = EmbedHelper.error(
                        "Permissão Insuficiente",
                        "Você não pode banir alguém com role igual ou maior!",
                        interaction.user
                    )
                    await interaction.followup.send(embed=embed)
                    return
            except discord.NotFound:
                pass

            # Registrar infração
            await self.infraction_repo.add_infraction(
                user.id,
                interaction.guild.id,
                "ban",
                reason,
                interaction.user.id
            )

            # Executar ação
            await interaction.guild.ban(
                user,
                delete_message_days=min(delete_days, 7),
                reason=f"{interaction.user.display_name}: {reason}"
            )

            # Responder
            embed = discord.Embed(
                title="🔨 Usuário Banido",
                description=f"**Usuário:** {user.mention}\n"
                           f"**Motivo:** {reason}\n"
                           f"**Moderador:** {interaction.user.mention}\n"
                           f"**Mensagens deletadas:** {delete_days} dias",
                color=discord.Color.red()
            )
            embed.set_thumbnail(url=user.avatar.url)

            await interaction.followup.send(embed=embed)
            logger.info(f"Ban: {user.display_name} por {interaction.user.display_name}")

        except discord.Forbidden:
            embed = EmbedHelper.error(
                "Sem Permissão",
                "Não tenho permissão para banir este usuário!",
                interaction.user
            )
            await interaction.followup.send(embed=embed)
        except Exception as e:
            logger.error(f"Erro no ban: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="mute",
        description="Silencia um usuário (remove permissão de falar)"
    )
    @app_commands.describe(
        user="Usuário a silenciar",
        duration="Duração em minutos",
        reason="Motivo (opcional)"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def mute_command(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        duration: int,
        reason: str = "Nenhum motivo fornecido"
    ) -> None:
        """Comando para silenciar um usuário."""
        await interaction.response.defer()

        try:
            # Validar duração
            if duration <= 0 or duration > 40320:  # máx 28 dias
                embed = EmbedHelper.error(
                    "Duração Inválida",
                    "Duração deve ser entre 1 e 40320 minutos (28 dias)",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Obter membro
            try:
                member = await interaction.guild.fetch_member(user.id)
            except discord.NotFound:
                embed = EmbedHelper.error(
                    "Não Encontrado",
                    "Usuário não está no servidor!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            if member.id == interaction.user.id:
                embed = EmbedHelper.error(
                    "Não Pode",
                    "Você não pode silenciar a si mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            if member.top_role.position >= interaction.user.top_role.position:
                embed = EmbedHelper.error(
                    "Permissão Insuficiente",
                    "Você não pode silenciar alguém com role igual ou maior!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Registrar infração
            await self.infraction_repo.add_infraction(
                user.id,
                interaction.guild.id,
                "mute",
                reason,
                interaction.user.id
            )

            # Executar ação
            timeout_until = discord.utils.utcnow() + timedelta(minutes=duration)
            await member.edit(
                timed_out_until=timeout_until,
                reason=f"{interaction.user.display_name}: {reason}"
            )

            # Responder
            embed = discord.Embed(
                title="🔇 Usuário Silenciado",
                description=f"**Usuário:** {user.mention}\n"
                           f"**Duração:** {duration} minutos\n"
                           f"**Motivo:** {reason}\n"
                           f"**Moderador:** {interaction.user.mention}",
                color=discord.Color.yellow()
            )
            embed.set_thumbnail(url=user.avatar.url)

            await interaction.followup.send(embed=embed)
            logger.info(f"Mute: {user.display_name} por {duration}m")

        except discord.Forbidden:
            embed = EmbedHelper.error(
                "Sem Permissão",
                "Não tenho permissão para silenciar este usuário!",
                interaction.user
            )
            await interaction.followup.send(embed=embed)
        except Exception as e:
            logger.error(f"Erro no mute: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="timeout",
        description="Cria um timeout (não pode enviar mensagens)"
    )
    @app_commands.describe(
        user="Usuário",
        duration="Duração em minutos",
        reason="Motivo (opcional)"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def timeout_command(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        duration: int,
        reason: str = "Nenhum motivo fornecido"
    ) -> None:
        """Comando para fazer timeout (alias para mute)."""
        # Chamar mute com os mesmos parâmetros
        await self.mute_command(interaction, user, duration, reason)

    @app_commands.command(
        name="limpar",
        description="Deleta mensagens do canal"
    )
    @app_commands.describe(
        count="Número de mensagens (2-100)"
    )
    @app_commands.checks.has_permissions(manage_messages=True)
    async def clear_command(
        self,
        interaction: discord.Interaction,
        count: int
    ) -> None:
        """Comando para limpar mensagens."""
        await interaction.response.defer()

        try:
            # Validar contagem
            if count < 2 or count > 100:
                embed = EmbedHelper.error(
                    "Contagem Inválida",
                    "Contagem deve ser entre 2 e 100 mensagens",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Deletar mensagens
            deleted = await interaction.channel.purge(limit=count)

            # Responder
            embed = discord.Embed(
                title="🗑️ Mensagens Deletadas",
                description=f"**Deletadas:** {len(deleted)} mensagens\n"
                           f"**Canal:** {interaction.channel.mention}\n"
                           f"**Moderador:** {interaction.user.mention}",
                color=discord.Color.blue()
            )

            await interaction.followup.send(embed=embed)
            logger.info(f"Limpeza: {len(deleted)} mensagens por {interaction.user.display_name}")

        except discord.Forbidden:
            embed = EmbedHelper.error(
                "Sem Permissão",
                "Não tenho permissão para deletar mensagens!",
                interaction.user
            )
            await interaction.followup.send(embed=embed)
        except Exception as e:
            logger.error(f"Erro na limpeza: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="avisar",
        description="Avisa um usuário (registra infração)"
    )
    @app_commands.describe(
        user="Usuário a avisar",
        reason="Motivo (opcional)"
    )
    @app_commands.checks.has_permissions(moderate_members=True)
    async def warn_command(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        reason: str = "Nenhum motivo fornecido"
    ) -> None:
        """Comando para avisar um usuário."""
        await interaction.response.defer()

        try:
            # Validações
            if user.id == interaction.user.id:
                embed = EmbedHelper.error(
                    "Não Pode",
                    "Você não pode avisar a si mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            if user.id == self.bot.user.id:
                embed = EmbedHelper.error(
                    "Não Pode",
                    "Não posso avisar a mim mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Registrar infração
            warn_id = await self.infraction_repo.add_infraction(
                user.id,
                interaction.guild.id,
                "warn",
                reason,
                interaction.user.id
            )

            # Contar avisos totais
            total_warns = await self.infraction_repo.get_warns_count(
                user.id,
                interaction.guild.id
            )

            # Responder
            embed = discord.Embed(
                title="⚠️ Aviso Registrado",
                description=f"**Usuário:** {user.mention}\n"
                           f"**Motivo:** {reason}\n"
                           f"**Aviso #:** {total_warns}\n"
                           f"**Moderador:** {interaction.user.mention}",
                color=discord.Color.gold()
            )
            embed.set_thumbnail(url=user.avatar.url)

            # Avisar sobre limite
            if total_warns >= 3:
                embed.add_field(
                    name="⚠️ Aviso",
                    value="Este usuário atingiu 3 avisos! Considere ações mais severas.",
                    inline=False
                )

            await interaction.followup.send(embed=embed)
            logger.info(f"Aviso: {user.display_name} (#{total_warns})")

        except Exception as e:
            logger.error(f"Erro no aviso: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    cog = ModerationCog(bot)
    await cog.infraction_repo.create_tables()
    await bot.add_cog(cog)
