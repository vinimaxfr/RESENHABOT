"""
TESTE DE MODERAÇÃO - PHASE 8

ANTES DE COMEÇAR:
=================

1. Iniciar bot: python main.py
2. Aguardar: "✅ Bot inicializado com sucesso!"
3. Verificar logs para: "✓ Carregado: cogs.moderation.moderation"
4. Servidor Discord com canal de teste

PASSOS DE TESTE:
================

1. TESTE /kick
   - Convide teste: /kick @test_user Teste de kick
   - Esperado: Usuário removido, embed com 👢
   - Verificar BD: infractions table tem registro
   - Verificar logs: "Kick: test_user por seu_nome"

2. TESTE /ban
   - Convide teste novamente: /ban @test_user Teste de ban delete_days:1
   - Esperado: Usuário banido, embed com 🔨
   - Verificar: Não consegue entrar no servidor
   - Verificar BD: infractions table tem registro type=ban

3. TESTE /mute
   - Convide teste: /mute @test_user 10 Teste mute
   - Esperado: Usuário silenciado por 10 min, embed com 🔇
   - Ação: Usuário não consegue enviar mensagens
   - Tempo: Após 10 min libera automaticamente

4. TESTE /timeout
   - Convide teste: /timeout @test_user 5 Teste timeout
   - Esperado: Igual a mute, embed com 🔇
   - Verificar: Alias funcionando

5. TESTE /limpar
   - Enviar 10 mensagens de teste
   - /limpar 5
   - Esperado: 5 mensagens deletadas, embed com 🗑️
   - Verificar: Não cria infração (só log)

6. TESTE /avisar
   - /avisar @test_user Primeira advertência
   - Esperado: embed com ⚠️ e "Aviso #1"
   - /avisar @test_user Segunda advertência
   - Esperado: embed com ⚠️ e "Aviso #2"
   - /avisar @test_user Terceira advertência
   - Esperado: embed com ⚠️ e "Aviso #3" + ALERTA

7. TESTE PERMISSÕES
   - Sem permissão /kick @user: Erro "Você não tem permissão"
   - User sem role: Erro apropriado

8. TESTE AUTO-PROTEÇÃO
   - /kick @você: Erro "Não pode fazer em si mesmo"
   - /ban @bot: Erro "Não pode fazer no bot"

BANCO DE DADOS:
===============

1. Verificar criação:
   - Abra SQLite viewer
   - Arquivo: data/resenhabot.db
   - Tabela: infractions
   - Colunas: id, discord_id, server_id, infraction_type, reason, moderator_id, created_at

2. Query para verificar:
   SELECT * FROM infractions ORDER BY created_at DESC LIMIT 10;

3. Contar por tipo:
   SELECT infraction_type, COUNT(*) as total FROM infractions GROUP BY infraction_type;

4. Contar avisos de um user:
   SELECT COUNT(*) FROM infractions WHERE discord_id = XXX AND infraction_type = 'warn';

LOGS:
=====

1. Abrir arquivo: logs/resenhabot.log

2. Procurar por:
   - "Kick: xxx"
   - "Ban: xxx"
   - "Mute: xxx"
   - "Aviso: xxx"
   - "Limpeza: X mensagens"

3. Erros esperados:
   - "Erro ao fazer kick: [motivo]"
   - Deve ter try/except

POSSÍVEIS ERROS:
================

❌ "Cog não carregado"
   → Verificar: cogs/moderation/__init__.py
   → Verificar: cogs/moderation/moderation.py
   → Executar: python main.py novamente

❌ "Infração não registra"
   → Verificar: database/infraction_repository.py
   → Verificar: main.py cria repositório
   → Checar logs para erro de BD

❌ "Comando não aparece"
   → Recarregar slash commands: /sync ou reiniciar
   → Verificar permissões do bot

❌ "User não pode ser kickado"
   → Checar hierarquia de roles
   → Bot role deve estar acima do user

❌ "Timeout não funciona"
   → Verificar: discord.py versão 2.3.2+
   → Verificar: Member.edit() funciona

MÉTRICAS DE SUCESSO:
====================

✅ Todos 6 comandos respondendo
✅ Infrações registradas no BD
✅ Cada ação gera 1 infração
✅ Avisos contam progressivamente
✅ Embeds aparecem com cores corretas
✅ Logs escritos em arquivo
✅ Validações funcionam
✅ Erros tratados gracefully

PERFORMANCE:
=============

Tempo esperado por comando:
- /kick: 500-1000ms
- /ban: 500-1000ms
- /mute: 500-1000ms
- /limpar: 1-2s (depende de mensagens)
- /avisar: 300-500ms

Se > 2s: Há problema, checar logs

STRESS TEST:
============

1. Múltiplos usuários em avisos:
   - /avisar @user1, @user2, @user3 (rápido)
   - Verificar: Todos registram

2. Kick em rápida sucessão:
   - /kick @user1, /kick @user2, /kick @user3
   - Verificar: Sem travamentos

3. Limpar grande quantidade:
   - /limpar 100
   - Verificar: Sem lag

DATABASE CONSISTENCY:
====================

1. Sem duplicatas:
   SELECT id, discord_id, server_id, infraction_type, COUNT(*) as cnt
   FROM infractions
   GROUP BY discord_id, server_id, infraction_type, created_at
   HAVING COUNT(*) > 1;
   → Deve retornar vazio

2. Sem infrações órfãs:
   SELECT * FROM infractions
   WHERE moderator_id NOT IN (SELECT discord_id FROM users);
   → Deve retornar vazio

3. Todas com created_at:
   SELECT COUNT(*) FROM infractions WHERE created_at IS NULL;
   → Deve retornar 0

VERDADE/FALSIDADE:
==================

✓ /kick remove permanentemente: FALSO (pode retornar)
✓ /ban remove permanentemente: VERDADEIRO
✓ /mute impede voz: VERDADEIRO
✓ /timeout é igual /mute: VERDADEIRO
✓ /limpar registra infração: FALSO
✓ /avisar conta avisos: VERDADEIRO
✓ 3 avisos auto-kicka: FALSO (apenas alerta)

PRÓXIMO PASSO:
==============

Se todos testes passaram:
→ FASE 8 COMPLETA ✅

Próximo: FASE 9 - Advanced Rankings + Web Dashboard

Aguardando "sim" para FASE 9 ✨
"""
