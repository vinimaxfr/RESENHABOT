"""
Cogs de moderação e administração.
"""

from .moderation import ModerationCog

__all__ = ["ModerationCog"]
