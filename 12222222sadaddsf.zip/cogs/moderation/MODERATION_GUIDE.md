"""
Guia Completo de Moderação - FASE 8

FUNCIONALIDADES:
================

1. /kick <user> [reason]
   - Remove usuário (pode retornar)
   - Requer: kick_members permission
   - Registra: Infração no banco
   - Emoji: 👢

2. /ban <user> [reason] [delete_days]
   - Bane usuário permanentemente
   - Pode deletar mensagens (0-7 dias)
   - Requer: ban_members permission
   - Registra: Infração no banco
   - Emoji: 🔨

3. /mute <user> <duration> [reason]
   - Silencia usuário (timeout)
   - Duração: 1-40320 minutos (máx 28 dias)
   - Pode enviar mensagens mas sem voz
   - Requer: moderate_members permission
   - Registra: Infração no banco
   - Emoji: 🔇

4. /timeout <user> <duration> [reason]
   - ALIAS para /mute
   - Mesmo funcionamento
   - Requer: moderate_members permission
   - Registra: Infração no banco
   - Emoji: 🔇

5. /limpar <count>
   - Deleta mensagens do canal
   - Contagem: 2-100
   - Requer: manage_messages permission
   - Emoji: 🗑️

6. /avisar <user> [reason]
   - Sistema de avisos progressivo
   - Registra: Infração com tipo "warn"
   - Aviso #3: Alerta sobre limite
   - Requer: moderate_members permission
   - Emoji: ⚠️

SISTEMA DE INFRAÇÕES:
=====================

Tabela: infractions
├── id (PK, autoincrement)
├── discord_id (FK → users)
├── server_id
├── infraction_type (kick, ban, mute, timeout, warn)
├── reason
├── moderator_id (FK → users)
└── created_at

Cada ação cria um registro:
✅ kick → Registra
✅ ban → Registra
✅ mute/timeout → Registra
✅ avisar → Registra
✓ limpar → NÃO registra (apenas log)

VALIDAÇÕES:
===========

✅ Permissões:
   - /kick: Requer kick_members
   - /ban: Requer ban_members
   - /mute: Requer moderate_members
   - /timeout: Requer moderate_members
   - /limpar: Requer manage_messages
   - /avisar: Requer moderate_members

✅ Hierarquia de Roles:
   - Não pode fazer ação em role igual/maior
   - Comparação: member.top_role.position
   - Exceção: Aviso tem verificação menos rigorosa

✅ Auto-proteção:
   - Não pode kick/ban/mute a si mesmo
   - Não pode fazer ação no bot
   - Mensagem de erro clara

✅ Parâmetros:
   - count: 2-100 (limpar)
   - duration: 1-40320 minutos (mute)
   - delete_days: 0-7 (ban)
   - reason: Max 200 chars (recomendado)

FLUXO DE EXECUÇÃO:
==================

1. Usuário executa comando
   ↓
2. Validar permissões (has_permissions)
   ↓
3. Bot faz defer (resposta atrasada)
   ↓
4. Executar validações (hierarquia, self, etc)
   ↓
5. Registrar infração no BD
   ↓
6. Executar ação Discord
   ↓
7. Retornar embed de sucesso
   ↓
8. Log em arquivo

EXEMPLOS DE USO:
================

Kick simples:
/kick @usuario Spam demais

Ban com limpeza:
/ban @usuario Comportamento tóxico delete_days:3

Mute 1 hora:
/mute @usuario 60 Flood

Timeout 30 minutos:
/timeout @usuario 30 Spam

Limpar 50 mensagens:
/limpar 50

Avisar:
/avisar @usuario Aviso por advertência

ESTRUTURA INTERNA:
==================

ModerationCog:
├── __init__: Inicializa bot e repo
├── kick_command: 👢 Kick logic
├── ban_command: 🔨 Ban logic
├── mute_command: 🔇 Mute logic
├── timeout_command: 🔇 Timeout (calls mute)
├── clear_command: 🗑️ Clear logic
└── warn_command: ⚠️ Warn logic

InfractionRepository:
├── create_tables: Cria tabela
├── add_infraction: Adiciona registro
├── get_user_infractions: Lista por usuário
├── get_total_infractions: Conta total
├── get_server_infractions: Lista por servidor
├── get_warns_count: Conta avisos
└── Todos com error handling

EMBEDS GERADOS:
===============

Sucesso:
- Título com emoji e ação
- Descrição com usuário, motivo, mod
- Thumbnail com avatar
- Cor apropriada por ação

Erro:
- Título com problema
- Descrição explicando por quê
- Cor vermelha

LOGGING:
========

Cada ação gera log:
✅ kick: "Kick: {user} por {mod}"
✅ ban: "Ban: {user} por {mod}"
✅ mute: "Mute: {user} por {duration}m"
✅ warn: "Aviso: {user} (#{total})"
✅ clear: "Limpeza: {count} mensagens"

Logs armazenados em: logs/resenhabot.log

QUERYING INFRAÇÕES:
===================

Repository methods:

get_user_infractions(discord_id, server_id)
→ Retorna lista de últimas 20 infrações

get_total_infractions(discord_id, server_id)
→ Retorna número total

get_server_infractions(server_id)
→ Retorna últimas 50 do servidor

get_warns_count(discord_id, server_id)
→ Retorna número de avisos

Todas retornam dict:
{
    "id": 123,
    "discord_id": 456,
    "server_id": 789,
    "infraction_type": "warn",
    "reason": "motivo",
    "moderator_id": 111,
    "created_at": "2026-06-28 12:34:56"
}

FUTUROS COMANDOS (Fase 9+):
============================

Possíveis adições:
- /infrações <user> - Visualizar infrações
- /infração_remover <id> - Remover infração
- /mutar_voz <user> - Mute apenas em voz
- /deban <user> - Remover banição
- /avisos_reset <user> - Resetar avisos
- /logs <canal> - Audit log channel
- /mod_config - Configurar moderação

INTEGRAÇÃO:
===========

✅ Database: InfractionRepository integrada
✅ Logger: Logging em arquivo
✅ Embeds: EmbedHelper para consistency
✅ Permissions: discord.py checks
✅ Timing: discord.utils.utcnow() para precisão
✅ Error handling: Try/except/finally robusto

NOTAS IMPORTANTES:
==================

1. Verificação de permissões é em TWO LEVELS:
   - @app_commands.checks.has_permissions (Discord side)
   - Verificação adicional em role (safety)

2. Timeout usa: timed_out_until (novo discord.py)

3. Ban pode limpar até 7 dias de mensagens

4. Mute pode durar até 28 dias

5. All infractions are logged forever

6. Sistema de avisos é PROGRESSIVO
   (3 avisos = alerta automático)

TESTES RECOMENDADOS:
====================

[ ] /kick com test user
[ ] /ban com test user
[ ] /mute por 5 minutos
[ ] /limpar 5 mensagens
[ ] /avisar mínimo 3x mesmo user
[ ] Verificar que DB tem infrações
[ ] Tentar kick a si mesmo (erro)
[ ] Tentar kick superior (erro)
[ ] Verificar logs no arquivo
[ ] /kick sem permissão (erro)

PRONTO PARA FASE 9? ✨
"""
