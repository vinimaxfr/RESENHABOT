"""
Cog com comandos de gerenciamento de contexto da IA.
"""

import discord
from discord.ext import commands
from discord import app_commands
from database.context_repository import ContextRepository
from utils.logger import setup_logger
from utils.embeds import EmbedHelper
from datetime import datetime

logger = setup_logger(__name__)


class AIContextCog(commands.Cog):
    """Cog com comandos de gerenciamento de contexto."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        # Compartilhar o mesmo repository com AICog
        self.context_repo = ContextRepository()

    @app_commands.command(
        name="contexto_limpar",
        description="Limpa o histórico de contexto da IA"
    )
    async def clear_context_command(self, interaction: discord.Interaction) -> None:
        """Limpa o contexto."""
        await interaction.response.defer()

        try:
            await self.context_repo.clear_context(
                interaction.user.id,
                interaction.guild.id
            )

            embed = EmbedHelper.success(
                "Contexto Limpo",
                "O histórico de conversa com a IA foi limpo! 🧹\n\n"
                "A IA esquecerá das conversas anteriores.",
                interaction.user
            )

            await interaction.followup.send(embed=embed)
            logger.info(f"Contexto limpo para {interaction.user.display_name}")

        except Exception as e:
            logger.error(f"Erro ao limpar contexto: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="contexto_stats",
        description="Ver estatísticas do contexto com a IA"
    )
    async def context_stats_command(self, interaction: discord.Interaction) -> None:
        """Visualiza estatísticas do contexto."""
        await interaction.response.defer()

        try:
            stats = await self.context_repo.get_stats(
                interaction.user.id,
                interaction.guild.id
            )

            embed = discord.Embed(
                title="📊 Estatísticas de Contexto",
                color=discord.Color.blurple(),
                timestamp=datetime.now()
            )

            embed.add_field(
                name="💬 Interações Totais",
                value=str(stats["total_interactions"]),
                inline=True
            )

            embed.add_field(
                name="📝 Mensagens em Memória",
                value=f"{stats['messages_count']} / 10",
                inline=True
            )

            last_interaction = datetime.fromisoformat(stats["last_interaction"])
            embed.add_field(
                name="⏰ Última Interação",
                value=f"<t:{int(last_interaction.timestamp())}:R>",
                inline=False
            )

            embed.set_footer(text=f"ID: {interaction.user.id}", icon_url=interaction.user.avatar.url)

            await interaction.followup.send(embed=embed)
            logger.info(f"Stats de contexto visualizados para {interaction.user.display_name}")

        except Exception as e:
            logger.error(f"Erro ao obter stats: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(AIContextCog(bot))
