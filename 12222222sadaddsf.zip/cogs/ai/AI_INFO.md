"""
Documentação do Sistema de IA.

COMO FUNCIONA:
==============

1. MENÇÃO DO BOT
   - Quando você menciona o Resenha Bot (@Resenha Bot), ele responde
   - Exemplo: "@Resenha Bot Qual é tua música favorita?"

2. CONTEXTO
   - A IA mantém as últimas 10 mensagens de conversa
   - Contexto é separado por usuário e servidor
   - A IA "lembra" do que você disse antes

3. PERSONALIDADE
   - Engraçada e descontraída
   - Adora Roblox 🎮
   - Conhece memes
   - Natural como um amigo
   - Pode brincar e ser sarcástica

4. RECURSOS
   - Responde em português
   - Usa emojis frequentemente
   - Faz perguntas para manter conversa
   - Conhecimento geral

COMANDOS RELACIONADOS:
======================

/contexto_limpar - Limpa o histórico (IA esquecerá)
/contexto_stats - Ver estatísticas de interações

EXEMPLO DE USO:
===============

Você: @Resenha Bot Oi! Como vai?
IA: Oi! Tudo bem? Acabei de acordar do sleep 😴
   Tava pensando em Roblox, conhece?

Você: @Resenha Bot Sim! Qual teu jogo favorito?
IA: Cara, Adopt Me é vício demais! 🐕
   Mas tb gosto de Tower Defense Simulator
   Qual é o seu?

CONFIGURAÇÃO:
=============

Certifique-se de ter:
- OPENAI_API_KEY configurada em .env
- Seu bot mencionado corretamente

LIMITES:
========

- Respostas limitadas a 200 tokens (~150 palavras)
- Histórico: últimas 10 mensagens
- Timeout: 30 segundos
- Temperatura: 0.8 (criativo mas consistente)

NOTAS:
======

- A IA NÃO responde automaticamente (só quando mencionada)
- Contexto reseta se usar /contexto_limpar
- Cada usuário tem contexto separado
- A IA respeita as rules do servidor
"""
