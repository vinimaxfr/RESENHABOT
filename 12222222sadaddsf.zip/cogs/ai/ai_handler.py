"""
Cog principal de IA — Resenha Bot.
Modo livre inteligente: lê contexto, decide se vale entrar, cooldowns por canal.
"""

import discord
from discord.ext import commands
import aiohttp
import asyncio
import random
import time
from config.settings import Settings
from database.context_repository import ContextRepository
from cogs.ai.prompts import get_system_prompt, get_context_prompt
from utils.logger import setup_logger

logger = setup_logger(__name__)

# ─────────────────────────────────────────────
#  CONFIGURAÇÃO DO MODO LIVRE
#  Ajuste esses valores pra calibrar o bot
# ─────────────────────────────────────────────

# Cooldown mínimo entre respostas espontâneas por canal (segundos)
COOLDOWN_CHAT = 120        # 2 min — evita spam no mesmo canal

# Chance base de entrar na conversa (bem baixa)
CHANCE_BASE = 0.03         # 3% — raro por padrão

# Multiplicadores por contexto
MULT_GATILHO_FRACO  = 2.0  # palavras comuns → 6%
MULT_GATILHO_FORTE  = 4.0  # palavras quentes → 12%
MULT_MUITAS_MSGS    = 1.5  # conversa ativa → aumenta um pouco
CHANCE_MAX          = 0.15  # teto absoluto: nunca mais que 15%

# Mínimo de mensagens recentes pra considerar "conversa ativa"
MSGS_ATIVAS_MIN = 3

# Gatilhos fracos — assuntos gerais
GATILHOS_FRACOS = [
    "kkk", "kkkk", "haha", "rs", "lol",
    "cara", "mano", "véi", "vei", "gente",
    "nossa", "serio", "sério", "imagina",
    "que isso", "verdade", "faz sentido",
    "concordo", "discordo", "mas",
]

# Gatilhos fortes — temas que o bot domina
GATILHOS_FORTES = [
    "roblox", "minecraft", "valorant", "cs2", "lol", "free fire",
    "meme", "viral", "trend", "tiktok", "twitter", "instagram",
    "ia ", "inteligência artificial", "chatgpt", "claude", "gemini",
    "discord", "servidor", "bot", "game", "jogo",
    "2025", "2026", "notícia", "aconteceu",
    "skill issue", "sigma", "rizz", "slay", "lowkey",
    "deepfake", "stream", "twitch", "youtube",
]


class AICog(commands.Cog):
    """Cog com IA contextual — modo livre calibrado."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.context_repo = ContextRepository()
        self.session: aiohttp.ClientSession = None
        # canal_id → timestamp da última resposta espontânea
        self._cooldowns: dict[int, float] = {}
        # canal_id → lista dos últimos conteúdos (pra analisar contexto)
        self._historico_recente: dict[int, list[str]] = {}

    async def cog_load(self) -> None:
        self.session = aiohttp.ClientSession()

    async def cog_unload(self) -> None:
        if self.session:
            await self.session.close()

    # ─── Cooldown ─────────────────────────────────────────
    def _em_cooldown(self, channel_id: int) -> bool:
        ultimo = self._cooldowns.get(channel_id, 0)
        return (time.time() - ultimo) < COOLDOWN_CHAT

    def _set_cooldown(self, channel_id: int) -> None:
        self._cooldowns[channel_id] = time.time()

    # ─── Análise de contexto ──────────────────────────────
    def _registrar_mensagem(self, channel_id: int, content: str) -> None:
        """Guarda as últimas 10 mensagens de cada canal."""
        if channel_id not in self._historico_recente:
            self._historico_recente[channel_id] = []
        hist = self._historico_recente[channel_id]
        hist.append(content.lower())
        if len(hist) > 10:
            hist.pop(0)

    def _calcular_chance(self, channel_id: int, content: str) -> float:
        """
        Calcula a chance real de responder espontaneamente.
        Leva em conta: gatilhos na msg atual + tema recorrente no histórico.
        """
        content_lower = content.lower()
        hist = self._historico_recente.get(channel_id, [])

        chance = CHANCE_BASE

        # Verifica gatilhos na mensagem atual
        tem_forte = any(g in content_lower for g in GATILHOS_FORTES)
        tem_fraco = any(g in content_lower for g in GATILHOS_FRACOS)

        if tem_forte:
            chance *= MULT_GATILHO_FORTE
        elif tem_fraco:
            chance *= MULT_GATILHO_FRACO

        # Verifica se o tema forte aparece no histórico recente (assunto recorrente)
        if hist and tem_forte:
            recorrencias = sum(
                1 for msg in hist
                if any(g in msg for g in GATILHOS_FORTES)
            )
            if recorrencias >= MSGS_ATIVAS_MIN:
                chance *= MULT_MUITAS_MSGS  # conversa ativa sobre tema quente

        # Teto absoluto
        return min(chance, CHANCE_MAX)

    def _deve_responder(self, channel_id: int, content: str) -> bool:
        chance = self._calcular_chance(channel_id, content)
        return random.random() < chance

    # ─── Listener principal ───────────────────────────────
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot:
            return
        if message.content.startswith(Settings.BOT_PREFIX):
            return

        foi_mencionado = self.bot.user in message.mentions
        eh_dm = isinstance(message.channel, discord.DMChannel)

        # Registra no histórico do canal (sempre)
        if message.guild:
            self._registrar_mensagem(message.channel.id, message.content)

        # ── DM → sempre responde ────────────────────────
        if eh_dm:
            await self._responder(message, espontaneo=False)
            return

        # ── Mencionado → sempre responde ────────────────
        if foi_mencionado:
            await self._responder(message, espontaneo=False)
            return

        # ── Modo livre ───────────────────────────────────
        if not message.guild:
            return
        if len(message.content) < 8:
            return
        if self._em_cooldown(message.channel.id):
            return
        if self._deve_responder(message.channel.id, message.content):
            await self._responder(message, espontaneo=True)

    # ─── Resposta ─────────────────────────────────────────
    async def _responder(self, message: discord.Message, espontaneo: bool) -> None:
        try:
            async with message.channel.typing():
                guild_id = message.guild.id if message.guild else 0
                content = message.content.replace(
                    f"<@{self.bot.user.id}>", ""
                ).strip()

                await self.context_repo.add_message(
                    discord_id=message.author.id,
                    server_id=guild_id,
                    author_id=message.author.id,
                    author_name=message.author.display_name,
                    content=content
                )

                context_string = await self.context_repo.get_context_string(
                    message.author.id, guild_id
                )

                # Prompt extra pra resposta espontânea: curto e no tema
                system = get_system_prompt()
                if espontaneo:
                    system += (
                        "\n\nVocê está ENTRANDO ESPONTANEAMENTE na conversa — ninguém te chamou. "
                        "Faça UM comentário curto (máx 1-2 linhas), engraçado e DIRETAMENTE ligado "
                        "ao que foi dito. Não se apresente. Não diga que você é um bot. "
                        "Aja como se fosse só mais alguém da conversa que teve uma reação."
                    )

                response = await self._call_groq(
                    context_string, message.author.display_name, content, system
                )

                if not response:
                    if espontaneo:
                        return  # silencia — não spama erro
                    response = "Hmm, parece que tive um problema... 😅"

                await self.context_repo.add_message(
                    discord_id=message.author.id,
                    server_id=guild_id,
                    author_id=self.bot.user.id,
                    author_name="Resenha Bot",
                    content=response
                )

                if espontaneo:
                    self._set_cooldown(message.channel.id)

                if len(response) > 2000:
                    for chunk in [response[i:i+2000] for i in range(0, len(response), 2000)]:
                        await message.reply(chunk, mention_author=not espontaneo)
                else:
                    await message.reply(response, mention_author=not espontaneo)

                logger.info(f"IA {'[espontâneo]' if espontaneo else '[menção]'} → {message.author.display_name}")

        except Exception as e:
            logger.error(f"Erro ao responder: {e}")
            if not espontaneo:
                try:
                    await message.reply("Desculpa, tive um probleminha aqui 😢", mention_author=True)
                except Exception:
                    pass

    async def _call_groq(
        self, context: str, user_name: str, message: str, system: str
    ) -> str:
        """Chama a API Groq."""
        try:
            if not Settings.GROQ_API_KEY:
                logger.error("GROQ_API_KEY não configurada!")
                return ""

            payload = {
                "model": "llama-3.1-8b-instant",
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": get_context_prompt(context, user_name, message)}
                ],
                "temperature": 0.85,
                "max_tokens": 250,
                "top_p": 0.9,
            }

            async with self.session.post(
                "https://api.groq.com/openai/v1/chat/completions",
                json=payload,
                headers={
                    "Authorization": f"Bearer {Settings.GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                timeout=aiohttp.ClientTimeout(total=30)
            ) as resp:
                if resp.status != 200:
                    logger.error(f"Erro Groq: {await resp.json()}")
                    return ""
                data = await resp.json()
                return data["choices"][0]["message"]["content"].strip()

        except asyncio.TimeoutError:
            logger.error("Timeout Groq")
            return ""
        except Exception as e:
            logger.error(f"Erro Groq: {e}")
            return ""


async def setup(bot: commands.Bot) -> None:
    cog = AICog(bot)
    await cog.cog_load()
    await bot.add_cog(cog)
