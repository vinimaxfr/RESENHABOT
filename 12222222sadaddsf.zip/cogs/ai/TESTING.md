"""
Teste de funcionalidade da IA.

Este arquivo documenta como testar a IA quando o bot estiver rodando.

PASSOS DE TESTE:
================

1. PREPARAÇÃO
   - Certifique-se que OPENAI_API_KEY está em .env
   - Execute: python main.py
   - Aguarde: "✅ Bot inicializado com sucesso!"

2. TESTE BÁSICO
   - Vá para um canal do Discord
   - Digite: @Resenha Bot Oi tudo bem?
   - Resultado: Bot responde com mensagem amigável

3. TESTE DE CONTEXTO
   - Digite: @Resenha Bot Qual é teu nome?
   - Bot: Sou a Resenha Bot!
   - Digite: @Resenha Bot E o que você faz?
   - Bot: Responde lembrando que é a Resenha Bot
   - (Note que o bot "lembra" da conversa anterior)

4. TESTE DE PERSONALIDADE
   - Digite: @Resenha Bot Me fale sobre Roblox
   - Bot: Deve responder entusiasticamente sobre Roblox
   - Digite: @Resenha Bot Qual meme você conhece?
   - Bot: Deve fazer referências a memes

5. TESTE DE CONTEXTO STATS
   - Digite: /contexto_stats
   - Resultado: Mostra número de interações

6. TESTE DE LIMPEZA
   - Digite: /contexto_limpar
   - Digite: /contexto_stats
   - Resultado: Contador de interações zera

ESPERADO:
=========

✅ Bot responde quando mencionado
✅ Bot usa emojis
✅ Bot faz piadas
✅ Bot mantém contexto (10 mensagens)
✅ Bot menciona Roblox quando possível
✅ Bot usa linguagem natural
✅ Respostas em português
✅ Timeout em 30 segundos (se IA demorar)

POSSÍVEIS ERROS:
================

❌ "Hmm, parece que tive um problema..."
   → Cheque OPENAI_API_KEY em .env
   → Verifique limite de requisições OpenAI

❌ Bot não responde
   → Verifique se foi mencionado corretamente
   → Verifique logs para erros

❌ Resposta vazia
   → Timeout da API (30s)
   → Erro na requisição OpenAI
   → Cheque logs

LOGS:
=====

Procure por:
- "IA respondeu a {username}" = Sucesso
- "Erro ao responder mensagem" = Erro
- "OPENAI_API_KEY não configurada" = Config faltando
"""
