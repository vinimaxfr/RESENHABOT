"""
Documentação dos Minijogos do Resenha Bot.

Cada minijogo tem prêmios diferentes baseado na dificuldade.
Todos requerem aposta em dinheiro.

MINIJOGOS DISPONÍVEIS:
======================

1. CARA OU COROA (/cara_ou_coroa)
   - Dificuldade: Muito Fácil
   - Chance de vitória: 50%
   - Prêmio: 2x a aposta
   - Descrição: Escolha cara ou coroa e tente acertar!

2. DADO (/dado)
   - Dificuldade: Fácil
   - Chance de vitória: 16.67%
   - Prêmio: 5x a aposta
   - Descrição: Escolha um número de 1-6

3. PEDRA PAPEL TESOURA (/pedra_papel_tesoura)
   - Dificuldade: Fácil
   - Chance de vitória: ~33% (com possibilidade de empate)
   - Prêmio: 2x a aposta
   - Descrição: O clássico jogo de RPS contra o bot

4. ROLETA (/roleta)
   - Dificuldade: Muito Difícil
   - Chance de vitória: 2.7% (1/37)
   - Prêmio: 35x a aposta
   - Descrição: Escolha um número de 0-36

5. QUIZ (/quiz)
   - Dificuldade: Média
   - Chance de vitória: 25%
   - Prêmio: 3x a aposta
   - Descrição: Responda uma pergunta de múltipla escolha
   - Perguntas: 10 opções aleatórias

6. ADIVINHAR NÚMERO (/adivinhar_numero)
   - Dificuldade: Muito Difícil
   - Chance de vitória: 1%
   - Prêmio: 50x a aposta
   - Descrição: Adivinhe o número de 1-100
   - Sistema de dicas incluído

7. BLACKJACK (/blackjack)
   - Dificuldade: Média
   - Chance de vitória: ~40%
   - Prêmio: 2x-2.5x a aposta
   - Descrição: Jogue contra o dealer
   - Blackjack natural: 2.5x
   - Vitória normal: 2x

SISTEMA DE PONTUAÇÃO:
====================
- Cada vitória adiciona +1 ao contador de vitórias em minijogos
- Prêmio em dinheiro é registrado como transação
- Histórico completo disponível

ESTRATÉGIA RECOMENDADA:
=======================
🎯 Para Lucro Rápido:
   - Jogar Cara ou Coroa com apostas pequenas
   - Taxa de vitória alta (50%)
   
💎 Para Grande Vitória:
   - Tentar Roleta ou Adivinhar Número
   - Prêmios massivos (35x, 50x)
   - Risco muito alto

⚖️ Equilibrado:
   - Dado ou Blackjack
   - Prêmios moderados com risco médio

NOTAS:
======
- Você não pode ficar com saldo negativo (validação de saldo)
- Todas as transações são rastreadas
- Cooldowns podem ser adicionados em futuro
- Quiz tem 10 perguntas diferentes
- Blackjack é versão simplificada (sem hit/stand atual)
"""
