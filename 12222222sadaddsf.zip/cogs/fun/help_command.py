"""
Comando de ajuda resumido com todos os comandos.
"""

import discord
from discord.ext import commands
from discord import app_commands
from utils.logger import setup_logger

logger = setup_logger(__name__)


class HelpCog(commands.Cog):
    """Cog com comando de ajuda."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="ajuda", description="Lista TODOS os comandos do bot")
    async def help_command(self, interaction: discord.Interaction) -> None:
        """Mostra ajuda com todos os comandos."""
        await interaction.response.defer()

        try:
            embed = discord.Embed(
                title="🤖 Resenha Bot - Ajuda Completa",
                description="Lista de TODOS os comandos disponíveis",
                color=discord.Color.blurple()
            )

            # Profile & Ranking
            embed.add_field(
                name="👤 Profile & Ranking",
                value="`/perfil [user]` - Ver perfil\n"
                      "`/ranking [campo]` - Top 10 (money, xp, palo_best, wins, msgs)\n"
                      "`/ranking_infrações` - Top infrações\n"
                      "`/ranking_moderadores` - Top mods",
                inline=False
            )

            # Palo
            embed.add_field(
                name="📏 Medir Palo",
                value="`/medir_palo` - 1x/dia, ganha evento especial\n"
                      "`/historico_palo` - Ver histórico",
                inline=False
            )

            # Economy
            embed.add_field(
                name="💰 Economia",
                value="`/daily` - Recompensa diária ($1000 base)\n"
                      "`/carteira [user]` - Ver dinheiro\n"
                      "`/transferir @user <valor>` - Enviar dinheiro\n"
                      "`/roubo @user` - Roubar 10-30%\n"
                      "`/trabalho` - Ganhar $\n"
                      "`/loja` - Ver itens\n"
                      "`/comprar <item> [qty]` - Comprar\n"
                      "`/inventario` - Seu inventário",
                inline=False
            )

            # Minijogos
            embed.add_field(
                name="🎮 Minijogos (7 disponíveis)",
                value="`/cara_ou_coroa` - 50%, 2x\n"
                      "`/dado` - 16.67%, 5x\n"
                      "`/pedra_papel_tesoura` - 33%, 2x\n"
                      "`/roleta` - 2.7%, 35x (arriscado!)\n"
                      "`/quiz` - 25%, 3x\n"
                      "`/adivinhar_numero` - 1%, 50x (muito arriscado!)\n"
                      "`/blackjack` - 40%, 2-2.5x",
                inline=False
            )

            # IA
            embed.add_field(
                name="🤖 IA & Contexto",
                value="`@Resenha Bot [mensagem]` - Conversar com IA\n"
                      "`/contexto_limpar` - Apagar histórico\n"
                      "`/contexto_stats` - Ver stats de conversa",
                inline=False
            )

            # Voz
            embed.add_field(
                name="🎙️ Voz",
                value="`/entrar` - Bot entra em call\n"
                      "`/sair` - Bot sai de call\n"
                      "`/status_voz` - Status da conexão",
                inline=False
            )

            # Moderação
            embed.add_field(
                name="👮 Moderação (Admin only)",
                value="`/kick @user [motivo]` - Remove\n"
                      "`/ban @user [motivo]` - Bane\n"
                      "`/mute @user <mins>` - Silencia\n"
                      "`/timeout @user <mins>` - Timeout\n"
                      "`/limpar <qty>` - Delete msgs\n"
                      "`/avisar @user` - Sistema de avisos",
                inline=False
            )

            # Footer
            embed.set_footer(text="Use /ajuda para rever | Dúvidas? Leia o README!")
            embed.set_thumbnail(url=self.bot.user.avatar.url if self.bot.user else None)

            await interaction.followup.send(embed=embed)
            logger.info(f"Ajuda visualizada por {interaction.user.display_name}")

        except Exception as e:
            logger.error(f"Erro ao mostrar ajuda: {e}")
            embed = discord.Embed(
                title="Erro",
                description=f"Erro: {str(e)}",
                color=discord.Color.red()
            )
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(HelpCog(bot))
