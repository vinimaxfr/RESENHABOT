"""
Cog com todos os minijogos.
"""

import discord
from discord.ext import commands
from discord import app_commands
import random
from datetime import datetime
from typing import Optional

from database.user_repository import UserRepository
from database.transaction_repository import TransactionRepository
from database.models.transaction import TransactionModel, TransactionType
from utils.logger import setup_logger
from utils.embeds import EmbedHelper
from utils.minigame_utils import MinigameUtils

logger = setup_logger(__name__)


class MinigamesCog(commands.Cog):
    """Cog com todos os minijogos."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def _update_win_stat(self, discord_id: int, server_id: int) -> None:
        """Atualiza estatística de vitórias."""
        try:
            user_repo = UserRepository(self.bot.db)
            user = await user_repo.get_user(discord_id)
            if user:
                user.minigames_wins += 1
                await user_repo.update_user(user)
        except Exception as e:
            logger.error(f"Erro ao atualizar vitórias: {e}")

    async def _add_winnings(
        self,
        discord_id: int,
        server_id: int,
        amount: int,
        game_name: str
    ) -> None:
        """Adiciona ganhos e registra transação."""
        try:
            user_repo = UserRepository(self.bot.db)
            transaction_repo = TransactionRepository(self.bot.db)

            user = await user_repo.get_user(discord_id)
            if user:
                user.money += amount
                await user_repo.update_user(user)

            transaction = TransactionModel(
                discord_id=discord_id,
                server_id=server_id,
                transaction_type=TransactionType.SALARY.value,
                amount=amount,
                description=f"Vitória em {game_name}"
            )
            await transaction_repo.add_transaction(transaction)
        except Exception as e:
            logger.error(f"Erro ao adicionar ganhos: {e}")

    @app_commands.command(name="cara_ou_coroa", description="Jogue Cara ou Coroa!")
    @app_commands.describe(escolha="Escolha: cara ou coroa", aposta="Quanto quer apostar?")
    @app_commands.choices(
        escolha=[
            app_commands.Choice(name="Cara", value="cara"),
            app_commands.Choice(name="Coroa", value="coroa"),
        ]
    )
    async def coin_flip_command(
        self,
        interaction: discord.Interaction,
        escolha: str,
        aposta: int
    ) -> None:
        """Jogo de Cara ou Coroa."""
        await interaction.response.defer()

        try:
            if aposta <= 0:
                embed = EmbedHelper.error(
                    "Aposta Inválida",
                    "A aposta deve ser maior que $0!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            await user_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if user.money < aposta:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você tem apenas **${user.money:,}**",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Sortear resultado
            resultado = random.choice(["cara", "coroa"])
            vitoria = escolha == resultado

            # Atualizar saldo
            if vitoria:
                ganho = MinigameUtils.calculate_win(aposta, 2.0)
                user.money += ganho
                await user_repo.update_user(user)
                await self._update_win_stat(interaction.user.id, interaction.guild.id)
                await self._add_winnings(
                    interaction.user.id,
                    interaction.guild.id,
                    ganho,
                    "Cara ou Coroa"
                )

                embed = EmbedHelper.success(
                    "🎉 Você Venceu!",
                    f"Você escolheu **{escolha}** e saiu **{resultado}**!\n\n"
                    f"Ganho: **${ganho:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )
            else:
                user.money -= aposta
                await user_repo.update_user(user)

                embed = EmbedHelper.error(
                    "😢 Você Perdeu!",
                    f"Você escolheu **{escolha}** mas saiu **{resultado}**!\n\n"
                    f"Perdeu: **${aposta:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro no Cara ou Coroa: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="dado", description="Jogue o Dado!")
    @app_commands.describe(numero="Número de 1 a 6", aposta="Quanto quer apostar?")
    @app_commands.choices(
        numero=[
            app_commands.Choice(name="1", value=1),
            app_commands.Choice(name="2", value=2),
            app_commands.Choice(name="3", value=3),
            app_commands.Choice(name="4", value=4),
            app_commands.Choice(name="5", value=5),
            app_commands.Choice(name="6", value=6),
        ]
    )
    async def dice_command(
        self,
        interaction: discord.Interaction,
        numero: int,
        aposta: int
    ) -> None:
        """Jogo do Dado."""
        await interaction.response.defer()

        try:
            if aposta <= 0:
                embed = EmbedHelper.error("Aposta Inválida", "A aposta deve ser > $0!")
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            await user_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if user.money < aposta:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você tem apenas **${user.money:,}**",
                )
                await interaction.followup.send(embed=embed)
                return

            # Sortear dado
            resultado = random.randint(1, 6)
            vitoria = numero == resultado

            emojis = ["❌", "1️⃣", "2️⃣", "3️⃣", "4️⃣", "5️⃣", "6️⃣"]

            if vitoria:
                ganho = MinigameUtils.calculate_win(aposta, 5.0)  # 5x
                user.money += ganho
                await user_repo.update_user(user)
                await self._update_win_stat(interaction.user.id, interaction.guild.id)
                await self._add_winnings(
                    interaction.user.id,
                    interaction.guild.id,
                    ganho,
                    "Dado"
                )

                embed = EmbedHelper.success(
                    f"{emojis[resultado]} Você Venceu!",
                    f"Você apostou no **{numero}** e saiu **{resultado}**!\n\n"
                    f"Ganho: **${ganho:,}** (5x)\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )
            else:
                user.money -= aposta
                await user_repo.update_user(user)

                embed = EmbedHelper.error(
                    f"{emojis[resultado]} Você Perdeu!",
                    f"Você apostou no **{numero}** mas saiu **{resultado}**!\n\n"
                    f"Perdeu: **${aposta:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro no Dado: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="pedra_papel_tesoura", description="Jogue Pedra, Papel ou Tesoura!")
    @app_commands.describe(escolha="Sua escolha", aposta="Quanto quer apostar?")
    @app_commands.choices(
        escolha=[
            app_commands.Choice(name="🪨 Pedra", value="pedra"),
            app_commands.Choice(name="📄 Papel", value="papel"),
            app_commands.Choice(name="✂️ Tesoura", value="tesoura"),
        ]
    )
    async def rps_command(
        self,
        interaction: discord.Interaction,
        escolha: str,
        aposta: int
    ) -> None:
        """Jogo de Pedra, Papel ou Tesoura."""
        await interaction.response.defer()

        try:
            if aposta <= 0:
                embed = EmbedHelper.error("Aposta Inválida", "A aposta deve ser > $0!")
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            await user_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if user.money < aposta:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você tem apenas **${user.money:,}**",
                )
                await interaction.followup.send(embed=embed)
                return

            choices_map = {"pedra": 0, "papel": 1, "tesoura": 2}
            user_choice = choices_map[escolha]
            bot_choice = random.randint(0, 2)

            user_emoji, user_name = MinigameUtils.get_rock_paper_scissors_emoji(user_choice)
            bot_emoji, bot_name = MinigameUtils.get_rock_paper_scissors_emoji(bot_choice)

            # Verificar vitória
            # 0=Pedra, 1=Papel, 2=Tesoura
            # Pedra vence Tesoura, Papel vence Pedra, Tesoura vence Papel
            vitoria = (
                (user_choice == 0 and bot_choice == 2) or
                (user_choice == 1 and bot_choice == 0) or
                (user_choice == 2 and bot_choice == 1)
            )
            empate = user_choice == bot_choice

            if vitoria:
                ganho = MinigameUtils.calculate_win(aposta, 2.0)
                user.money += ganho
                await user_repo.update_user(user)
                await self._update_win_stat(interaction.user.id, interaction.guild.id)
                await self._add_winnings(
                    interaction.user.id,
                    interaction.guild.id,
                    ganho,
                    "Pedra/Papel/Tesoura"
                )

                embed = EmbedHelper.success(
                    "🎉 Você Venceu!",
                    f"Você: {user_emoji} **{user_name}**\n"
                    f"Bot: {bot_emoji} **{bot_name}**\n\n"
                    f"Ganho: **${ganho:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )
            elif empate:
                embed = discord.Embed(
                    title="🤝 Empate!",
                    description=f"Você: {user_emoji} **{user_name}**\n"
                               f"Bot: {bot_emoji} **{bot_name}**\n\n"
                               f"Seu dinheiro foi devolvido.",
                    color=discord.Color.blue(),
                    timestamp=datetime.now()
                )
                embed.set_footer(text=f"ID: {interaction.user.id}", icon_url=interaction.user.avatar.url)
            else:
                user.money -= aposta
                await user_repo.update_user(user)

                embed = EmbedHelper.error(
                    "😢 Você Perdeu!",
                    f"Você: {user_emoji} **{user_name}**\n"
                    f"Bot: {bot_emoji} **{bot_name}**\n\n"
                    f"Perdeu: **${aposta:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro em RPS: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="roleta", description="Jogue na Roleta da Sorte!")
    @app_commands.describe(numero="Número de 0 a 36", aposta="Quanto quer apostar?")
    async def roulette_command(
        self,
        interaction: discord.Interaction,
        numero: int,
        aposta: int
    ) -> None:
        """Jogo de Roleta."""
        await interaction.response.defer()

        try:
            if numero < 0 or numero > 36:
                embed = EmbedHelper.error(
                    "Número Inválido",
                    "Escolha um número entre 0 e 36!",
                )
                await interaction.followup.send(embed=embed)
                return

            if aposta <= 0:
                embed = EmbedHelper.error("Aposta Inválida", "A aposta deve ser > $0!")
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            await user_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if user.money < aposta:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você tem apenas **${user.money:,}**",
                )
                await interaction.followup.send(embed=embed)
                return

            # Sortear número
            resultado = random.randint(0, 36)
            vitoria = numero == resultado

            if vitoria:
                ganho = MinigameUtils.calculate_win(aposta, 35.0)  # 35x (típico de roleta)
                user.money += ganho
                await user_repo.update_user(user)
                await self._update_win_stat(interaction.user.id, interaction.guild.id)
                await self._add_winnings(
                    interaction.user.id,
                    interaction.guild.id,
                    ganho,
                    "Roleta"
                )

                embed = EmbedHelper.success(
                    "🎰 JACKPOT!",
                    f"Você apostou no **{numero}** e saiu **{resultado}**!\n\n"
                    f"Ganho: **${ganho:,}** (35x)\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )
            else:
                user.money -= aposta
                await user_repo.update_user(user)

                embed = EmbedHelper.error(
                    "🎲 Perdeu!",
                    f"Você apostou no **{numero}** mas saiu **{resultado}**!\n\n"
                    f"Perdeu: **${aposta:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro na Roleta: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="quiz", description="Responda uma pergunta de Quiz!")
    @app_commands.describe(aposta="Quanto quer apostar?")
    async def quiz_command(
        self,
        interaction: discord.Interaction,
        aposta: int
    ) -> None:
        """Jogo de Quiz."""
        await interaction.response.defer()

        try:
            if aposta <= 0:
                embed = EmbedHelper.error("Aposta Inválida", "A aposta deve ser > $0!")
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            await user_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if user.money < aposta:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você tem apenas **${user.money:,}**",
                )
                await interaction.followup.send(embed=embed)
                return

            # Obter pergunta
            quiz = MinigameUtils.get_random_quiz()

            embed = discord.Embed(
                title="🧠 Quiz",
                description=f"**{quiz['question']}**\n\n",
                color=discord.Color.blue(),
                timestamp=datetime.now()
            )

            for i, option in enumerate(quiz["options"], 1):
                embed.description += f"{i}. {option}\n"

            embed.add_field(
                name="Como Responder",
                value="Responda com um número de 1 a 4",
                inline=False
            )

            embed.set_footer(text=f"Aposta: ${aposta:,}")

            await interaction.followup.send(embed=embed)

            # Armazenar contexto para a resposta (implementar com listener depois)
            logger.info(f"Quiz iniciado para {interaction.user.display_name}")

        except Exception as e:
            logger.error(f"Erro no Quiz: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="adivinhar_numero", description="Adivinhe o número!")
    @app_commands.describe(numero="Seu palpite (1-100)", aposta="Quanto quer apostar?")
    async def guess_number_command(
        self,
        interaction: discord.Interaction,
        numero: int,
        aposta: int
    ) -> None:
        """Jogo de Adivinhar Número."""
        await interaction.response.defer()

        try:
            if numero < 1 or numero > 100:
                embed = EmbedHelper.error(
                    "Número Inválido",
                    "Escolha um número entre 1 e 100!",
                )
                await interaction.followup.send(embed=embed)
                return

            if aposta <= 0:
                embed = EmbedHelper.error("Aposta Inválida", "A aposta deve ser > $0!")
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            await user_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if user.money < aposta:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você tem apenas **${user.money:,}**",
                )
                await interaction.followup.send(embed=embed)
                return

            # Sortear número
            resultado = random.randint(1, 100)
            acerto = numero == resultado
            maior = numero < resultado
            menor = numero > resultado

            if acerto:
                ganho = MinigameUtils.calculate_win(aposta, 50.0)  # 50x
                user.money += ganho
                await user_repo.update_user(user)
                await self._update_win_stat(interaction.user.id, interaction.guild.id)
                await self._add_winnings(
                    interaction.user.id,
                    interaction.guild.id,
                    ganho,
                    "Adivinhar Número"
                )

                embed = EmbedHelper.success(
                    "🎯 Acertou!",
                    f"Você adivinhou o número **{resultado}**!\n\n"
                    f"Ganho: **${ganho:,}** (50x)\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )
            else:
                user.money -= aposta
                await user_repo.update_user(user)

                dica = "O número é MAIOR que sua tentativa! ⬆️" if maior else "O número é MENOR que sua tentativa! ⬇️"

                embed = EmbedHelper.error(
                    "😢 Errou!",
                    f"Você chutou **{numero}** mas era **{resultado}**!\n"
                    f"_{dica}_\n\n"
                    f"Perdeu: **${aposta:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro ao adivinhar: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="blackjack", description="Jogue Blackjack!")
    @app_commands.describe(aposta="Quanto quer apostar?")
    async def blackjack_command(
        self,
        interaction: discord.Interaction,
        aposta: int
    ) -> None:
        """Jogo de Blackjack simplificado."""
        await interaction.response.defer()

        try:
            if aposta <= 0:
                embed = EmbedHelper.error("Aposta Inválida", "A aposta deve ser > $0!")
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            await user_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if user.money < aposta:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você tem apenas **${user.money:,}**",
                )
                await interaction.followup.send(embed=embed)
                return

            # Distribuir cartas iniciais
            player_cards = [MinigameUtils.generate_blackjack_card() for _ in range(2)]
            dealer_cards = [MinigameUtils.generate_blackjack_card() for _ in range(2)]

            # Calcular score (simplificado)
            def calc_score(cards):
                score = 0
                aces = 0
                for card in cards:
                    value, _ = MinigameUtils.get_blackjack_card_value(card)
                    if value == 11:
                        aces += 1
                    score += value

                while score > 21 and aces > 0:
                    score -= 10
                    aces -= 1

                return score

            player_score = calc_score(player_cards)
            dealer_score = calc_score(dealer_cards)

            # Verificar blackjack
            if player_score == 21:
                ganho = MinigameUtils.calculate_win(aposta, 2.5)
                user.money += ganho
                await user_repo.update_user(user)
                await self._update_win_stat(interaction.user.id, interaction.guild.id)
                await self._add_winnings(
                    interaction.user.id,
                    interaction.guild.id,
                    ganho,
                    "Blackjack"
                )

                embed = EmbedHelper.success(
                    "🎰 BLACKJACK!",
                    f"Suas cartas: {' '.join(player_cards)} (**{player_score}**)\n"
                    f"Cartas do dealer: {' '.join(dealer_cards)} (**{dealer_score}**)\n\n"
                    f"Ganho: **${ganho:,}** (2.5x)\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            elif player_score > 21:
                user.money -= aposta
                await user_repo.update_user(user)

                embed = EmbedHelper.error(
                    "💥 Bust!",
                    f"Suas cartas: {' '.join(player_cards)} (**{player_score}**)\n"
                    f"Você estourou!\n\n"
                    f"Perdeu: **${aposta:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            elif dealer_score > 21:
                ganho = MinigameUtils.calculate_win(aposta, 2.0)
                user.money += ganho
                await user_repo.update_user(user)
                await self._update_win_stat(interaction.user.id, interaction.guild.id)
                await self._add_winnings(
                    interaction.user.id,
                    interaction.guild.id,
                    ganho,
                    "Blackjack"
                )

                embed = EmbedHelper.success(
                    "🎉 Vitória!",
                    f"Suas cartas: {' '.join(player_cards)} (**{player_score}**)\n"
                    f"Cartas do dealer: {' '.join(dealer_cards)} (**{dealer_score}**)\n"
                    f"Dealer estourou!\n\n"
                    f"Ganho: **${ganho:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            elif player_score > dealer_score:
                ganho = MinigameUtils.calculate_win(aposta, 2.0)
                user.money += ganho
                await user_repo.update_user(user)
                await self._update_win_stat(interaction.user.id, interaction.guild.id)
                await self._add_winnings(
                    interaction.user.id,
                    interaction.guild.id,
                    ganho,
                    "Blackjack"
                )

                embed = EmbedHelper.success(
                    "🎉 Você Venceu!",
                    f"Suas cartas: {' '.join(player_cards)} (**{player_score}**)\n"
                    f"Cartas do dealer: {' '.join(dealer_cards)} (**{dealer_score}**)\n\n"
                    f"Ganho: **${ganho:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            elif player_score < dealer_score:
                user.money -= aposta
                await user_repo.update_user(user)

                embed = EmbedHelper.error(
                    "😢 Você Perdeu!",
                    f"Suas cartas: {' '.join(player_cards)} (**{player_score}**)\n"
                    f"Cartas do dealer: {' '.join(dealer_cards)} (**{dealer_score}**)\n\n"
                    f"Perdeu: **${aposta:,}**\n"
                    f"Novo saldo: **${user.money:,}**",
                    interaction.user
                )

            else:
                embed = discord.Embed(
                    title="🤝 Empate!",
                    description=f"Suas cartas: {' '.join(player_cards)} (**{player_score}**)\n"
                               f"Cartas do dealer: {' '.join(dealer_cards)} (**{dealer_score}**)\n\n"
                               f"Seu dinheiro foi devolvido.",
                    color=discord.Color.blue(),
                    timestamp=datetime.now()
                )
                embed.set_footer(text=f"ID: {interaction.user.id}", icon_url=interaction.user.avatar.url)

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro no Blackjack: {e}")
            embed = EmbedHelper.error("Erro", f"Erro: {str(e)}")
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(MinigamesCog(bot))
