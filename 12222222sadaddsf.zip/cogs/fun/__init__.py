"""
Cogs de diversão, perfil do usuário e minijogos.
"""

from .profile import ProfileCog
from .medir_palo import MedirPaloCog
from .minigames import MinigamesCog
from .advanced_ranking import AdvancedRankingCog
from .help_command import HelpCog
from .resenha_humor import ResenhaHumorCog

__all__ = ["ProfileCog", "MedirPaloCog", "MinigamesCog", "AdvancedRankingCog", "HelpCog", "ResenhaHumorCog"]
