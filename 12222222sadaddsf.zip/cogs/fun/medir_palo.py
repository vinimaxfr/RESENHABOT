"""
Cog com o comando /medir_palo.
"""

import discord
from discord.ext import commands
from discord import app_commands
from database.user_repository import UserRepository
from database.measurement_repository import MeasurementRepository
from database.models.measurement import MeasurementModel
from utils.measurement_generator import MeasurementEventGenerator
from utils.logger import setup_logger
from utils.embeds import EmbedHelper
from datetime import datetime, timedelta

logger = setup_logger(__name__)


class MedirPaloCog(commands.Cog):
    """Cog com o comando /medir_palo."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(
        name="medir_palo",
        description="Meça seu palo! (1x por dia)"
    )
    async def medir_palo_command(self, interaction: discord.Interaction) -> None:
        """
        Comando slash para medir o palo.

        Args:
            interaction: Interação do Discord
        """
        await interaction.response.defer()

        try:
            user_id = interaction.user.id
            server_id = interaction.guild.id
            user_repo = UserRepository(self.bot.db)
            measurement_repo = MeasurementRepository(self.bot.db)

            # Criar tabelas se necessário
            await user_repo.create_tables()
            await measurement_repo.create_tables()

            # Obter ou criar usuário
            user = await user_repo.get_or_create_user(
                discord_id=user_id,
                name=interaction.user.display_name
            )

            # Verificar se já foi usado hoje
            last_measurement = await measurement_repo.get_last_measurement(
                user_id,
                server_id
            )

            if last_measurement:
                last_date = datetime.fromisoformat(last_measurement.created_at)
                now = datetime.now()

                # Se a última medição foi no mesmo dia
                if last_date.date() == now.date():
                    hours_left = 24 - (now - last_date).total_seconds() / 3600
                    embed = EmbedHelper.warning(
                        "Limite Diário Atingido",
                        f"Você já mediu seu palo hoje! 📏\n\n"
                        f"Volte em **{hours_left:.1f} horas** para medir novamente.",
                        interaction.user
                    )
                    await interaction.followup.send(embed=embed)
                    return

            # Gerar evento
            event_type, message, gain = MeasurementEventGenerator.generate_event()

            # Calcular novo total
            new_total = max(0, user.palo_current + gain)

            # Atualizar melhor e pior
            if user.palo_best == 0 or new_total > user.palo_best:
                user.palo_best = new_total

            if user.palo_worst == 0 or new_total < user.palo_worst:
                user.palo_worst = new_total

            # Atualizar usuário
            user.palo_current = new_total
            user.palo_last_measurement = datetime.now().isoformat()
            await user_repo.update_user(user)

            # Salvar no histórico
            measurement = MeasurementModel(
                discord_id=user_id,
                server_id=server_id,
                amount_change=gain,
                new_total=new_total,
                event_type=event_type.value,
                message=message
            )
            await measurement_repo.add_measurement(measurement)

            # Criar embed bonito
            emoji = MeasurementEventGenerator.get_event_emoji(event_type)
            color = MeasurementEventGenerator.get_event_color(event_type)

            embed = discord.Embed(
                title=f"{emoji} {message}",
                color=color,
                timestamp=datetime.now()
            )

            # Informações da medição
            gain_str = f"{'+'if gain >= 0 else ''}{gain} cm"
            embed.add_field(
                name="📊 Resultado",
                value=f"**Variação:** {gain_str}\n"
                      f"**Medida Anterior:** {user.palo_current - gain} cm\n"
                      f"**Medida Atual:** {new_total} cm",
                inline=False
            )

            # Estatísticas
            embed.add_field(
                name="📈 Estatísticas",
                value=f"**Melhor:** {user.palo_best} cm\n"
                      f"**Pior:** {user.palo_worst} cm\n"
                      f"**Média:** {(user.palo_current + user.palo_best + user.palo_worst) // 3} cm",
                inline=True
            )

            # Ranking
            rank = await user_repo.get_user_rank(user_id, "palo_best")
            embed.add_field(
                name="🏆 Ranking",
                value=f"**Posição:** #{rank}",
                inline=True
            )

            # Próxima medição
            next_measurement = datetime.now() + timedelta(hours=24)
            embed.add_field(
                name="⏰ Próxima Medição",
                value=f"<t:{int(next_measurement.timestamp())}:R>",
                inline=False
            )

            embed.set_footer(
                text=f"Tipo de evento: {event_type.value.upper()}",
                icon_url=interaction.user.avatar.url
            )

            await interaction.followup.send(embed=embed)

            logger.info(
                f"Medição de {interaction.user.display_name}: "
                f"{gain:+d} cm (Total: {new_total})"
            )

        except Exception as e:
            logger.error(f"Erro ao executar /medir_palo: {e}")
            embed = EmbedHelper.error(
                "Erro",
                f"Ocorreu um erro: {str(e)}",
                interaction.user
            )
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="historico_palo",
        description="Visualize seu histórico de medições"
    )
    @app_commands.describe(limite="Quantidade de medições a mostrar (padrão: 10)")
    async def historico_command(
        self,
        interaction: discord.Interaction,
        limite: int = 10
    ) -> None:
        """
        Visualiza o histórico de medições.

        Args:
            interaction: Interação do Discord
            limite: Número de medições a mostrar
        """
        await interaction.response.defer()

        try:
            user_id = interaction.user.id
            server_id = interaction.guild.id
            measurement_repo = MeasurementRepository(self.bot.db)

            await measurement_repo.create_tables()

            # Obter histórico
            measurements = await measurement_repo.get_user_measurements(
                user_id,
                server_id,
                limit=min(limite, 50)  # Máximo 50
            )

            if not measurements:
                embed = EmbedHelper.info(
                    "Histórico Vazio",
                    "Você ainda não tem nenhuma medição registrada.",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            embed = discord.Embed(
                title=f"📋 Histórico de Medições",
                color=discord.Color.blurple(),
                timestamp=datetime.now()
            )

            # Construir histórico
            history_text = ""
            for idx, measurement in enumerate(measurements, 1):
                date = datetime.fromisoformat(measurement.created_at)
                emoji = MeasurementEventGenerator.get_event_emoji(
                    measurement.event_type
                )

                change_str = f"{'+'if measurement.amount_change >= 0 else ''}{measurement.amount_change}"
                history_text += (
                    f"{idx}. {emoji} **{measurement.new_total} cm** "
                    f"({change_str} cm) - "
                    f"<t:{int(date.timestamp())}:R>\n"
                )

            embed.description = history_text
            embed.set_footer(text=f"Total de medições: {len(measurements)}")

            await interaction.followup.send(embed=embed)

            logger.info(f"Histórico de {interaction.user.display_name} visualizado")

        except Exception as e:
            logger.error(f"Erro ao visualizar histórico: {e}")
            embed = EmbedHelper.error(
                "Erro",
                f"Ocorreu um erro: {str(e)}",
                interaction.user
            )
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(MedirPaloCog(bot))
