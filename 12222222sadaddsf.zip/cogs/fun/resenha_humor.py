"""
Cog de humor e personalidade do Resenha Bot.
Comandos extras divertidos sem precisar de API.
"""

import discord
from discord.ext import commands
from discord import app_commands
import random
import asyncio
from utils.logger import setup_logger

logger = setup_logger(__name__)


# ─────────────────────────────────────────────
#  DADOS DE HUMOR
# ─────────────────────────────────────────────

JULGAMENTOS = [
    ("🗿 sigma silencioso", "você não fala mas quando fala, acerta"),
    ("🤡 palhaço honorário", "o servidor precisava de você"),
    ("💅 main character", "tudo gira em torno de você e você sabe disso"),
    ("🔥 menace to society", "caos ambulante, mas o bom tipo"),
    ("😭 NPC de suporte", "aparece nas cenas importantes dos outros"),
    ("🎭 dramático certificado", "faz de tudo uma novela e a gente ama"),
    ("🧠 big brain do servidor", "às vezes. quando quer."),
    ("👻 fantasma do servidor", "existe mas ninguém tem certeza"),
    ("⚡ speedrunner da vida", "faz tudo errado mas muito rápido"),
    ("🗑️ lore do servidor", "você já virou piada interna. parabéns."),
    ("🎮 robloxiano de coração", "mesmo que negue, a gente sabe"),
    ("💀 causa de morte do servidor", "toda vez que você fala, alguém morre de rir"),
    ("🌙 criatura noturna", "só aparece depois das 22h, suspeito"),
    ("🤝 diplomata do caos", "consegue criar confusão e resolver ao mesmo tempo"),
    ("📊 estatística ambulante", "73% das mensagens do chat foram suas hoje"),
]

VEREDICTOS_8BALL = [
    # Positivos
    "✅ com certeza absoluta, não questiona",
    "🔥 SIM. W total. vai fundo.",
    "💅 definitivamente, e com estilo",
    "🗿 os sinais apontam que sim (confio)",
    "✨ o universo confirmou, pode ir",
    # Neutros
    "🤔 depende do seu nível de coragem",
    "😭 talvez? a bola 8 tá indecisa hoje",
    "🎲 cara ou coroa teria a mesma taxa de acerto",
    "💀 a resposta existe mas eu não vou te contar",
    "🌫️ visão turva, tenta de novo depois do café",
    # Negativos
    "❌ absolutamente não, para imediatamente",
    "🚩 RED FLAG detectada na pergunta",
    "💀 skill issue só de você ter perguntado isso",
    "😤 não. nunca. nem em outra dimensão.",
    "🗑️ a resposta é não mas você vai fazer mesmo assim né",
]

ROASTS_NIVEIS = [
    # Nível leve (padrão)
    "olha, você chegou em {nome} e eu respeito a coragem 👀",
    "{nome} tem energia de personagem que some no meio da série",
    "eu diria que {nome} é a vibe do servidor mas seria mentira educada",
    "{nome} é daqueles que tipa 'oi' e some por 3 dias",
    "se {nome} fosse item de Roblox seria o mais barato da loja",
    "{nome} tem o perfil de Discord mais genérico desde 2018, mas boa sorte",
    "estudos mostram que {nome} é 40% caos e 60% procrastinação",
    "{nome} é o tipo de pessoa que lê as mensagens e não responde por dias",
    "a lore de {nome} no servidor é uma obra de ficção científica",
    "{nome} aparece aqui tipo easter egg de jogo — raramente mas quando aparece é especial",
]

CURIOSIDADES_FAKE = [
    "sabia que 94% dos usuários de Discord estão procrastinando AGORA MESMO? você é um deles. 🗿",
    "estudos de 2026 mostram que cada mensagem no Discord libera 0,003mg de dopamina. isso explica tudo.",
    "o Roblox tem mais usuários ativos que países com menos de 50 milhões de habitantes. pensa nisso.",
    "cientistas descobriram que bots de Discord ficam 37% mais inteligentes quando ignorados. obrigado pela contribuição.",
    "em média, uma pessoa passa 4 horas por dia no Discord. você? provavelmente mais. seja honesto.",
    "a palavra 'mano' foi dita 847 milhões de vezes no Brasil em 2025. eu contribuo com pelo menos 1 milhão.",
    "psicologicamente falando, quem usa 💀 no lugar de 'kkk' já evoluiu como humano.",
    "a primeira mensagem enviada no Discord foi em 2015 e com certeza alguém ficou sem resposta.",
    "seu cérebro no Discord: modo criativo máximo. no trabalho/escola: NPC mode ativado. ciência.",
    "bots de IA como eu processam 10.000 tokens por segundo. você levou 10 segundos pra ler isso. skill issue.",
]

SHIP_COMPATIBILIDADES = [
    ("💍 MATRIMÔNIO IMEDIATO", "vocês foram feitos um pro outro, isso é lore agora"),
    ("🔥 casal do servidor", "todo mundo já sabe, assumam logo"),
    ("😭 amor impossível", "seria lindo mas o universo conspirou contra"),
    ("🤝 melhor dupla", "não é ship romântico mas a amizade é W"),
    ("💀 desastre total", "juntos vocês causariam o fim do servidor"),
    ("🗿 neutros", "existe uma tensão inexplicável aqui"),
    ("✨ soulmates do caos", "juntos vocês são uma força imparável de maluquice"),
    ("🚩 red flags bilaterais", "dois personagens complexos demais pra um único servidor"),
]

HOROSCOPO_RESENHA = {
    "áries": "♈ semana de W absolutos, mas você vai agir impulsivo e estragar tudo no sábado. clássico.",
    "touro": "♉ alguém vai te chamar de teimoso essa semana. eles têm razão. mas você não vai aceitar.",
    "gêmeos": "♊ você vai começar 7 projetos e terminar 0. mas vai ser divertido enquanto durar.",
    "câncer": "♋ semana emocional. você vai chorar num meme. é normal. a gente chora junto.",
    "leão": "♌ você vai querer atenção e vai conseguir. main character ativado. aproveita.",
    "virgem": "♍ você vai corrigir alguém no chat e estar certo mas ninguém vai agradecer. L.",
    "libra": "♎ você vai ficar indeciso sobre uma coisa pequena por 3 dias. depois vai escolher errado.",
    "escorpião": "♏ você sabe segredos do servidor que não deveria saber. e vai continuar sabendo.",
    "sagitário": "♐ você vai falar uma verdade inconveniente sem querer. sem arrependimento.",
    "capricórnio": "♑ grind mode ativado. mas você vai parar pra ver meme de vez em quando. tá liberado.",
    "aquário": "♒ ideia genial essa semana. ninguém vai entender na hora. em 6 meses roubam.",
    "peixes": "♓ você vai viver na cabeça essa semana. o chat vai notar sua ausência espiritual.",
}


class ResenhaHumorCog(commands.Cog):
    """Cog de humor e personalidade Resenha."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    # ─── /julgar ───────────────────────────────────
    @app_commands.command(name="julgar", description="O bot te julga baseado na sua vibe 🗿")
    @app_commands.describe(usuario="Quem vai ser julgado? (deixe vazio pra se auto-julgar)")
    async def julgar(self, interaction: discord.Interaction, usuario: discord.Member = None) -> None:
        alvo = usuario or interaction.user
        titulo, desc = random.choice(JULGAMENTOS)

        embed = discord.Embed(
            title=f"⚖️ VEREDITO OFICIAL",
            description=f"Após análise profunda de {random.randint(3, 99)} milissegundos...",
            color=discord.Color.from_rgb(255, 165, 0)
        )
        embed.add_field(
            name=f"{alvo.display_name} é oficialmente:",
            value=f"## {titulo}\n*\"{desc}\"*",
            inline=False
        )
        embed.set_thumbnail(url=alvo.display_avatar.url)
        embed.set_footer(text="este veredito é baseado em vibes e não pode ser contestado 🗿")
        await interaction.response.send_message(embed=embed)

    # ─── /8ball ────────────────────────────────────
    @app_commands.command(name="8ball", description="A bola mágica do Resenha responde sua pergunta 🎱")
    @app_commands.describe(pergunta="O que você quer saber?")
    async def bola8(self, interaction: discord.Interaction, pergunta: str) -> None:
        resposta = random.choice(VEREDICTOS_8BALL)
        embed = discord.Embed(
            title="🎱 Bola Mágica do Resenha",
            color=discord.Color.dark_purple()
        )
        embed.add_field(name="Sua pergunta:", value=f"*{pergunta}*", inline=False)
        embed.add_field(name="A bola diz:", value=f"**{resposta}**", inline=False)
        embed.set_footer(text=f"perguntado por {interaction.user.display_name}")
        await interaction.response.send_message(embed=embed)

    # ─── /roast ────────────────────────────────────
    @app_commands.command(name="roast", description="Roast leve e sem maldade em alguém 🔥")
    @app_commands.describe(usuario="Quem vai levar o roast?")
    async def roast(self, interaction: discord.Interaction, usuario: discord.Member = None) -> None:
        alvo = usuario or interaction.user
        frase = random.choice(ROASTS_NIVEIS).format(nome=alvo.display_name)

        embed = discord.Embed(
            title="🔥 ROAST CERTIFICADO",
            description=frase,
            color=discord.Color.red()
        )
        embed.set_thumbnail(url=alvo.display_avatar.url)
        embed.set_footer(text="roast com carinho, sem maldade ✌️ | use com responsabilidade")
        await interaction.response.send_message(embed=embed)

    # ─── /curiosidade ──────────────────────────────
    @app_commands.command(name="curiosidade", description="Fato aleatório (pode ou não ser verdade) 🧠")
    async def curiosidade(self, interaction: discord.Interaction) -> None:
        fato = random.choice(CURIOSIDADES_FAKE)
        embed = discord.Embed(
            title="🧠 FATO DO DIA",
            description=fato,
            color=discord.Color.teal()
        )
        embed.set_footer(text="fonte: confie em mim, sou uma IA 🗿 | pode não ser 100% real")
        await interaction.response.send_message(embed=embed)

    # ─── /ship ─────────────────────────────────────
    @app_commands.command(name="ship", description="Analisa a compatibilidade entre duas pessoas 💘")
    @app_commands.describe(pessoa1="Primeira pessoa", pessoa2="Segunda pessoa")
    async def ship(self, interaction: discord.Interaction, pessoa1: discord.Member, pessoa2: discord.Member) -> None:
        porcentagem = random.randint(1, 100)
        titulo, desc = random.choice(SHIP_COMPATIBILIDADES)

        if porcentagem >= 80:
            cor = discord.Color.from_rgb(255, 105, 180)
            emoji_bar = "💗" * (porcentagem // 10)
        elif porcentagem >= 50:
            cor = discord.Color.gold()
            emoji_bar = "💛" * (porcentagem // 10)
        else:
            cor = discord.Color.greyple()
            emoji_bar = "🩶" * (porcentagem // 10)

        embed = discord.Embed(
            title=f"💘 SHIP ANALYSIS",
            color=cor
        )
        embed.add_field(
            name="Casal analisado:",
            value=f"**{pessoa1.display_name}** 💞 **{pessoa2.display_name}**",
            inline=False
        )
        embed.add_field(name="Compatibilidade:", value=f"{emoji_bar}\n**{porcentagem}%**", inline=False)
        embed.add_field(name="Veredito:", value=f"{titulo}\n*{desc}*", inline=False)
        embed.set_footer(text="análise baseada em vibes quânticas e nada mais 🗿")
        await interaction.response.send_message(embed=embed)

    # ─── /horoscopo ────────────────────────────────
    @app_commands.command(name="horoscopo", description="Horóscopo do Resenha — pode não ser real 🔮")
    @app_commands.describe(signo="Qual é o seu signo?")
    @app_commands.choices(signo=[
        app_commands.Choice(name="Áries ♈", value="áries"),
        app_commands.Choice(name="Touro ♉", value="touro"),
        app_commands.Choice(name="Gêmeos ♊", value="gêmeos"),
        app_commands.Choice(name="Câncer ♋", value="câncer"),
        app_commands.Choice(name="Leão ♌", value="leão"),
        app_commands.Choice(name="Virgem ♍", value="virgem"),
        app_commands.Choice(name="Libra ♎", value="libra"),
        app_commands.Choice(name="Escorpião ♏", value="escorpião"),
        app_commands.Choice(name="Sagitário ♐", value="sagitário"),
        app_commands.Choice(name="Capricórnio ♑", value="capricórnio"),
        app_commands.Choice(name="Aquário ♒", value="aquário"),
        app_commands.Choice(name="Peixes ♓", value="peixes"),
    ])
    async def horoscopo(self, interaction: discord.Interaction, signo: str) -> None:
        previsao = HOROSCOPO_RESENHA.get(signo, "signo não reconhecido, mas você vai ter uma semana... existindo. 🗿")
        embed = discord.Embed(
            title=f"🔮 Horóscopo Resenha — {signo.title()}",
            description=previsao,
            color=discord.Color.purple()
        )
        embed.set_footer(text="100% inventado | mas e se eu estiver certo? 👀")
        await interaction.response.send_message(embed=embed)

    # ─── /pergunta ─────────────────────────────────
    @app_commands.command(name="pergunta", description="O bot faz uma pergunta filosófica pro servidor 🤔")
    async def pergunta_filosofica(self, interaction: discord.Interaction) -> None:
        perguntas = [
            "se você fosse item de Roblox, qual seria o preço? seja honesto 🗿",
            "qual foi a última vez que você respondeu uma mensagem no mesmo dia que recebeu?",
            "você prefere ter razão ou ser feliz? (aviso: no Discord você vai escolher ter razão)",
            "se o servidor tivesse um MVP da semana, seria você? pensa bem antes de responder",
            "quantas abas do navegador você tem abertas AGORA MESMO? confessa.",
            "você já enviou uma mensagem e imediatamente arrependeu? rate de 1 a 10 a frequência",
            "qual personagem de série você mais parece no Discord vs na vida real?",
            "se sua vida fosse um jogo, qual seria sua classe principal? seja honesto sobre seu kit",
            "você já mandou mensagem pra pessoa errada? quantas vezes em 2025?",
            "qual foi o meme que mais te fez rir essa semana? preciso de dados para análise 🔬",
        ]
        pergunta = random.choice(perguntas)
        embed = discord.Embed(
            title="🤔 PERGUNTA DO DIA",
            description=f"**{pergunta}**",
            color=discord.Color.blue()
        )
        embed.set_footer(text=f"pergunta lançada por {interaction.user.display_name} | respondam no chat 👇")
        await interaction.response.send_message(embed=embed)

    # ─── /vibe ─────────────────────────────────────
    @app_commands.command(name="vibe", description="Checa a vibe do servidor agora 📊")
    async def vibe_check(self, interaction: discord.Interaction) -> None:
        vibes = [
            ("🔥 SERVIDOR ON FIRE", "energia altíssima, alguém fez algo e a galera tá reagindo", discord.Color.red()),
            ("😴 MODO SONECA", "todo mundo vivo mas ninguém tá falando. existência passiva.", discord.Color.greyple()),
            ("🎭 DRAMA MODE", "tem algo acontecendo. eu sinto. as vibes estão carregadas.", discord.Color.dark_orange()),
            ("💅 SLAY ENERGY", "o servidor tá chique hoje. não sei o que aconteceu mas aprovado.", discord.Color.from_rgb(255,105,180)),
            ("🗿 MODO PEDRA", "todos presentes. ninguém fala. observação mútua em progresso.", discord.Color.dark_gray()),
            ("🎉 FESTA MODE", "tá animado demais aqui, alguém comemorou algo ou é só caos", discord.Color.gold()),
            ("🤔 MODO FILOSÓFICO", "conversas profundas ou ninguém sabe o que falar. igual.", discord.Color.purple()),
            ("⚡ SPEEDRUN", "mensagens voando, ninguém tá lendo, caos organizado em curso.", discord.Color.yellow()),
        ]
        titulo, desc, cor = random.choice(vibes)
        nivel = random.randint(1, 100)
        embed = discord.Embed(title="📊 VIBE CHECK DO SERVIDOR", color=cor)
        embed.add_field(name="Status atual:", value=f"## {titulo}", inline=False)
        embed.add_field(name="Descrição:", value=desc, inline=False)
        embed.add_field(name="Nível de energia:", value=f"**{nivel}/100**", inline=False)
        embed.set_footer(text="análise feita com base em absolutamente nada científico 🗿")
        await interaction.response.send_message(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(ResenhaHumorCog(bot))
