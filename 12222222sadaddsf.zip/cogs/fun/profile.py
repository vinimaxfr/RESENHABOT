"""
Comando de perfil do usuário.
"""

import discord
from discord.ext import commands
from discord import app_commands
from database.user_repository import UserRepository
from utils.logger import setup_logger
from utils.embeds import EmbedHelper
from datetime import datetime

logger = setup_logger(__name__)


class ProfileCog(commands.Cog):
    """Cog com comandos de perfil de usuário."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(
        name="perfil",
        description="Visualiza o perfil de um usuário"
    )
    @app_commands.describe(usuario="O usuário (deixe em branco para seu perfil)")
    async def perfil_command(
        self,
        interaction: discord.Interaction,
        usuario: discord.User = None
    ) -> None:
        """
        Comando slash para visualizar perfil.

        Args:
            interaction: Interação do Discord
            usuario: Usuário a visualizar (padrão: você mesmo)
        """
        await interaction.response.defer()

        try:
            target_user = usuario or interaction.user
            user_repo = UserRepository(self.bot.db)

            # Criar tabelas se não existirem
            await user_repo.create_tables()

            # Obter ou criar usuário
            user = await user_repo.get_or_create_user(
                discord_id=target_user.id,
                name=target_user.display_name
            )

            # Obter rank
            rank_money = await user_repo.get_user_rank(target_user.id, "money")
            rank_xp = await user_repo.get_user_rank(target_user.id, "xp")
            rank_palo = await user_repo.get_user_rank(target_user.id, "palo_best")

            # Criar embed
            embed = discord.Embed(
                title=f"📋 Perfil de {target_user.display_name}",
                color=discord.Color.blurple(),
                timestamp=datetime.now()
            )

            embed.set_thumbnail(url=target_user.avatar.url)

            # Seção de Nível e Experiência
            embed.add_field(
                name="🎯 Nível e Experiência",
                value=f"**Nível:** {user.level}\n"
                      f"**XP:** {user.xp:,}\n"
                      f"**Ranking XP:** #{rank_xp}",
                inline=True
            )

            # Seção de Economia
            embed.add_field(
                name="💰 Economia",
                value=f"**Dinheiro:** ${user.money:,}\n"
                      f"**Ranking:** #{rank_money}",
                inline=True
            )

            # Seção de Estatísticas Gerais
            embed.add_field(
                name="📊 Estatísticas",
                value=f"**Comandos usados:** {user.commands_used}\n"
                      f"**Mensagens:** {user.messages_count}\n"
                      f"**Calls:** {user.voice_calls}",
                inline=True
            )

            # Seção de Minijogos
            embed.add_field(
                name="🎮 Minijogos",
                value=f"**Vitórias:** {user.minigames_wins}",
                inline=True
            )

            # Seção de "Palo"
            embed.add_field(
                name="📏 Medidas do Palo",
                value=f"**Atual:** {user.palo_current} cm\n"
                      f"**Melhor:** {user.palo_best} cm\n"
                      f"**Pior:** {user.palo_worst} cm\n"
                      f"**Ranking:** #{rank_palo}",
                inline=True
            )

            # Datas
            created_date = datetime.fromisoformat(user.created_at).strftime("%d/%m/%Y %H:%M")
            embed.add_field(
                name="📅 Informações",
                value=f"**Membro desde:** {created_date}",
                inline=False
            )

            embed.set_footer(
                text=f"ID: {target_user.id}",
                icon_url=target_user.avatar.url
            )

            await interaction.followup.send(embed=embed)

            logger.info(f"Perfil de {target_user.display_name} visualizado")

        except Exception as e:
            logger.error(f"Erro ao visualizar perfil: {e}")
            embed = EmbedHelper.error(
                "Erro",
                f"Ocorreu um erro ao carregar o perfil: {str(e)}",
                interaction.user
            )
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="ranking",
        description="Visualiza o ranking de um campo específico"
    )
    @app_commands.describe(
        campo="Campo para ranking (money, xp, palo_best, minigames_wins)"
    )
    @app_commands.choices(
        campo=[
            app_commands.Choice(name="💰 Dinheiro", value="money"),
            app_commands.Choice(name="⭐ Experiência", value="xp"),
            app_commands.Choice(name="📏 Melhor Palo", value="palo_best"),
            app_commands.Choice(name="🎮 Vitórias", value="minigames_wins"),
            app_commands.Choice(name="💬 Mensagens", value="messages_count"),
        ]
    )
    async def ranking_command(
        self,
        interaction: discord.Interaction,
        campo: str = "money"
    ) -> None:
        """
        Comando slash para visualizar ranking.

        Args:
            interaction: Interação do Discord
            campo: Campo do ranking
        """
        await interaction.response.defer()

        try:
            user_repo = UserRepository(self.bot.db)
            await user_repo.create_tables()

            # Obter top 10
            top_users = await user_repo.get_top_users(campo, limit=10)

            # Mapear nomes dos campos para emojis
            field_names = {
                "money": "💰 Ranking de Dinheiro",
                "xp": "⭐ Ranking de Experiência",
                "palo_best": "📏 Ranking de Melhor Palo",
                "minigames_wins": "🎮 Ranking de Vitórias",
                "messages_count": "💬 Ranking de Mensagens",
            }

            embed = discord.Embed(
                title=field_names.get(campo, "📊 Ranking"),
                color=discord.Color.gold(),
                timestamp=datetime.now()
            )

            # Construir ranking
            ranking_text = ""
            for idx, user in enumerate(top_users, 1):
                value = getattr(user, campo)
                medal = "🥇" if idx == 1 else "🥈" if idx == 2 else "🥉" if idx == 3 else f"#{idx}"

                ranking_text += f"{medal} **{user.name}** - {value:,}\n"

            if ranking_text:
                embed.description = ranking_text
            else:
                embed.description = "Nenhum dado disponível"

            embed.set_footer(text="Top 10 usuários")

            await interaction.followup.send(embed=embed)

            logger.info(f"Ranking de {campo} visualizado")

        except Exception as e:
            logger.error(f"Erro ao visualizar ranking: {e}")
            embed = EmbedHelper.error(
                "Erro",
                f"Ocorreu um erro ao carregar o ranking: {str(e)}",
                interaction.user
            )
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(ProfileCog(bot))
