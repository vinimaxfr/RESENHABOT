"""
Comando para rankings avançados no Discord.
"""

import discord
from discord.ext import commands
from discord import app_commands
from database.advanced_ranking_repository import AdvancedRankingRepository
from utils.embeds import EmbedHelper
from utils.logger import setup_logger

logger = setup_logger(__name__)


class AdvancedRankingCog(commands.Cog):
    """Cog com comandos de rankings avançados."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.ranking_repo = AdvancedRankingRepository(bot.db)

    @app_commands.command(
        name="ranking_infrações",
        description="Top usuários com mais infrações"
    )
    async def ranking_infractions_cmd(self, interaction: discord.Interaction) -> None:
        """Ranking de infrações."""
        await interaction.response.defer()

        try:
            data = await self.ranking_repo.get_top_by_infractions(interaction.guild.id)

            if not data:
                embed = EmbedHelper.warning(
                    "Sem Dados",
                    "Nenhuma infração neste servidor ainda!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            embed = discord.Embed(
                title="⚠️ Top Infrações",
                color=discord.Color.red(),
                description="Usuários com mais infrações"
            )

            for i, user in enumerate(data[:10], 1):
                embed.add_field(
                    name=f"{i}. {user['name'] or 'Desconhecido'}",
                    value=f"**{user['total']}** infrações",
                    inline=False
                )

            await interaction.followup.send(embed=embed)
            logger.info(f"Ranking infrações visualizado")

        except Exception as e:
            logger.error(f"Erro: {e}")
            embed = EmbedHelper.error("Erro", str(e))
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="ranking_moderadores",
        description="Top moderadores por ações"
    )
    async def ranking_moderators_cmd(self, interaction: discord.Interaction) -> None:
        """Ranking de moderadores."""
        await interaction.response.defer()

        try:
            data = await self.ranking_repo.get_top_by_moderations(interaction.guild.id)

            if not data:
                embed = EmbedHelper.warning(
                    "Sem Dados",
                    "Nenhuma ação de moderação neste servidor ainda!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            embed = discord.Embed(
                title="👮 Top Moderadores",
                color=discord.Color.blue(),
                description="Moderadores mais ativos"
            )

            for i, mod in enumerate(data[:10], 1):
                embed.add_field(
                    name=f"{i}. {mod['name'] or 'Desconhecido'}",
                    value=f"**{mod['total']}** ações",
                    inline=False
                )

            await interaction.followup.send(embed=embed)
            logger.info(f"Ranking moderadores visualizado")

        except Exception as e:
            logger.error(f"Erro: {e}")
            embed = EmbedHelper.error("Erro", str(e))
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(AdvancedRankingCog(bot))
