"""
Task para fazer backup automático do BD a cada 6 horas.
"""

import asyncio
import discord
from discord.ext import commands, tasks
from utils.backup import backup_database
from utils.logger import setup_logger

logger = setup_logger(__name__)


class BackupTaskCog(commands.Cog):
    """Task para backup automático."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.backup_task.start()

    def cog_unload(self):
        """Cancelar task ao descarregar."""
        self.backup_task.cancel()

    @tasks.loop(hours=6)
    async def backup_task(self) -> None:
        """Task de backup a cada 6 horas."""
        try:
            backup_database()
        except Exception as e:
            logger.error(f"Erro na task de backup: {e}")

    @backup_task.before_loop
    async def before_backup(self) -> None:
        """Esperar bot estar pronto."""
        await self.bot.wait_until_ready()


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(BackupTaskCog(bot))
