"""
Leveling automático em mensagens.
"""

import discord
from discord.ext import commands
import random
from database.user_repository import UserRepository
from utils.logger import setup_logger

logger = setup_logger(__name__)


class AutoLevelingCog(commands.Cog):
    """Auto leveling em mensagens."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.user_repo = UserRepository(bot.db)

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        """Adiciona XP em mensagens."""
        if message.author == self.bot.user or message.author.bot:
            return
        if not message.guild:
            return

        try:
            xp_gain = random.randint(10, 30)

            # Corrigido: get_or_create_user só aceita discord_id e name
            user = await self.user_repo.get_or_create_user(
                message.author.id,
                message.author.display_name
            )

            old_level = user.level if hasattr(user, "level") else user.get("level", 0)
            await self.user_repo.add_xp(message.author.id, xp_gain)

            user_updated = await self.user_repo.get_user(message.author.id)
            new_level = user_updated.level if hasattr(user_updated, "level") else user_updated.get("level", 0)

            if new_level > old_level:
                embed = discord.Embed(
                    title="🎉 Level Up!",
                    description=f"{message.author.mention} atingiu o **nível {new_level}**!",
                    color=discord.Color.gold()
                )
                await message.channel.send(embed=embed, delete_after=10)
                logger.info(f"Level up: {message.author.display_name} → {new_level}")

        except Exception as e:
            logger.error(f"Erro em auto leveling: {e}")


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(AutoLevelingCog(bot))
