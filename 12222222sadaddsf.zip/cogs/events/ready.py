"""
Evento de pronto do bot.
"""

import discord
from discord.ext import commands
from utils.logger import setup_logger

logger = setup_logger(__name__)


class ReadyEvent(commands.Cog):
    """Eventos acionados quando o bot está pronto."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_ready(self) -> None:
        """Chamado quando o bot está pronto e conectado."""
        logger.info(f"✅ Bot conectado como: {self.bot.user}")
        logger.info(f"📊 Servidores: {len(self.bot.guilds)}")

        try:
            synced = await self.bot.tree.sync()
            logger.info(f"🔄 Comandos Slash sincronizados: {len(synced)}")
        except Exception as e:
            logger.error(f"Erro ao sincronizar comandos: {e}")


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(ReadyEvent(bot))
