"""
Auto-responder para DMs do bot.
"""

import discord
from discord.ext import commands
from utils.logger import setup_logger

logger = setup_logger(__name__)


class DMResponderCog(commands.Cog):
    """Responde a DMs automaticamente."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        """Responde a DMs."""
        if message.author == self.bot.user:
            return

        if isinstance(message.channel, discord.DMChannel):
            try:
                embed = discord.Embed(
                    title="👋 Olá!",
                    description="Sou a **Resenha Bot**!\n\n"
                               "Use-me em um servidor Discord para:\n"
                               "💬 Conversar (/contexto_*)\n"
                               "🎮 Jogar minigames\n"
                               "💰 Economia\n"
                               "🎙️ Voz com IA\n"
                               "👮 Moderação\n\n"
                               "Obrigada por me adicionar! 🎉",
                    color=discord.Color.blurple()
                )
                embed.set_footer(text="Use /help em um servidor")
                await message.author.send(embed=embed)
                logger.info(f"DM respondido para {message.author.display_name}")
            except Exception as e:
                logger.error(f"Erro ao responder DM: {e}")


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(DMResponderCog(bot))
