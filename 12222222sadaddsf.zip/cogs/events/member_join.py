"""
Evento de novo membro - cria perfil automaticamente.
"""

import discord
from discord.ext import commands
from utils.logger import setup_logger

logger = setup_logger(__name__)


class MemberJoinEvent(commands.Cog):
    """Eventos de entrada de membros no servidor."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member) -> None:
        """Chamado quando um novo membro entra no servidor."""
        if member.bot:
            return

        try:
            # Obter ou criar perfil do usuário
            if self.bot.db:
                from database.user_repository import UserRepository

                user_repo = UserRepository(self.bot.db)
                await user_repo.create_tables()

                user = await user_repo.get_or_create_user(
                    discord_id=member.id,
                    name=member.display_name
                )

                logger.info(f"👋 Novo membro: {member.display_name} (ID: {member.id})")

                # Enviar mensagem de boas-vindas (opcional)
                try:
                    embed = discord.Embed(
                        title="🎉 Bem-vindo!",
                        description=f"Olá {member.mention}! Bem-vindo ao servidor!\n\n"
                                  "Use `/perfil` para ver seu perfil.\n"
                                  "Use `/help` para ver os comandos disponíveis.",
                        color=discord.Color.green()
                    )
                    embed.set_thumbnail(url=member.avatar.url)

                    # Tentar enviar no canal geral
                    for channel in member.guild.channels:
                        if isinstance(channel, discord.TextChannel) and channel.name == "geral":
                            await channel.send(embed=embed)
                            break

                except Exception as e:
                    logger.warning(f"Não foi possível enviar mensagem de boas-vindas: {e}")

        except Exception as e:
            logger.error(f"Erro ao processar novo membro: {e}")


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(MemberJoinEvent(bot))
