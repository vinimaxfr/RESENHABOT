"""
Processador de áudio para STT e TTS.

STT: SpeechRecognition (Google Speech API — grátis, sem key)
TTS: gTTS (Google Text-to-Speech — grátis, sem key)
IA:  Anthropic Claude (usa ANTHROPIC_API_KEY do .env)
"""

import asyncio
import io
import wave
import tempfile
import os
from typing import Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)


class AudioProcessor:
    """Processa áudio para STT e TTS sem custo extra."""

    def __init__(self):
        """Inicializa e verifica dependências."""
        self._check_dependencies()

    def _check_dependencies(self):
        """Verifica se as libs de voz estão instaladas."""
        try:
            import speech_recognition  # noqa
            logger.info("SpeechRecognition disponível (STT grátis via Google)")
        except ImportError:
            logger.warning("SpeechRecognition não instalado — rode: pip install SpeechRecognition")

        try:
            import gtts  # noqa
            logger.info("gTTS disponível (TTS grátis via Google)")
        except ImportError:
            logger.warning("gTTS não instalado — rode: pip install gtts")

        try:
            import pydub  # noqa
            logger.info("pydub disponível (conversão de áudio)")
        except ImportError:
            logger.warning("pydub não instalado — rode: pip install pydub")

    def _pcm_to_wav(self, audio_bytes: bytes) -> bytes:
        """Converte PCM bruto (Discord) em bytes WAV."""
        buffer = io.BytesIO()
        with wave.open(buffer, "wb") as wav_file:
            wav_file.setnchannels(2)       # stereo (Discord padrão)
            wav_file.setsampwidth(2)       # 16-bit
            wav_file.setframerate(48000)   # 48kHz (Discord padrão)
            wav_file.writeframes(audio_bytes)
        return buffer.getvalue()

    async def transcribe_audio(self, audio_bytes: bytes) -> Optional[str]:
        """
        Transcreve áudio para texto via Google Speech Recognition (grátis).

        Args:
            audio_bytes: Dados de áudio em PCM cru do Discord

        Returns:
            Texto transcrito ou None se falhar
        """
        try:
            import speech_recognition as sr
        except ImportError:
            logger.error("SpeechRecognition não instalado. Rode: pip install SpeechRecognition")
            return None

        try:
            if not audio_bytes or len(audio_bytes) < 1000:
                logger.warning("Áudio muito curto para transcrever")
                return None

            # Converter PCM → WAV
            wav_bytes = self._pcm_to_wav(audio_bytes)

            # Rodar em thread separada pra não bloquear o bot
            def _recognize():
                recognizer = sr.Recognizer()
                wav_io = io.BytesIO(wav_bytes)
                with sr.AudioFile(wav_io) as source:
                    # Ajuste de ruído ambiente
                    recognizer.adjust_for_ambient_noise(source, duration=0.3)
                    audio_data = recognizer.record(source)

                # Google Speech API — grátis, sem key necessária
                return recognizer.recognize_google(audio_data, language="pt-BR")

            loop = asyncio.get_event_loop()
            text = await loop.run_in_executor(None, _recognize)
            text = text.strip()

            if text:
                logger.info(f"Transcrição: {text[:80]}...")
                return text
            return None

        except Exception as e:
            # sr.UnknownValueError = silêncio ou áudio incompreensível
            if "UnknownValueError" in type(e).__name__:
                logger.debug("Áudio não reconhecido (silêncio ou ruído)")
            else:
                logger.error(f"Erro ao transcrever áudio: {e}")
            return None

    async def synthesize_speech(self, text: str) -> Optional[bytes]:
        """
        Sintetiza fala a partir de texto via gTTS (Google TTS — grátis).
        Retorna bytes MP3 prontos para tocar no canal de voz.

        Args:
            text: Texto a ser falado

        Returns:
            Áudio MP3 em bytes ou None se falhar
        """
        try:
            from gtts import gTTS
        except ImportError:
            logger.error("gTTS não instalado. Rode: pip install gtts")
            return None

        try:
            if not text or len(text.strip()) == 0:
                logger.warning("Texto vazio para TTS")
                return None

            # Limitar tamanho (gTTS aceita textos longos, mas voz fica lenta)
            text_clean = text[:400].strip()

            def _synthesize():
                tts = gTTS(text=text_clean, lang="pt", slow=False)
                buffer = io.BytesIO()
                tts.write_to_fp(buffer)
                buffer.seek(0)
                return buffer.read()

            loop = asyncio.get_event_loop()
            mp3_bytes = await loop.run_in_executor(None, _synthesize)

            logger.info(f"TTS gerado: {len(mp3_bytes)} bytes para '{text_clean[:40]}...'")
            return mp3_bytes

        except Exception as e:
            logger.error(f"Erro ao sintetizar fala: {e}")
            return None

    async def mp3_to_playable(self, mp3_bytes: bytes, output_path: str) -> bool:
        """
        Converte MP3 para formato compatível com discord.py FFmpegPCMAudio.
        Salva em disco temporariamente.

        Args:
            mp3_bytes: Bytes MP3 do gTTS
            output_path: Caminho onde salvar o arquivo

        Returns:
            True se converteu com sucesso
        """
        try:
            def _convert():
                with open(output_path, "wb") as f:
                    f.write(mp3_bytes)
                return True

            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, _convert)

        except Exception as e:
            logger.error(f"Erro ao salvar áudio: {e}")
            return False


async def setup(bot):
    """audio_processor.py é um módulo de suporte, não um Cog — setup vazio."""
    pass

