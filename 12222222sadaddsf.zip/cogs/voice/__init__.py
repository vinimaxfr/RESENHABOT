"""
Cogs de voz e processamento de áudio.
"""

from .voice_handler import VoiceCog

__all__ = ["VoiceCog"]
