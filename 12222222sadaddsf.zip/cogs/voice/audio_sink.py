"""
Audio sink para capturar áudio do Discord.
Compatível com discord.py 2.x (sem discord.sinks).
"""

import io
from utils.logger import setup_logger

logger = setup_logger(__name__)


class ResenhaAudioSink:
    """
    Audio sink simples para capturar PCM do Discord.
    Compatível com discord.py 2.x que não tem discord.sinks.
    """

    def __init__(self):
        self.audio_data: dict[int, list[bytes]] = {}
        self.active = True

    def write(self, user_id: int, pcm_data: bytes) -> None:
        """Recebe chunk de PCM de um usuário."""
        if not self.active:
            return
        if user_id not in self.audio_data:
            self.audio_data[user_id] = []
        self.audio_data[user_id].append(pcm_data)

    def get_audio(self, user_id: int) -> bytes:
        """Retorna e limpa o áudio acumulado de um usuário."""
        if user_id not in self.audio_data or not self.audio_data[user_id]:
            return b""
        data = b"".join(self.audio_data[user_id])
        self.audio_data[user_id] = []
        return data

    def stop(self) -> None:
        self.active = False

    def clear(self) -> None:
        self.audio_data.clear()


async def setup(bot):
    """audio_sink.py é um módulo de suporte, não um Cog — setup vazio."""
    pass

