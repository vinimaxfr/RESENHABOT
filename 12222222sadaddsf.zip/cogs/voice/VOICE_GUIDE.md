"""
Documentação do Sistema de Voz (Fase 7).

FUNCIONALIDADES:
================

1. CONECTAR A VOZ
   Comando: /entrar
   - Bot entra no canal de voz onde você está
   - Prepara para processar áudio

2. ESCUTAR ÁUDIO
   - Bot captura áudio dos participantes
   - Converte para WAV/PCM
   - Fila de processamento processa sequencialmente

3. CONVERTER VOZ PARA TEXTO (STT)
   - Usar: Faster Whisper (local)
   - Modelo: tiny (rápido)
   - Suporta português
   - Processa em background

4. ENVIAR PARA IA
   - Contexto incluído (últimas 10 mensagens)
   - Sistema prompt (personalidade)
   - OpenAI gpt-3.5-turbo
   - Resposta limitada a 200 tokens

5. CONVERTER TEXTO PARA VOZ (TTS)
   - Usar: OpenAI TTS
   - Voz: nova
   - Formato: MP3
   - Requer OPENAI_API_KEY

6. FALAR AUTOMATICAMENTE
   - Bot reproduz resposta da IA em voz
   - FFmpeg faz o streaming
   - Apenas uma resposta por vez (fila)

7. FILA DE PROCESSAMENTO
   - VoiceQueue garante sequencialidade
   - Impede respostas simultâneas
   - AsyncLock para sincronização
   - Status via /status_voz

FLUXO DE DADOS:
===============

1. Bot entra em call via /entrar
2. Bot escuta áudio dos membros
3. AudioSink captura PCM
4. AudioProcessor transcreve com Whisper
5. Texto vai para ContextRepository
6. IA gera resposta com contexto
7. AudioProcessor sintetiza voz
8. VoiceManager reproduz MP3

COMANDOS:
=========

/entrar
  - Conecta ao canal de voz
  - Requer estar em um canal
  - Resultado: "Entrei em #voice"

/sair
  - Desconecta do canal de voz
  - Para de ouvir
  - Resultado: "Saí do canal de voz"

/status_voz
  - Mostra se está conectado
  - Mostra canal e membros
  - Mostra fila de processamento
  - Resultado: Embed com info

CONFIGURAÇÃO NECESSÁRIA:
=========================

1. VARIÁVEIS DE AMBIENTE (.env)
   OPENAI_API_KEY=sua_chave_aqui
   DISCORD_TOKEN=seu_token_aqui

2. DEPENDÊNCIAS PYTHON
   - discord.py[voice]==2.3.2
   - PyNaCl==1.5.0 (criptografia de voz)
   - faster-whisper==0.10.0 (STT)
   - aiohttp==3.9.0 (requisições)
   - pydub==0.25.1 (processamento áudio)

3. DEPENDÊNCIAS DE SISTEMA
   Windows:
   - FFmpeg (https://ffmpeg.org/download.html)
   - Adicionar FFmpeg ao PATH
   
   Linux (Ubuntu/Debian):
   - sudo apt-get install ffmpeg libopus-dev libsodium-dev
   
   macOS:
   - brew install ffmpeg opus libsodium

EXEMPLO DE USO:
===============

Você: /entrar
Bot:  "Entrei em #voice_channel"

Bot escuta seu áudio...

Você: "Oi bot, tudo bem?"
Bot:  [Transcreveu: "Oi bot, tudo bem?"]
      [Enviou para IA]
      [IA respondeu: "Oi! Tudo certo! 🎉"]
      [Sintetizou em voz]
      [Reproduz: "Oi! Tudo certo!"]

Você: /status_voz
Bot:  "Conectado em #voice_channel
       Processando 0 tarefas"

Você: /sair
Bot:  "Saí do canal de voz"

LIMITAÇÕES CONHECIDAS:
======================

⚠️ Tamanho de áudio: Máx ~30s por captura
⚠️ Qualidade: Depende de codec Discord
⚠️ Latência: ~3-5 segundos processamento
⚠️ Custo OpenAI: TTS custa por caractere
⚠️ Whisper: Modelo tiny = menos preciso
⚠️ Simultâneos: Fila processa 1 por vez

OTIMIZAÇÕES FUTURAS:
====================

💡 Usar modelo whisper base/small (melhor preciso)
💡 Cache de TTS para respostas repetidas
💡 Compressão de áudio antes de STT
💡 Suporte a múltiplos idiomas
💡 Implementar streaming de TTS
💡 WebRTC para melhor qualidade

TROUBLESHOOTING:
================

Erro: "FFmpeg não encontrado"
→ Instale FFmpeg e adicione ao PATH

Erro: "Failed to import codec"
→ Reinstale: pip install discord.py[voice] --upgrade --force

Erro: "OPENAI_API_KEY não configurada"
→ Adicione ao .env: OPENAI_API_KEY=sk-...

Erro: "Whisper model not found"
→ Primeira execução baixa modelo (lento)
→ Aguarde pacientemente

Erro: "Bot não ouve áudio"
→ Verifique permissões em server.json
→ Tente /sair e /entrar novamente
"""
