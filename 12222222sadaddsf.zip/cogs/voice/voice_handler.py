"""
Cog de voz do Resenha Bot — v3.

CORREÇÕES:
- VoiceManager recebe referência ao bot (para pegar ffmpeg_path).
- _wait_for_vc usa timeout razoável (5s) sem loop excessivo.
- _speak usa bot.ffmpeg_path ao invés de shutil.which na hora de tocar.
- Após channel.connect() retornar, o vc já está conectado — não precisamos de loop longo.
"""

import discord
from discord.ext import commands
from discord import app_commands
import asyncio
import os
import shutil
import tempfile
import time
import random
import aiohttp

from cogs.voice.voice_manager import VoiceManager
from cogs.voice.audio_processor import AudioProcessor
from cogs.ai.prompts import get_system_prompt
from config.settings import Settings
from utils.logger import setup_logger
from utils.embeds import EmbedHelper

logger = setup_logger(__name__)

COOLDOWN_VOZ    = 180
CHANCE_VOZ_BASE = 0.04
TEMAS_VOZ = [
    "roblox", "game", "jogo", "call", "voz", "falar",
    "meme", "engraçado", "que isso", "nossa", "acredita",
    "discord", "stream", "twitch",
]


class VoiceCog(commands.Cog):

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.voice_manager = VoiceManager(bot=bot)
        self.audio_processor = AudioProcessor()
        self.session: aiohttp.ClientSession = None
        self._voz_cooldowns: dict[int, float] = {}
        self._chat_recente: dict[int, list[str]] = {}

    async def cog_load(self) -> None:
        self.session = aiohttp.ClientSession()

    async def cog_unload(self) -> None:
        if self.session:
            await self.session.close()

    # ─── Helper: vc sempre fresco ────────────────────────────────────────────

    def _get_vc(self, guild: discord.Guild) -> discord.VoiceClient | None:
        vc = guild.voice_client
        return vc if (vc and vc.is_connected()) else None

    async def _wait_for_vc(
        self, guild: discord.Guild, timeout: float = 5.0
    ) -> discord.VoiceClient | None:
        """
        Aguarda guild.voice_client ficar conectado.
        Normalmente channel.connect() já retorna conectado — isso é só segurança extra.
        """
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            vc = self._get_vc(guild)
            if vc:
                return vc
            await asyncio.sleep(0.2)
        logger.warning(f"_wait_for_vc: vc não ficou pronto em {timeout}s")
        return None

    # ─── ffmpeg path ─────────────────────────────────────────────────────────

    def _ffmpeg(self) -> str:
        path = getattr(self.bot, "ffmpeg_path", None)
        if path and path != "ffmpeg":
            return path
        return shutil.which("ffmpeg") or "/usr/bin/ffmpeg" or "ffmpeg"

    # ─── Cooldowns ───────────────────────────────────────────────────────────

    def _voz_em_cooldown(self, guild_id: int) -> bool:
        return (time.time() - self._voz_cooldowns.get(guild_id, 0)) < COOLDOWN_VOZ

    def _set_voz_cooldown(self, guild_id: int) -> None:
        self._voz_cooldowns[guild_id] = time.time()

    def _registrar_chat(self, guild_id: int, content: str) -> None:
        hist = self._chat_recente.setdefault(guild_id, [])
        hist.append(content)
        if len(hist) > 8:
            hist.pop(0)

    def _deve_falar_espontaneo(self, guild_id: int, content: str) -> bool:
        if self._voz_em_cooldown(guild_id):
            return False
        tem_tema = any(t in content.lower() for t in TEMAS_VOZ)
        chance = CHANCE_VOZ_BASE * 3 if tem_tema else CHANCE_VOZ_BASE
        return random.random() < min(chance, 0.12)

    # ─── Listeners ───────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_voice_state_update(
        self,
        member: discord.Member,
        before: discord.VoiceState,
        after: discord.VoiceState,
    ) -> None:
        if member.bot:
            return

        guild = member.guild

        if after.channel and (not before.channel or before.channel != after.channel):
            vc = self._get_vc(guild)
            if not vc:
                success = await self.voice_manager.connect(after.channel)
                if success:
                    # channel.connect() já retornou conectado; _wait_for_vc é segurança extra
                    vc = self._get_vc(guild) or await self._wait_for_vc(guild, timeout=3.0)
                    if vc:
                        await self._saudar_entrada(vc, member)
                    else:
                        logger.warning("Auto-join: vc sumiu logo após connect()")
            else:
                if vc.channel == after.channel:
                    await self._saudar_entrada(vc, member)

        if before.channel:
            humanos = [m for m in before.channel.members if not m.bot]
            if not humanos:
                vc = self._get_vc(guild)
                if vc and vc.channel == before.channel:
                    await self.voice_manager.disconnect(guild.id, guild=guild)
                    logger.info(f"Auto-leave: {before.channel.name} ficou vazio")

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message) -> None:
        if message.author.bot or not message.guild:
            return

        guild = message.guild
        self._registrar_chat(guild.id, message.content)

        vc = self._get_vc(guild)
        if not vc or vc.is_playing() or len(message.content) < 8:
            return

        if self._deve_falar_espontaneo(guild.id, message.content):
            await self._falar_espontaneo(vc, guild, message)

    # ─── Saudação ────────────────────────────────────────────────────────────

    async def _saudar_entrada(self, vc: discord.VoiceClient, member: discord.Member) -> None:
        try:
            system = (
                get_system_prompt()
                + "\n\nVocê está na call de voz. Alguém acabou de entrar. "
                "Dê uma saudação CURTA e engraçada (1 frase), no estilo resenha brasileiro. "
                "Sem emojis, sem markdown — só texto puro para ser falado em voz."
            )
            resposta = await self._call_groq(
                system=system,
                user_msg=f"{member.display_name} entrou na call. Dê boas-vindas rápidas."
            )
            if not resposta:
                resposta = f"Ow, chegou o {member.display_name}! Bora resenha!"

            await self._speak(member.guild, resposta)
            self._set_voz_cooldown(member.guild.id)
        except Exception as e:
            logger.error(f"Erro ao saudar entrada: {e}")

    # ─── Fala espontânea ─────────────────────────────────────────────────────

    async def _falar_espontaneo(
        self,
        vc: discord.VoiceClient,
        guild: discord.Guild,
        message: discord.Message,
    ) -> None:
        try:
            hist = self._chat_recente.get(guild.id, [])
            contexto = "\n".join(hist[-5:]) if hist else message.content

            system = (
                get_system_prompt()
                + "\n\nVocê está numa call de voz e vai fazer um comentário FALADO sobre o que "
                "está rolando no chat. Seja MUITO breve (1 frase curta), engraçado e no tema. "
                "Sem emojis, sem símbolos, sem markdown — só texto puro pra ser falado em voz."
            )
            resposta = await self._call_groq(
                system=system,
                user_msg=f"Contexto do chat:\n{contexto}\n\nFaça um comentário rápido em voz."
            )
            if resposta:
                await self._speak(guild, resposta)
                self._set_voz_cooldown(guild.id)
                logger.info(f"Voz espontânea: {resposta[:60]}")
        except Exception as e:
            logger.error(f"Erro em fala espontânea: {e}")

    # ─── Comandos slash ──────────────────────────────────────────────────────

    @app_commands.command(name="entrar", description="Bot entra no seu canal de voz 🎤")
    async def join_command(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer()

        if not interaction.user.voice:
            await interaction.followup.send(
                embed=EmbedHelper.error("Sem Canal", "Você precisa estar num canal de voz!")
            )
            return

        channel = interaction.user.voice.channel
        guild = interaction.guild

        existing = guild.voice_client
        if existing:
            try:
                await existing.disconnect(force=True)
            except Exception:
                pass
            await asyncio.sleep(0.8)

        success = await self.voice_manager.connect(channel)
        if not success:
            await interaction.followup.send(
                embed=EmbedHelper.error(
                    "Erro de Voz",
                    "Não consegui entrar no canal. Verifique se tenho permissão de conectar."
                )
            )
            return

        embed = discord.Embed(
            title="🎤 Entrei na call!",
            description=(
                f"Tô em **{channel.name}**! Vou ouvir o chat e às vezes soltar um comentário. 🗿\n\n"
                "Use `/sair` pra me tirar | `/falar` pra eu falar algo | `/perguntar_voz` pra me perguntar."
            ),
            color=discord.Color.green()
        )
        await interaction.followup.send(embed=embed)

        # Saudar — vc já está pronto pois connect() é bloqueante
        vc = self._get_vc(guild)
        if vc:
            await self._saudar_entrada(vc, interaction.user)
        else:
            logger.warning("/entrar: vc sumiu após connect() — não vai saudar")

    @app_commands.command(name="sair", description="Bot sai do canal de voz 👋")
    async def leave_command(self, interaction: discord.Interaction) -> None:
        await interaction.response.defer()
        success = await self.voice_manager.disconnect(
            interaction.guild_id, guild=interaction.guild
        )
        if success:
            await interaction.followup.send(embed=discord.Embed(
                title="👋 Saí da call!",
                description="Foi bom demais. Até a próxima resenha 🗿",
                color=discord.Color.orange()
            ))
        else:
            await interaction.followup.send(
                embed=EmbedHelper.error("Erro", "Não estava em nenhum canal.")
            )

    @app_commands.command(name="falar", description="Bot fala algo no canal de voz 🔊")
    @app_commands.describe(texto="O que você quer que o bot fale?")
    async def speak_command(self, interaction: discord.Interaction, texto: str) -> None:
        await interaction.response.defer()
        vc = self._get_vc(interaction.guild)
        if not vc:
            await interaction.followup.send(
                embed=EmbedHelper.error("Sem Voz", "Use `/entrar` primeiro!")
            )
            return

        success = await self._speak(interaction.guild, texto)
        if success:
            await interaction.followup.send(embed=discord.Embed(
                title="🔊 Falando...",
                description=f"*\"{texto}\"*",
                color=discord.Color.blue()
            ))
        else:
            await interaction.followup.send(
                embed=EmbedHelper.error("Erro de TTS", "Não consegui gerar o áudio 😢")
            )

    @app_commands.command(name="perguntar_voz", description="Faz uma pergunta pro bot falar em voz 🤖🎤")
    @app_commands.describe(pergunta="Sua pergunta")
    async def ask_voice(self, interaction: discord.Interaction, pergunta: str) -> None:
        await interaction.response.defer()
        vc = self._get_vc(interaction.guild)
        if not vc:
            await interaction.followup.send(
                embed=EmbedHelper.error("Sem Voz", "Use `/entrar` primeiro!")
            )
            return

        system = (
            get_system_prompt()
            + "\n\nVocê está respondendo EM VOZ. Seja MUITO breve (máx 2 frases curtas). "
            "Sem emojis, sem símbolos, sem markdown — só texto puro pra ser falado."
        )
        resposta = await self._call_groq(system=system, user_msg=f"{interaction.user.display_name}: {pergunta}")
        if not resposta:
            resposta = "Tive um problema aqui, desculpa"

        await self._speak(interaction.guild, resposta)

        embed = discord.Embed(title="🤖 Resposta em Voz", color=discord.Color.purple())
        embed.add_field(name="Pergunta:", value=pergunta, inline=False)
        embed.add_field(name="Resposta:", value=resposta, inline=False)
        await interaction.followup.send(embed=embed)

    # ─── _speak: recebe guild, pega vc fresco ────────────────────────────────

    async def _speak(self, guild: discord.Guild, text: str) -> bool:
        """
        Gera TTS e toca no canal de voz.
        Recebe o guild (não o vc) para sempre usar o vc mais atual.
        """
        try:
            mp3_bytes = await self.audio_processor.synthesize_speech(text)
            if not mp3_bytes:
                logger.error("_speak: TTS não gerou bytes")
                return False

            # Pega vc fresco agora (após a chamada de TTS)
            vc = self._get_vc(guild)
            if not vc:
                logger.error("_speak: VoiceClient não está conectado")
                return False

            if vc.is_playing():
                vc.stop()
                await asyncio.sleep(0.3)

            ffmpeg_path = self._ffmpeg()

            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as f:
                f.write(mp3_bytes)
                tmp_path = f.name

            def after_play(error):
                try:
                    os.unlink(tmp_path)
                except Exception:
                    pass
                if error:
                    logger.error(f"Erro ao tocar áudio: {error}")

            source = discord.FFmpegPCMAudio(
                tmp_path, executable=ffmpeg_path, options="-loglevel quiet"
            )
            vc.play(source, after=after_play)
            logger.info(f"Falando: {text[:60]}")
            return True

        except Exception as e:
            logger.error(f"Erro ao falar: {e}")
            return False

    # ─── Groq ────────────────────────────────────────────────────────────────

    async def _call_groq(self, system: str, user_msg: str) -> str:
        try:
            if not Settings.GROQ_API_KEY:
                return ""
            async with self.session.post(
                "https://api.groq.com/openai/v1/chat/completions",
                json={
                    "model": "llama-3.1-8b-instant",
                    "messages": [
                        {"role": "system", "content": system},
                        {"role": "user", "content": user_msg},
                    ],
                    "temperature": 0.85,
                    "max_tokens": 80,
                },
                headers={
                    "Authorization": f"Bearer {Settings.GROQ_API_KEY}",
                    "Content-Type": "application/json",
                },
                timeout=aiohttp.ClientTimeout(total=20),
            ) as resp:
                if resp.status != 200:
                    return ""
                data = await resp.json()
                return data["choices"][0]["message"]["content"].strip()
        except Exception as e:
            logger.error(f"Erro Groq voz: {e}")
            return ""


async def setup(bot: commands.Bot) -> None:
    cog = VoiceCog(bot)
    await cog.cog_load()
    await bot.add_cog(cog)
