"""
Setup de FFmpeg para Resenha Bot.

FFmpeg é necessário para processamento de áudio e streaming de voz.

WINDOWS:
========

1. DOWNLOAD
   - Visite: https://ffmpeg.org/download.html#build-windows
   - Escolha uma build (ex: ffmpeg-master-latest-win64-gpl.zip)
   - Ou use: https://www.gyan.dev/ffmpeg/builds/

2. INSTALAÇÃO
   - Extraia o arquivo ZIP
   - Copie a pasta "ffmpeg" para um local permanente
     Ex: C:\\Program Files\\ffmpeg

3. ADICIONAR AO PATH (Variáveis de Ambiente)
   a) Abra "Variáveis de Ambiente" (Windows + X > Configurações)
   b) Busque "Editar variáveis de ambiente do sistema"
   c) Clique em "Variáveis de Ambiente"
   d) Sob "Variáveis do sistema", selecione "Path" e edite
   e) Clique "Novo" e adicione: C:\\Program Files\\ffmpeg\\bin
   f) Clique OK e feche tudo
   g) Reinicie o PowerShell

4. VERIFICAR
   - Abra novo PowerShell
   - Digite: ffmpeg -version
   - Se aparecer versão, está OK!

LINUX (Ubuntu/Debian):
======================

1. INSTALAÇÃO
   sudo apt-get update
   sudo apt-get install ffmpeg libopus-dev libsodium-dev

2. VERIFICAR
   ffmpeg -version

macOS:
======

1. INSTALAÇÃO COM BREW
   brew install ffmpeg opus libsodium

2. VERIFICAR
   ffmpeg -version

TESTE:
======

1. Teste básico FFmpeg
   ffmpeg -version

2. Teste de codec MP3
   ffmpeg -codecs | grep mp3

3. Teste de codec Opus
   ffmpeg -codecs | grep opus

POSSÍVEIS ERROS:
================

"ffmpeg: command not found"
→ FFmpeg não está no PATH
→ Reinstale e adicione ao PATH

"Unknown encoder 'libmp3lame'"
→ Use build diferente (com todos os codecs)
→ https://www.gyan.dev/ffmpeg/builds/

"opus encoder not found"
→ Instale libopus
→ Windows: Incluso em algumas builds
→ Linux: sudo apt-get install libopus0 libopus-dev
→ macOS: brew install opus

VERIFICAÇÃO FINAL:
==================

# Windows PowerShell
ffmpeg -version

# Deve aparecer algo como:
# ffmpeg version 7.0 ...
# Copyleft 2023-2024

# Isso significa FFmpeg está OK ✓
"""
