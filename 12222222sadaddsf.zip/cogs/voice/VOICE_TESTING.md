"""
Teste de funcionalidade de Voz.

ANTES DE INICIAR:
=================

1. FFmpeg instalado? ffmpeg -version
2. Faster Whisper? pip list | grep faster-whisper
3. OPENAI_API_KEY configurada em .env
4. Bot em servidor de teste com canal de voz

PASSO A PASSO:
==============

1. INICIAR BOT
   python main.py
   Aguarde até: "✅ Bot inicializado com sucesso!"

2. ENTRAR EM CALL
   /entrar
   Esperado: "Entrei em #voice_channel"
   Verificar: Bot entra no canal (ícone de conexão)

3. VERIFICAR STATUS
   /status_voz
   Esperado:
   - Status: Conectado ✅
   - Canal: [nome do canal]
   - Membros: [número]
   - Fila: 0 tarefas

4. TESTAR ÁUDIO
   - Fale algo no canal (ex: "Oi bot!")
   - Verifique logs para: "[Escutando áudio...]"
   - Bot deve responder em ~3-5 segundos

5. VERIFICAR RESPOSTA
   - Bot fala automaticamente
   - Verificar para: "✓ Áudio reproduzido"
   - Ouvir resposta sintetizada

6. TESTAR FILA
   a) Múltiplos usuários falam simultaneamente
   b) Bot processa um por vez (fila)
   c) Verificar: "Fila: X tarefas"

7. SAIR
   /sair
   Esperado: "Saí do canal de voz"

TESTES ADICIONAIS:
==================

TESTE 1: Contexto em Voz
- Você: "Meu nome é João"
- Bot: "Legal João!"
- Você: "Qual é meu nome?"
- Bot: Deve responder "João"

TESTE 2: Personalidade
- Você: "Fale sobre Roblox"
- Bot: Deve mencionar Roblox entusiasticamente

TESTE 3: Transcrição
- Fale lentamente: "Um, dois, três"
- Verificar logs: "Transcrito: Um dois três"

TESTE 4: TTS
- Escutar qualidade de síntese
- Verificar latência (<5s)

TESTE 5: Fila sob Stress
- 3+ pessoas falam simultaneamente
- Verificar: Fila processa todos
- Verificar: Nenhuma fala simultânea

MÉTRICAS ESPERADAS:
===================

Latência: 3-7 segundos (total)
  - STT (Whisper): 2-4s
  - IA (OpenAI): 1-2s
  - TTS (OpenAI): 1-2s

Qualidade Áudio:
  - Entrada: PCM 48kHz stereo
  - STT: 95%+ acurácia (português)
  - Saída: MP3 128kbps

Processamento:
  - Fila: 1 por vez (sem simultâneos)
  - CPU: <30% durante processamento
  - Memória: ~150MB estável

POSSÍVEIS ERROS:
================

"Bot entra mas não fala"
→ Verificar OPENAI_API_KEY
→ Verificar quota de TTS
→ Checar FFmpeg: ffmpeg -version

"Whisper tarda muito (> 10s)"
→ Primeiro uso baixa modelo
→ CPU fraco? Considere modelo tiny
→ Aumentar RAM se necessário

"Fila não processa"
→ Verificar logs para erros
→ Reiniciar bot
→ Checar conexão internet

"Áudio de entrada vazio"
→ Verifique permissões do bot
→ Tente /sair e /entrar novamente
→ Verifique volume do Discord

LOGS IMPORTANTES:
=================

✓ Sucesso: "✓ Conectado ao canal: #voice"
✓ Sucesso: "IA respondeu com: ..."
✓ Sucesso: "✓ Áudio reproduzido"

✗ Erro: "Erro ao conectar a voz:"
✗ Erro: "FFmpeg não encontrado"
✗ Erro: "OPENAI_API_KEY não configurada"

PRÓXIMO PASSO:
==============

Se tudo passou nos testes, FASE 7 está completa! ✨

Próximo: FASE 8 - Moderation
  - /kick, /ban, /mute
  - /timeout, /limpar
  - Logs de infrações
"""
