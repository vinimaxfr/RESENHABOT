"""
Gerenciador de conexões de voz — v3.

CORREÇÕES DESTA VERSÃO:
- channel.connect() já é bloqueante: quando retorna, o vc ESTÁ conectado.
  O loop de is_connected() era desnecessário e causava timeout falso.
- ffmpeg_path vem do bot.ffmpeg_path (resolvido no startup pelo ffmpeg_setup).
- Source of truth sempre é guild.voice_client.
"""

import asyncio
import os
import tempfile
import shutil
import discord
from typing import Optional
from utils.logger import setup_logger

logger = setup_logger(__name__)


def _get_ffmpeg(bot) -> str:
    """Pega o caminho do ffmpeg resolvido no startup."""
    path = getattr(bot, "ffmpeg_path", None)
    if path and path != "ffmpeg":
        return path
    # Fallback: tentar encontrar no sistema
    return shutil.which("ffmpeg") or "/usr/bin/ffmpeg" or "ffmpeg"


class VoiceManager:
    """Gerencia conexões de voz usando guild.voice_client como source of truth."""

    def __init__(self, bot=None):
        self.bot = bot

    # ─── Source of truth ─────────────────────────────────────────────────────

    def _vc(self, guild: discord.Guild) -> Optional[discord.VoiceClient]:
        """Retorna o VoiceClient ativo ou None."""
        vc = guild.voice_client
        return vc if (vc and vc.is_connected()) else None

    # ─── Conexão ─────────────────────────────────────────────────────────────

    async def connect(self, channel: discord.VoiceChannel) -> bool:
        """
        Conecta ao canal de voz.
        channel.connect() já é bloqueante — quando retorna o vc está pronto.
        """
        guild = channel.guild
        try:
            # Derrubar qualquer sessão existente
            existing = guild.voice_client
            if existing:
                try:
                    await existing.disconnect(force=True)
                except Exception:
                    pass
                await asyncio.sleep(0.8)  # Discord precisa processar o leave

            # Conectar — bloqueante, já retorna conectado
            vc = await channel.connect(timeout=60, reconnect=False)

            # Verificação de sanidade (não loop)
            if not vc.is_connected():
                # Em raríssimos casos o vc pode não estar connected ainda
                # Espera 1 segundo e testa de novo
                await asyncio.sleep(1.0)
                if not vc.is_connected():
                    logger.error(f"✗ vc retornou mas is_connected=False em {channel.name}")
                    try:
                        await vc.disconnect(force=True)
                    except Exception:
                        pass
                    return False

            logger.info(f"✓ Conectado ao canal: {channel.name}")
            return True

        except discord.ClientException as e:
            # "Already connected" — já estamos no canal certo?
            vc = self._vc(guild)
            if vc and vc.channel == channel:
                logger.info(f"✓ Já estava conectado em: {channel.name}")
                return True
            logger.error(f"ClientException ao conectar: {e}")
            return False
        except asyncio.TimeoutError:
            logger.error(f"✗ Timeout ao conectar em {channel.name} — verifique ffmpeg e PyNaCl")
            return False
        except Exception as e:
            logger.error(f"✗ Erro ao conectar a voz: {e}")
            return False

    # ─── Desconexão ──────────────────────────────────────────────────────────

    async def disconnect(self, guild_id: int, *, guild: Optional[discord.Guild] = None) -> bool:
        if guild is None:
            logger.warning("disconnect() sem objeto guild")
            return False
        try:
            vc = guild.voice_client
            if vc:
                await vc.disconnect(force=True)
                logger.info("✓ Desconectado")
                return True
            logger.warning(f"Não conectado no servidor {guild_id}")
            return False
        except Exception as e:
            logger.error(f"Erro ao desconectar: {e}")
            return False

    async def leave_voice(self, guild_id: int, *, guild: Optional[discord.Guild] = None) -> bool:
        return await self.disconnect(guild_id, guild=guild)

    # ─── Acesso ao vc ────────────────────────────────────────────────────────

    def get_voice_client(self, guild: discord.Guild) -> Optional[discord.VoiceClient]:
        return self._vc(guild)

    def is_connected(self, guild: discord.Guild) -> bool:
        return self._vc(guild) is not None

    # ─── Reprodução de áudio ─────────────────────────────────────────────────

    async def play_audio(self, guild: discord.Guild, audio_bytes: bytes) -> bool:
        vc = self._vc(guild)
        if not vc:
            logger.warning("play_audio: não conectado")
            return False
        if vc.is_playing():
            logger.warning("play_audio: já reproduzindo")
            return False

        ffmpeg_path = _get_ffmpeg(self.bot)
        try:
            with tempfile.NamedTemporaryFile(suffix=".mp3", delete=False) as f:
                f.write(audio_bytes)
                tmp_path = f.name

            def after_play(error):
                try:
                    os.unlink(tmp_path)
                except Exception:
                    pass
                if error:
                    logger.error(f"Erro ao tocar áudio: {error}")

            source = discord.FFmpegPCMAudio(
                tmp_path, executable=ffmpeg_path, options="-loglevel quiet"
            )
            vc.play(source, after=after_play)
            logger.info("✓ Reproduzindo áudio")
            return True
        except Exception as e:
            logger.error(f"Erro ao reproduzir áudio: {e}")
            return False


async def setup(bot):
    pass
