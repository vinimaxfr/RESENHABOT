"""
Cog principal de economia.
"""

import discord
from discord.ext import commands
from discord import app_commands
import random
from datetime import datetime, timedelta

from database.user_repository import UserRepository
from database.transaction_repository import TransactionRepository
from database.item_repository import ItemRepository
from database.inventory_repository import InventoryRepository
from database.models.transaction import TransactionModel, TransactionType
from utils.logger import setup_logger
from utils.embeds import EmbedHelper

logger = setup_logger(__name__)


class EconomyCog(commands.Cog):
    """Cog com todos os comandos de economia."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="daily", description="Receba sua recompensa diária!")
    async def daily_command(self, interaction: discord.Interaction) -> None:
        """Comando para receber recompensa diária."""
        await interaction.response.defer()

        try:
            user_repo = UserRepository(self.bot.db)
            transaction_repo = TransactionRepository(self.bot.db)

            await user_repo.create_tables()
            await transaction_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            # Verificar se já recebeu hoje
            if user.palo_last_measurement:
                last_daily = datetime.fromisoformat(user.palo_last_measurement)
                if last_daily.date() == datetime.now().date():
                    hours_left = 24 - (datetime.now() - last_daily).total_seconds() / 3600
                    embed = EmbedHelper.warning(
                        "Daily Já Reclamado",
                        f"Você já reclamou seu daily hoje! 💤\n\n"
                        f"Volte em **{hours_left:.1f} horas**.",
                        interaction.user
                    )
                    await interaction.followup.send(embed=embed)
                    return

            # Recompensa base
            reward = 1000

            # Bônus se tiver shield
            inv_repo = InventoryRepository(self.bot.db)
            await inv_repo.create_tables()
            shield = await inv_repo.get_item(interaction.user.id, interaction.guild.id, "shield")
            if shield and shield.quantity > 0:
                reward = int(reward * 1.25)  # +25%

            # Bônus se tiver golden_ticket
            golden_ticket = await inv_repo.get_item(
                interaction.user.id,
                interaction.guild.id,
                "golden_ticket"
            )
            if golden_ticket and golden_ticket.quantity > 0:
                reward *= 2

            user.money += reward
            user.palo_last_measurement = datetime.now().isoformat()
            await user_repo.update_user(user)

            # Registrar transação
            transaction = TransactionModel(
                discord_id=interaction.user.id,
                server_id=interaction.guild.id,
                transaction_type=TransactionType.DAILY.value,
                amount=reward,
                description="Daily reward reclamado"
            )
            await transaction_repo.add_transaction(transaction)

            embed = EmbedHelper.success(
                "Daily Reclamado!",
                f"Você recebeu **${reward:,}**! 💰\n\n"
                f"Novo saldo: **${user.money:,}**",
                interaction.user
            )
            await interaction.followup.send(embed=embed)

            logger.info(f"{interaction.user.display_name} reclamou daily: ${reward}")

        except Exception as e:
            logger.error(f"Erro ao reclamar daily: {e}")
            embed = EmbedHelper.error("Erro", f"Erro ao reclamar daily: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="carteira", description="Veja seu saldo")
    @app_commands.describe(usuario="Usuário para verificar (padrão: você)")
    async def wallet_command(
        self,
        interaction: discord.Interaction,
        usuario: discord.User = None
    ) -> None:
        """Visualiza o saldo da carteira."""
        await interaction.response.defer()

        try:
            target_user = usuario or interaction.user
            user_repo = UserRepository(self.bot.db)

            await user_repo.create_tables()
            user = await user_repo.get_or_create_user(target_user.id, target_user.display_name)

            embed = discord.Embed(
                title=f"💰 Carteira de {target_user.display_name}",
                color=discord.Color.gold(),
                timestamp=datetime.now()
            )

            embed.add_field(
                name="💵 Dinheiro na Carteira",
                value=f"**${user.money:,}**",
                inline=True
            )

            # Adicionar informação de rank
            rank = await user_repo.get_user_rank(target_user.id, "money")
            embed.add_field(
                name="🏆 Ranking",
                value=f"**#{rank}**",
                inline=True
            )

            embed.set_thumbnail(url=target_user.avatar.url)
            embed.set_footer(text=f"ID: {target_user.id}")

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro ao verificar carteira: {e}")
            embed = EmbedHelper.error("Erro", f"Erro ao verificar carteira: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="transferir",
        description="Transfira dinheiro para outro usuário"
    )
    @app_commands.describe(
        usuario="Usuário a receber a transferência",
        quantia="Quantidade de dinheiro"
    )
    async def transfer_command(
        self,
        interaction: discord.Interaction,
        usuario: discord.User,
        quantia: int
    ) -> None:
        """Transfere dinheiro entre usuários."""
        await interaction.response.defer()

        try:
            if usuario.id == interaction.user.id:
                embed = EmbedHelper.error(
                    "Erro",
                    "Você não pode transferir para si mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            if usuario.bot:
                embed = EmbedHelper.error(
                    "Erro",
                    "Você não pode transferir para bots!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            if quantia <= 0:
                embed = EmbedHelper.error(
                    "Erro",
                    "A quantia deve ser positiva!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            transaction_repo = TransactionRepository(self.bot.db)

            await user_repo.create_tables()
            await transaction_repo.create_tables()

            sender = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if sender.money < quantia:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você tem apenas **${sender.money:,}**",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Atualizar sender
            sender.money -= quantia
            await user_repo.update_user(sender)

            # Atualizar receiver
            receiver = await user_repo.get_or_create_user(usuario.id, usuario.display_name)
            receiver.money += quantia
            await user_repo.update_user(receiver)

            # Registrar transações
            sent_transaction = TransactionModel(
                discord_id=interaction.user.id,
                server_id=interaction.guild.id,
                transaction_type=TransactionType.TRANSFER_SENT.value,
                amount=quantia,
                description=f"Transferência para {usuario.display_name}",
                related_user_id=usuario.id
            )

            received_transaction = TransactionModel(
                discord_id=usuario.id,
                server_id=interaction.guild.id,
                transaction_type=TransactionType.TRANSFER_RECEIVED.value,
                amount=quantia,
                description=f"Transferência de {interaction.user.display_name}",
                related_user_id=interaction.user.id
            )

            await transaction_repo.add_transaction(sent_transaction)
            await transaction_repo.add_transaction(received_transaction)

            embed = EmbedHelper.success(
                "Transferência Realizada",
                f"Você transferiu **${quantia:,}** para {usuario.mention}!\n\n"
                f"Seu novo saldo: **${sender.money:,}**",
                interaction.user
            )

            await interaction.followup.send(embed=embed)
            logger.info(f"{interaction.user.display_name} transferiu ${quantia} para {usuario.display_name}")

        except Exception as e:
            logger.error(f"Erro ao transferir: {e}")
            embed = EmbedHelper.error("Erro", f"Erro ao transferir: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(
        name="roubo",
        description="Tente roubar dinheiro de alguém (50% de chance)"
    )
    @app_commands.describe(usuario="Usuário a roubar")
    async def robbery_command(
        self,
        interaction: discord.Interaction,
        usuario: discord.User
    ) -> None:
        """Comando de roubo."""
        await interaction.response.defer()

        try:
            if usuario.id == interaction.user.id:
                embed = EmbedHelper.error(
                    "Erro",
                    "Você não pode roubar de si mesmo!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            if usuario.bot:
                embed = EmbedHelper.error(
                    "Erro",
                    "Bots não têm dinheiro!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            transaction_repo = TransactionRepository(self.bot.db)
            inv_repo = InventoryRepository(self.bot.db)

            await user_repo.create_tables()
            await transaction_repo.create_tables()
            await inv_repo.create_tables()

            robber = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            target = await user_repo.get_or_create_user(usuario.id, usuario.display_name)

            if target.money < 100:
                embed = EmbedHelper.error(
                    "Vítima Pobre",
                    f"{usuario.display_name} tem menos de $100. Não vale a pena!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Chance de sucesso (50%)
            success = random.random() < 0.5

            # Modificador com magnifying glass
            magnifying = await inv_repo.get_item(
                interaction.user.id,
                interaction.guild.id,
                "magnifying_glass"
            )
            if magnifying and magnifying.quantity > 0:
                success = random.random() < 0.75  # 75%

            if success:
                # Quantidade roubada (10-30% do dinheiro da vítima)
                steal_amount = random.randint(
                    int(target.money * 0.1),
                    int(target.money * 0.3)
                )

                robber.money += steal_amount
                target.money -= steal_amount

                await user_repo.update_user(robber)
                await user_repo.update_user(target)

                # Registrar transações
                robber_trans = TransactionModel(
                    discord_id=interaction.user.id,
                    server_id=interaction.guild.id,
                    transaction_type=TransactionType.ROBBERY.value,
                    amount=steal_amount,
                    description=f"Roubo bem-sucedido de {usuario.display_name}",
                    related_user_id=usuario.id
                )

                victim_trans = TransactionModel(
                    discord_id=usuario.id,
                    server_id=interaction.guild.id,
                    transaction_type=TransactionType.ROBBERY.value,
                    amount=-steal_amount,
                    description=f"Roubado por {interaction.user.display_name}",
                    related_user_id=interaction.user.id
                )

                await transaction_repo.add_transaction(robber_trans)
                await transaction_repo.add_transaction(victim_trans)

                embed = EmbedHelper.success(
                    "Roubo Bem-Sucedido! 🎉",
                    f"Você roubou **${steal_amount:,}** de {usuario.mention}!\n\n"
                    f"Seu novo saldo: **${robber.money:,}**",
                    interaction.user
                )

                logger.info(f"{interaction.user.display_name} roubou ${steal_amount} de {usuario.display_name}")

            else:
                embed = EmbedHelper.error(
                    "Roubo Fracassado! 😅",
                    f"Você foi pego tentando roubar {usuario.mention}!\n\n"
                    f"Sorte sua vez, coitado...",
                    interaction.user
                )

                logger.info(f"{interaction.user.display_name} tentou roubar {usuario.display_name} e falhou")

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro ao roubar: {e}")
            embed = EmbedHelper.error("Erro", f"Erro ao roubar: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="trabalho", description="Trabalhe para ganhar dinheiro")
    async def work_command(self, interaction: discord.Interaction) -> None:
        """Comando de trabalho."""
        await interaction.response.defer()

        try:
            user_repo = UserRepository(self.bot.db)
            transaction_repo = TransactionRepository(self.bot.db)

            await user_repo.create_tables()
            await transaction_repo.create_tables()

            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            # Ganho de trabalho (50-200)
            salary = random.randint(50, 200)

            user.money += salary
            await user_repo.update_user(user)

            # Registrar transação
            transaction = TransactionModel(
                discord_id=interaction.user.id,
                server_id=interaction.guild.id,
                transaction_type=TransactionType.SALARY.value,
                amount=salary,
                description="Ganho de trabalho"
            )
            await transaction_repo.add_transaction(transaction)

            messages = [
                f"Você trabalhou duro e ganhou **${salary}**! 💪",
                f"Que dia produtivo! Você ganhou **${salary}**! 😊",
                f"Trabalho realizado! **${salary}** para você! 🎯",
                f"Bom trabalho! Ganhou **${salary}**! ⭐",
            ]

            embed = EmbedHelper.success(
                "Trabalho Concluído!",
                f"{random.choice(messages)}\n\n"
                f"Novo saldo: **${user.money:,}**",
                interaction.user
            )

            await interaction.followup.send(embed=embed)
            logger.info(f"{interaction.user.display_name} trabalhou e ganhou ${salary}")

        except Exception as e:
            logger.error(f"Erro ao trabalhar: {e}")
            embed = EmbedHelper.error("Erro", f"Erro ao trabalhar: {str(e)}")
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(EconomyCog(bot))
