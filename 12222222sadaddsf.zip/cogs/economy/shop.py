"""
Cog com comandos de loja e inventário.
"""

import discord
from discord.ext import commands
from discord import app_commands
from datetime import datetime

from database.user_repository import UserRepository
from database.item_repository import ItemRepository
from database.inventory_repository import InventoryRepository
from database.transaction_repository import TransactionRepository
from database.models.transaction import TransactionModel, TransactionType
from utils.logger import setup_logger
from utils.embeds import EmbedHelper

logger = setup_logger(__name__)


class ShopCog(commands.Cog):
    """Cog com comandos de loja e inventário."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="loja", description="Veja os itens disponíveis na loja")
    async def shop_command(self, interaction: discord.Interaction) -> None:
        """Visualiza a loja."""
        await interaction.response.defer()

        try:
            item_repo = ItemRepository(self.bot.db)
            await item_repo.create_tables()

            items = await item_repo.get_all_items()

            embed = discord.Embed(
                title="🏪 Loja Disponível",
                color=discord.Color.purple(),
                timestamp=datetime.now()
            )

            # Agrupar por raridade
            rarities = {
                "comum": [],
                "raro": [],
                "épico": [],
                "lendário": [],
            }

            for item in items:
                rarities[item.rarity].append(item)

            # Construir descrição
            description = ""

            for rarity_name, rarity_items in rarities.items():
                if rarity_items:
                    if rarity_name == "comum":
                        emoji = "⚪"
                    elif rarity_name == "raro":
                        emoji = "🔵"
                    elif rarity_name == "épico":
                        emoji = "🟣"
                    else:
                        emoji = "🟡"

                    description += f"\n{emoji} **{rarity_name.upper()}**\n"

                    for item in rarity_items:
                        description += f"{item.emoji} **{item.name}** - ${item.price:,}\n"
                        description += f"   _{item.description}_\n"

            embed.description = description

            embed.add_field(
                name="💡 Como Comprar",
                value="Use `/comprar <item_id>` para comprar um item\n"
                      "Use `/inventario` para ver seus itens",
                inline=False
            )

            await interaction.followup.send(embed=embed)

        except Exception as e:
            logger.error(f"Erro ao visualizar loja: {e}")
            embed = EmbedHelper.error("Erro", f"Erro ao visualizar loja: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="comprar", description="Compre um item da loja")
    @app_commands.describe(
        item="ID do item a comprar",
        quantidade="Quantidade a comprar (padrão: 1)"
    )
    async def buy_command(
        self,
        interaction: discord.Interaction,
        item: str,
        quantidade: int = 1
    ) -> None:
        """Compra um item da loja."""
        await interaction.response.defer()

        try:
            if quantidade <= 0:
                embed = EmbedHelper.error(
                    "Erro",
                    "A quantidade deve ser maior que 0!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            user_repo = UserRepository(self.bot.db)
            item_repo = ItemRepository(self.bot.db)
            inv_repo = InventoryRepository(self.bot.db)
            transaction_repo = TransactionRepository(self.bot.db)

            await user_repo.create_tables()
            await item_repo.create_tables()
            await inv_repo.create_tables()
            await transaction_repo.create_tables()

            # Obter item
            shop_item = await item_repo.get_item(item)
            if not shop_item:
                embed = EmbedHelper.error(
                    "Erro",
                    f"Item '{item}' não encontrado!",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Calcular custo total
            total_cost = shop_item.price * quantidade

            # Verificar saldo
            user = await user_repo.get_or_create_user(
                interaction.user.id,
                interaction.user.display_name
            )

            if user.money < total_cost:
                embed = EmbedHelper.error(
                    "Saldo Insuficiente",
                    f"Você precisa de **${total_cost:,}** mas tem apenas **${user.money:,}**",
                    interaction.user
                )
                await interaction.followup.send(embed=embed)
                return

            # Descontar dinheiro
            user.money -= total_cost
            await user_repo.update_user(user)

            # Adicionar item ao inventário
            await inv_repo.add_item(
                interaction.user.id,
                interaction.guild.id,
                shop_item.item_id,
                quantidade
            )

            # Registrar transação
            transaction = TransactionModel(
                discord_id=interaction.user.id,
                server_id=interaction.guild.id,
                transaction_type=TransactionType.PURCHASE.value,
                amount=total_cost,
                description=f"Compra de {quantidade}x {shop_item.name}"
            )
            await transaction_repo.add_transaction(transaction)

            embed = EmbedHelper.success(
                "Compra Realizada!",
                f"Você comprou **{quantidade}x {shop_item.emoji} {shop_item.name}**\n\n"
                f"Custo: **${total_cost:,}**\n"
                f"Novo saldo: **${user.money:,}**",
                interaction.user
            )

            await interaction.followup.send(embed=embed)
            logger.info(f"{interaction.user.display_name} comprou {quantidade}x {shop_item.name}")

        except Exception as e:
            logger.error(f"Erro ao comprar: {e}")
            embed = EmbedHelper.error("Erro", f"Erro ao comprar: {str(e)}")
            await interaction.followup.send(embed=embed)

    @app_commands.command(name="inventario", description="Veja seu inventário")
    @app_commands.describe(usuario="Usuário para verificar (padrão: você)")
    async def inventory_command(
        self,
        interaction: discord.Interaction,
        usuario: discord.User = None
    ) -> None:
        """Visualiza o inventário."""
        await interaction.response.defer()

        try:
            target_user = usuario or interaction.user
            inv_repo = InventoryRepository(self.bot.db)
            item_repo = ItemRepository(self.bot.db)

            await inv_repo.create_tables()
            await item_repo.create_tables()

            inventory = await inv_repo.get_user_inventory(target_user.id, interaction.guild.id)

            embed = discord.Embed(
                title=f"🎒 Inventário de {target_user.display_name}",
                color=discord.Color.green(),
                timestamp=datetime.now()
            )

            if not inventory:
                embed.description = "Inventário vazio! 😢"
            else:
                description = ""
                for inv_item in inventory:
                    shop_item = await item_repo.get_item(inv_item.item_id)
                    if shop_item:
                        description += (
                            f"{shop_item.emoji} **{shop_item.name}** (x{inv_item.quantity})\n"
                            f"   _{shop_item.description}_\n"
                        )

                embed.description = description

            embed.set_thumbnail(url=target_user.avatar.url)

            await interaction.followup.send(embed=embed)
            logger.info(f"Inventário de {target_user.display_name} visualizado")

        except Exception as e:
            logger.error(f"Erro ao visualizar inventário: {e}")
            embed = EmbedHelper.error("Erro", f"Erro ao visualizar inventário: {str(e)}")
            await interaction.followup.send(embed=embed)


async def setup(bot: commands.Bot) -> None:
    """Setup do cog."""
    await bot.add_cog(ShopCog(bot))
