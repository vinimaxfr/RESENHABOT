"""
QUICK REFERENCE - FASE 8 MODERATION

6 COMANDOS:
===========

1️⃣ /kick @user [reason]
   Remove do servidor. Pode retornar.

2️⃣ /ban @user [reason] [delete_days]
   Bane permanentemente. Max 7 dias de cleanup.

3️⃣ /mute @user <minutes> [reason]
   Silencia por N minutos. Max 40320 (28 dias).

4️⃣ /timeout @user <minutes> [reason]
   ALIAS para /mute. Mesmo funcionamento.

5️⃣ /limpar <count>
   Deleta 2-100 mensagens. Sem registrar.

6️⃣ /avisar @user [reason]
   Aviso progressivo. Alerta em #3.

BANCO DE DADOS:
===============

Tabela: infractions
├── id
├── discord_id
├── server_id
├── infraction_type (kick|ban|mute|warn)
├── reason
├── moderator_id
└── created_at

PERMISSÕES NECESSÁRIAS:
=======================

Bot precisa de:
✅ Manage Members
✅ Kick Members
✅ Ban Members
✅ Moderate Members
✅ Manage Messages

VALIDAÇÕES:
===========

❌ Não pode fazer em si mesmo
❌ Não pode fazer no bot
❌ Role não pode ser >= sua role
❌ Deve ter permissão appropriada
❌ Parâmetros dentro range

EXEMPLOS:
=========

/kick @spammer Spam demais
/ban @troll Comportamento tóxico delete_days:3
/mute @user 60 Flood
/timeout @user 30 Spam
/limpar 50
/avisar @user Aviso 1

ARQUIVO ESTRUTURA:
==================

cogs/moderation/
├── __init__.py (carrega ModerationCog)
├── moderation.py (6 comandos)
├── MODERATION_GUIDE.md
├── PHASE8_SUMMARY.md
├── MODERATION_TESTING.md
└── IMPLEMENTATION_CHECKLIST.md

database/
├── infraction_repository.py (novo)
└── __init__.py (atualizado)

main.py (atualizado)

INTEGRAÇÕES:
============

✅ Database: InfractionRepository
✅ Logger: setup_logger
✅ Embeds: EmbedHelper
✅ Permissions: @app_commands.checks
✅ Discord API: kick, ban, mute/timeout

STATS:
======

Linhas de código: ~750
Documentação: ~500
Total: ~1250

Tempo desenvolvimento: ~2 horas
Comandos: 6
Validações: 15+
Error cases: 10+

PRONTO PARA TESTE? ✨

Ver: cogs/moderation/MODERATION_TESTING.md
"""
