# Resenha Bot 🤖

Um bot Discord profissional e escalável com sistema de economia, minijogos, IA com contexto e suporte a voz.

## 🚀 Características

### 🎮 Diversão
- Minijogos (Cara/Coroa, Dado, Pedra/Papel/Tesoura, Roleta, Quiz, Adivinhar Número, Blackjack)
- Comando `/medir_palo` com eventos especiais (Jackpot, Falha Crítica, Multiplicador, Lendário)
- Sistema de ranking

### 💰 Economia
- Carteira e Banco
- Transferências entre usuários
- Trabalho diário
- Sistema de roubo
- Loja com itens
- Inventário

### 🧠 IA
- Respostas contextualizadas
- Memória por usuário
- Memória por servidor
- Personalidade engraçada e amigável

### 🎙️ Voz
- Entrada automática em call
- Reconhecimento de voz (Faster Whisper)
- Conversão de texto para voz
- Respostas automáticas

### 🛡️ Moderação
- Kick, Ban, Mute
- Timeout
- Limpar mensagens
- Sistema de avisos
- Logs completos

## 📋 Requisitos

- Python 3.13+
- Discord Bot Token
- OpenAI API Key (para IA)
- FFmpeg (para voz)

## 📦 Instalação

1. Clone o repositório
```bash
git clone https://github.com/seu-usuario/resenha-bot.git
cd resenha-bot
```

2. Crie um ambiente virtual
```bash
python -m venv venv
source venv/bin/activate  # No Windows: venv\Scripts\activate
```

3. Instale as dependências
```bash
pip install -r requirements.txt
```

4. Configure as variáveis de ambiente
```bash
cp .env.example .env
# Edite .env com suas configurações
```

5. Execute o bot
```bash
python main.py
```

## 🏗️ Arquitetura

```
ResenhaBot/
├── config/              # Configurações
├── database/            # Gerenciamento de BD
├── cogs/               # Módulos de funcionalidades
│   ├── events/         # Eventos do bot
│   ├── fun/            # Minijogos
│   ├── economy/        # Sistema de economia
│   ├── moderation/     # Moderação
│   ├── ai/             # IA e respostas
│   └── voice/          # Voz
├── utils/              # Utilitários
├── logs/               # Arquivos de log
├── assets/             # Recursos (imagens, etc)
└── main.py             # Ponto de entrada
```

## 📝 Comandos

### Perfil
- `/perfil` - Ver seu perfil
- `/ranking` - Ver rankings

### Economia
- `/daily` - Receber recompensa diária
- `/carteira` - Ver saldo
- `/banco` - Ver saldo no banco
- `/transferir` - Transferir dinheiro
- `/loja` - Ver loja
- `/comprar` - Comprar item
- `/inventário` - Ver inventário

### Minijogos
- `/cara_ou_coroa` - Cara ou Coroa
- `/dado` - Jogar dado
- `/pedra_papel_tesoura` - Jogo clássico
- `/roleta` - Roleta da sorte
- `/quiz` - Quiz
- `/adivinhar_numero` - Adivinhar número
- `/blackjack` - Blackjack
- `/medir_palo` - Medir "palo" (uma por dia)

### Moderação
- `/kick` - Expulsar usuário
- `/ban` - Banir usuário
- `/mute` - Silenciar usuário
- `/timeout` - Timeout do usuário
- `/limpar` - Limpar mensagens
- `/avisar` - Avisar usuário

### Voz
- `/entrar` - Bot entra em call
- `/sair` - Bot sai de call

## ⚙️ Configuração

Edite o arquivo `.env` com:

```env
DISCORD_TOKEN=seu_token_aqui
DISCORD_GUILD_ID=seu_server_id
OPENAI_API_KEY=sua_chave_openai
DATABASE_PATH=./database/resenhabot.db
BOT_PREFIX=!
LOG_LEVEL=INFO
ENABLE_VOICE_FEATURES=true
```

## 🤝 Contribuindo

Contribuições são bem-vindas! Sinta-se livre para abrir issues e pull requests.

## 📄 Licença

Este projeto está licenciado sob a Licença MIT.

## 📧 Suporte

Para suporte, abra uma issue no repositório ou entre em contato.

---

**Desenvolvido com ❤️ usando discord.py**
