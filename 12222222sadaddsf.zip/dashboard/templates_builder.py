"""
Templates HTML para dashboard.
"""

TEMPLATES = {
    "index.html": """<!DOCTYPE html>
<html>
<head>
    <title>Resenha Bot Dashboard</title>
    <style>
        body { font-family: Arial; margin: 20px; background: #1e1e1e; color: #fff; }
        .container { max-width: 1200px; margin: 0 auto; }
        h1 { color: #7289da; }
        .section { background: #2c2f33; padding: 20px; margin: 20px 0; border-radius: 5px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #444; }
        th { background: #7289da; }
        tr:hover { background: #3c3f43; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🤖 Resenha Bot Dashboard</h1>
        
        <div class="section">
            <h2>💰 Top Economia</h2>
            <table id="moneyTable">
                <thead>
                    <tr><th>Usuário</th><th>Dinheiro</th><th>XP</th><th>Level</th></tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <div class="section">
            <h2>⚠️ Top Infrações</h2>
            <input type="number" id="serverId" placeholder="Server ID" value="123456">
            <button onclick="loadInfractions()">Carregar</button>
            <table id="infractionsTable">
                <thead>
                    <tr><th>Usuário</th><th>Infrações</th></tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <div class="section">
            <h2>👮 Top Moderadores</h2>
            <table id="moderatorsTable">
                <thead>
                    <tr><th>Moderador</th><th>Ações</th></tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

    <script>
        async function loadMoney() {
            const res = await fetch('/api/rankings/money');
            const data = await res.json();
            const tbody = document.querySelector('#moneyTable tbody');
            tbody.innerHTML = data.map(u => `
                <tr>
                    <td>${u.name}</td>
                    <td>$${u.money}</td>
                    <td>${u.xp}</td>
                    <td>${u.level}</td>
                </tr>
            `).join('');
        }

        async function loadInfractions() {
            const serverId = document.querySelector('#serverId').value;
            const res = await fetch(`/api/rankings/infractions/${serverId}`);
            const data = await res.json();
            const tbody = document.querySelector('#infractionsTable tbody');
            tbody.innerHTML = data.map(u => `
                <tr>
                    <td>${u.name}</td>
                    <td>${u.total}</td>
                </tr>
            `).join('');
        }

        async function loadModerators() {
            const serverId = document.querySelector('#serverId').value;
            const res = await fetch(`/api/rankings/moderators/${serverId}`);
            const data = await res.json();
            const tbody = document.querySelector('#moderatorsTable tbody');
            tbody.innerHTML = data.map(u => `
                <tr>
                    <td>${u.name}</td>
                    <td>${u.total}</td>
                </tr>
            `).join('');
        }

        loadMoney();
    </script>
</body>
</html>
"""
}


def create_templates():
    """Cria arquivos de template."""
    import os
    template_dir = os.path.join(os.path.dirname(__file__), "templates")
    os.makedirs(template_dir, exist_ok=True)
    
    for name, content in TEMPLATES.items():
        path = os.path.join(template_dir, name)
        with open(path, 'w') as f:
            f.write(content)
