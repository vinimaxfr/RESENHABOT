"""
__init__.py for dashboard module.
"""

from .dashboard import ResenhaDashboard
from .templates_builder import create_templates

__all__ = ["ResenhaDashboard", "create_templates"]
