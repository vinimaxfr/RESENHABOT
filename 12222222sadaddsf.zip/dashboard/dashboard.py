"""
Web dashboard para Resenha Bot com Flask.
"""

from flask import Flask, render_template, jsonify
from database.manager import DatabaseManager
from database.advanced_ranking_repository import AdvancedRankingRepository
from database.infraction_repository import InfractionRepository
from database.user_repository import UserRepository
import asyncio
from config.settings import Settings
from utils.logger import setup_logger

logger = setup_logger(__name__)


class ResenhaDashboard:
    """Dashboard web para o bot."""

    def __init__(self, db: DatabaseManager):
        self.db = db
        self.app = Flask(__name__)
        self.ranking_repo = AdvancedRankingRepository(db)
        self.infraction_repo = InfractionRepository(db)
        self.user_repo = UserRepository(db)
        self._setup_routes()

    def _setup_routes(self):
        """Configura rotas da API."""

        @self.app.route("/")
        def index():
            """Página inicial."""
            return render_template("index.html")

        @self.app.route("/api/rankings/money")
        def api_money_ranking():
            """Ranking por dinheiro."""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                rows = loop.run_until_complete(
                    self.db.fetch_all(
                        """SELECT discord_id, name, money, xp, level FROM users 
                           ORDER BY money DESC LIMIT 20"""
                    )
                )
                
                data = [dict(row) for row in rows] if rows else []
                return jsonify(data)
            except Exception as e:
                logger.error(f"Erro em /api/rankings/money: {e}")
                return jsonify({"error": str(e)}), 500

        @self.app.route("/api/rankings/infractions/<int:server_id>")
        def api_infractions(server_id):
            """Ranking por infrações."""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                data = loop.run_until_complete(
                    self.ranking_repo.get_top_by_infractions(server_id)
                )
                
                return jsonify(data)
            except Exception as e:
                logger.error(f"Erro em /api/rankings/infractions: {e}")
                return jsonify({"error": str(e)}), 500

        @self.app.route("/api/rankings/moderators/<int:server_id>")
        def api_moderators(server_id):
            """Ranking de moderadores."""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                data = loop.run_until_complete(
                    self.ranking_repo.get_top_by_moderations(server_id)
                )
                
                return jsonify(data)
            except Exception as e:
                logger.error(f"Erro em /api/rankings/moderators: {e}")
                return jsonify({"error": str(e)}), 500

        @self.app.route("/api/user/<int:user_id>")
        def api_user(user_id):
            """Info de usuário."""
            try:
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                
                user = loop.run_until_complete(
                    self.user_repo.get_user(user_id)
                )
                
                if not user:
                    return jsonify({"error": "Usuário não encontrado"}), 404
                
                return jsonify(dict(user))
            except Exception as e:
                logger.error(f"Erro em /api/user: {e}")
                return jsonify({"error": str(e)}), 500

    def run(self, host: str = "127.0.0.1", port: int = 5000, debug: bool = False):
        """Inicia o dashboard."""
        logger.info(f"🌐 Dashboard iniciando em http://{host}:{port}")
        self.app.run(host=host, port=port, debug=debug)
