"""
Utilitários de tipos e validações.
"""

from typing import Optional
from discord import User, Member


async def get_user_or_member(ctx_or_interaction, user_id: int) -> Optional[User | Member]:
    """
    Obtém um usuário ou membro por ID.

    Args:
        ctx_or_interaction: Contexto ou interação do Discord
        user_id: ID do usuário

    Returns:
        User ou Member se encontrado, None caso contrário
    """
    try:
        return await ctx_or_interaction.bot.fetch_user(user_id)
    except Exception:
        return None
