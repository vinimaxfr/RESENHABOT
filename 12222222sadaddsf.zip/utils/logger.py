"""
Sistema de logging para o Resenha Bot.
"""

import logging
from pathlib import Path
from config.settings import Settings


def setup_logger(name: str) -> logging.Logger:
    """
    Configura um logger para o módulo especificado.

    Args:
        name: Nome do logger (geralmente __name__)

    Returns:
        logging.Logger: Logger configurado
    """
    logger = logging.getLogger(name)
    logger.setLevel(Settings.LOG_LEVEL)

    # Criar diretório de logs se não existir
    Settings.LOGS_DIR.mkdir(exist_ok=True)

    # Handler para arquivo
    log_file = Settings.LOGS_DIR / "resenhabot.log"
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(Settings.LOG_LEVEL)

    # Handler para console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(Settings.LOG_LEVEL)

    # Formatter
    formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%d/%m/%Y %H:%M:%S"
    )

    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Adicionar handlers se não existirem
    if not logger.handlers:
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

    return logger
