"""
Decoradores úteis para o Resenha Bot.
"""

import functools
from typing import Any, Callable, Dict, Optional
from datetime import datetime, timedelta


def async_cache(ttl: int = 300) -> Callable:
    """
    Decorador para cache de funções assincronas.

    Args:
        ttl: Tempo de vida do cache em segundos (padrão: 5 minutos)

    Returns:
        Função decorada com cache
    """
    cache: Dict[tuple, tuple[Any, datetime]] = {}

    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        async def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Criar chave do cache
            key = (args, tuple(sorted(kwargs.items())))

            # Verificar se está em cache e ainda é válido
            if key in cache:
                cached_value, expiry_time = cache[key]
                if datetime.now() < expiry_time:
                    return cached_value

            # Executar função e cachear resultado
            result = await func(*args, **kwargs)
            cache[key] = (result, datetime.now() + timedelta(seconds=ttl))

            return result

        return wrapper

    return decorator
