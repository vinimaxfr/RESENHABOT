"""
Decorator para aplicar cooldown em comandos.
"""

import discord
from discord.ext import commands
from discord import app_commands
from datetime import timedelta


def cooldown_slash(seconds: int = 3):
    """Decorator para cooldown em slash commands."""
    return app_commands.checks.cooldown(1, seconds)


# Exemplo de uso:
# @app_commands.command()
# @cooldown_slash(5)
# async def meu_comando(self, interaction: discord.Interaction):
#     ...
