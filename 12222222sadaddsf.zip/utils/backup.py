"""
Utilitário para backup automático do BD.
"""

import shutil
from pathlib import Path
from datetime import datetime
from config.settings import Settings
from utils.logger import setup_logger

logger = setup_logger(__name__)


def backup_database() -> bool:
    """Faz backup do banco de dados."""
    try:
        db_path = Path(Settings.DATABASE_PATH)
        backup_dir = Path("./backups")
        backup_dir.mkdir(exist_ok=True)

        # Criar nome com timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = backup_dir / f"resenhabot_{timestamp}.db"

        # Copiar arquivo
        shutil.copy2(db_path, backup_file)

        # Manter apenas últimos 7 backups
        backups = sorted(backup_dir.glob("resenhabot_*.db"))
        if len(backups) > 7:
            for old_backup in backups[:-7]:
                old_backup.unlink()

        logger.info(f"✓ Backup criado: {backup_file}")
        return True

    except Exception as e:
        logger.error(f"Erro ao fazer backup: {e}")
        return False


def restore_database(backup_file: str) -> bool:
    """Restaura banco de dados de um backup."""
    try:
        backup_path = Path(backup_file)
        db_path = Path(Settings.DATABASE_PATH)

        if not backup_path.exists():
            logger.error(f"Backup não encontrado: {backup_file}")
            return False

        # Copiar backup sobre o BD atual
        shutil.copy2(backup_path, db_path)
        logger.info(f"✓ BD restaurado de: {backup_file}")
        return True

    except Exception as e:
        logger.error(f"Erro ao restaurar BD: {e}")
        return False
