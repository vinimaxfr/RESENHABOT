"""
Utilitários para embeds do Discord.
"""

import discord
from typing import Optional
from datetime import datetime


class EmbedHelper:
    """Auxiliar para criar embeds consistentes."""

    @staticmethod
    def success(title: str, description: str, user: Optional[discord.User] = None) -> discord.Embed:
        """Cria um embed de sucesso."""
        embed = discord.Embed(
            title=f"✅ {title}",
            description=description,
            color=discord.Color.green(),
            timestamp=datetime.now()
        )
        if user:
            embed.set_footer(text=f"Solicitado por {user}", icon_url=user.avatar.url)
        return embed

    @staticmethod
    def error(title: str, description: str, user: Optional[discord.User] = None) -> discord.Embed:
        """Cria um embed de erro."""
        embed = discord.Embed(
            title=f"❌ {title}",
            description=description,
            color=discord.Color.red(),
            timestamp=datetime.now()
        )
        if user:
            embed.set_footer(text=f"Solicitado por {user}", icon_url=user.avatar.url)
        return embed

    @staticmethod
    def info(title: str, description: str, user: Optional[discord.User] = None) -> discord.Embed:
        """Cria um embed de informação."""
        embed = discord.Embed(
            title=f"ℹ️ {title}",
            description=description,
            color=discord.Color.blue(),
            timestamp=datetime.now()
        )
        if user:
            embed.set_footer(text=f"Solicitado por {user}", icon_url=user.avatar.url)
        return embed

    @staticmethod
    def warning(title: str, description: str, user: Optional[discord.User] = None) -> discord.Embed:
        """Cria um embed de aviso."""
        embed = discord.Embed(
            title=f"⚠️ {title}",
            description=description,
            color=discord.Color.orange(),
            timestamp=datetime.now()
        )
        if user:
            embed.set_footer(text=f"Solicitado por {user}", icon_url=user.avatar.url)
        return embed
