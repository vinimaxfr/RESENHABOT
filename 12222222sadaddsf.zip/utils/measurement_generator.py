"""
Gerador de eventos e mensagens para o /medir_palo.
"""

import random
from typing import Tuple
from config.settings import Settings
from database.models.measurement import EventType
from utils.logger import setup_logger

logger = setup_logger(__name__)


# Mensagens engraçadas por tipo de evento
NORMAL_MESSAGES = [
    "Hoje você acordou... normal.",
    "Nada de especial aconteceu.",
    "Mais um dia comum.",
    "Medida comum de um dia comum.",
    "Sem surpresas hoje.",
    "Temperatura ambiente.",
]

JACKPOT_MESSAGES = [
    "🎰 JACKPOT! Vou chamar a imprensa!",
    "🍆 EXPLOSION! O pênis explodiu de alegria!",
    "💥 MUUUITO BOM! Você acertou na loteria!",
    "🎊 PARABÉNS! Você merecia isso!",
    "🌟 ÉPICO! Máximo histórico desbloqueado!",
    "⚡ BERSERK MODE ATIVADO!",
]

CRITICAL_FAIL_MESSAGES = [
    "💀 FALHA CRÍTICA! Que desastre!",
    "😰 Ohhh não! Pirou completamente!",
    "❌ CATASTROFE! Encolheu demais!",
    "🔻 CRASH! Sistema falhou!",
    "😭 Triste demais, até eu chorei!",
    "💔 Coração partido, assim como o pênis!",
]

MULTIPLIER_MESSAGES = [
    "✖️ 2X! Pontos dobrados!",
    "⭐ MULTIPLICADOR ATIVADO!",
    "🚀 BOOOOOST! Ganho em dobro!",
    "🎯 CRÍTICO! Acertou em cheio!",
    "💪 FORÇA TOTAL! Efeito amplificado!",
    "🔥 HOT! Triplicando o prazer!",
]

LEGENDARY_MESSAGES = [
    "👑 LENDÁRIO! Você se tornou uma lenda!",
    "🌈 ARCO-ÍRIS! Eventos cósmicos ocorreram!",
    "🦄 UNICÓRNIO! Impossível, mas aconteceu!",
    "🌟 SUPERNOVA! Brilho intergaláctico!",
    "⚔️ ÉPICO! Digno de músicas!",
    "🏆 HISTÓRICO! Página dos recordes!",
]


class MeasurementEventGenerator:
    """Gera eventos e mensagens para medições."""

    @staticmethod
    def generate_event() -> Tuple[EventType, str, int]:
        """
        Gera um evento aleatório com chance definida.

        Returns:
            Tupla com (tipo_evento, mensagem, multiplicador)
        """
        roll = random.random()

        # Lendário (2%)
        if roll < Settings.LEGENDARY_CHANCE:
            base_gain = random.randint(10, 30)
            gain = base_gain * random.choice([1, 2, 3])
            message = random.choice(LEGENDARY_MESSAGES)
            return EventType.LEGENDARY, message, gain

        # Jackpot (5%)
        elif roll < Settings.LEGENDARY_CHANCE + Settings.JACKPOT_CHANCE:
            gain = Settings.MEDIR_PALO_MAX_GAIN
            message = random.choice(JACKPOT_MESSAGES)
            return EventType.JACKPOT, message, gain

        # Falha Crítica (10%)
        elif roll < Settings.LEGENDARY_CHANCE + Settings.JACKPOT_CHANCE + Settings.CRITICAL_FAIL_CHANCE:
            gain = Settings.MEDIR_PALO_MIN_GAIN
            message = random.choice(CRITICAL_FAIL_MESSAGES)
            return EventType.CRITICAL_FAIL, message, gain

        # Multiplicador (15%)
        elif roll < Settings.LEGENDARY_CHANCE + Settings.JACKPOT_CHANCE + Settings.CRITICAL_FAIL_CHANCE + Settings.MULTIPLIER_CHANCE:
            base_gain = random.randint(5, 20)
            gain = base_gain * 2
            message = random.choice(MULTIPLIER_MESSAGES)
            return EventType.MULTIPLIER, message, gain

        # Normal
        else:
            gain = random.randint(
                Settings.MEDIR_PALO_MIN_GAIN,
                Settings.MEDIR_PALO_MAX_GAIN
            )
            message = random.choice(NORMAL_MESSAGES)
            return EventType.NORMAL, message, gain

    @staticmethod
    def get_event_emoji(event_type: EventType) -> str:
        """
        Retorna o emoji para um tipo de evento.

        Args:
            event_type: Tipo do evento

        Returns:
            Emoji correspondente
        """
        emojis = {
            EventType.NORMAL: "📏",
            EventType.JACKPOT: "🎰",
            EventType.CRITICAL_FAIL: "💀",
            EventType.MULTIPLIER: "✖️",
            EventType.LEGENDARY: "👑",
        }
        return emojis.get(event_type, "❓")

    @staticmethod
    def get_event_color(event_type: EventType) -> int:
        """
        Retorna a cor (int) para um tipo de evento no Discord.

        Args:
            event_type: Tipo do evento

        Returns:
            Cor em hexadecimal (int)
        """
        colors = {
            EventType.NORMAL: 0x3498DB,          # Azul
            EventType.JACKPOT: 0xF1C40F,         # Ouro
            EventType.CRITICAL_FAIL: 0xE74C3C,  # Vermelho
            EventType.MULTIPLIER: 0x2ECC71,     # Verde
            EventType.LEGENDARY: 0x9B59B6,      # Roxo
        }
        return colors.get(event_type, 0x95A5A6)
