"""
Utilitários para minijogos.
"""

import random
from typing import List, Tuple


class MinigameUtils:
    """Utilitários para minijogos."""

    # Perguntas de Quiz
    QUIZ_QUESTIONS = [
        {
            "question": "Qual é a capital da França?",
            "options": ["Paris", "Lyon", "Marselha", "Nice"],
            "answer": 0,
        },
        {
            "question": "Quantos continentes existem?",
            "options": ["5", "6", "7", "8"],
            "answer": 2,
        },
        {
            "question": "Qual é o planeta mais próximo do Sol?",
            "options": ["Vênus", "Mercúrio", "Marte", "Terra"],
            "answer": 1,
        },
        {
            "question": "Em que ano caiu o Muro de Berlim?",
            "options": ["1987", "1988", "1989", "1990"],
            "answer": 2,
        },
        {
            "question": "Qual é o maior oceano do mundo?",
            "options": ["Atlântico", "Índico", "Pacífico", "Ártico"],
            "answer": 2,
        },
        {
            "question": "Quantos lados tem um hexágono?",
            "options": ["5", "6", "7", "8"],
            "answer": 1,
        },
        {
            "question": "Qual é a moeda do Japão?",
            "options": ["Won", "Iene", "Rúpia", "Baht"],
            "answer": 1,
        },
        {
            "question": "Quantas cores tem o arco-íris?",
            "options": ["5", "6", "7", "8"],
            "answer": 2,
        },
        {
            "question": "Qual é o maior deserto do mundo?",
            "options": ["Saara", "Gobi", "Kalahari", "Antártida"],
            "answer": 0,
        },
        {
            "question": "Em que ano terminou a Segunda Guerra Mundial?",
            "options": ["1943", "1944", "1945", "1946"],
            "answer": 2,
        },
    ]

    @staticmethod
    def get_random_quiz() -> dict:
        """Retorna uma pergunta aleatória do quiz."""
        return random.choice(MinigameUtils.QUIZ_QUESTIONS)

    @staticmethod
    def calculate_win(initial_bet: int, multiplier: float = 2.0) -> int:
        """Calcula o prêmio de vitória."""
        return int(initial_bet * multiplier)

    @staticmethod
    def get_rock_paper_scissors_emoji(choice: int) -> Tuple[str, str]:
        """
        Retorna o emoji e nome da escolha.
        
        Args:
            choice: 0=Pedra, 1=Papel, 2=Tesoura
            
        Returns:
            Tupla (emoji, nome)
        """
        choices = [
            ("🪨", "Pedra"),
            ("📄", "Papel"),
            ("✂️", "Tesoura"),
        ]
        return choices[choice] if 0 <= choice < len(choices) else ("❓", "Desconhecido")

    @staticmethod
    def get_blackjack_card_value(card: str) -> Tuple[int, str]:
        """
        Retorna o valor e emoji de uma carta.
        
        Args:
            card: Código da carta (A,2-10,J,Q,K + suit)
            
        Returns:
            Tupla (valor, emoji)
        """
        suits = {"♠": "♠️", "♥": "♥️", "♦": "♦️", "♣": "♣️"}
        
        if card[0] in ["J", "Q", "K"]:
            return (10, card)
        elif card[0] == "A":
            return (11, card)  # Pode ser 1 ou 11
        else:
            return (int(card[:-1]), card)

    @staticmethod
    def generate_blackjack_card() -> str:
        """Gera uma carta aleatória para Blackjack."""
        ranks = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
        suits = ["♠", "♥", "♦", "♣"]
        return f"{random.choice(ranks)}{random.choice(suits)}"
