"""
ffmpeg_setup.py — Garante que o ffmpeg está disponível mesmo em ambientes sem ele instalado.

Estratégia (em ordem de tentativa):
1. Já existe no PATH → usa direto
2. Já foi baixado antes em ./bin/ffmpeg → usa direto  
3. Baixa o binário estático do ffmpeg (linux-amd64) e salva em ./bin/ffmpeg

Funciona no DisCloud, Railway, Render, VPS sem root, etc.
"""

import os
import stat
import shutil
import asyncio
import logging
import aiohttp
from pathlib import Path

logger = logging.getLogger(__name__)

# Binário estático do ffmpeg para Linux x86_64 — hospedado no GitHub Releases
# (john-vansickle mantém builds estáticas oficiais há +10 anos)
_FFMPEG_URL = (
    "https://github.com/yt-dlp/FFmpeg-Builds/releases/download/"
    "latest/ffmpeg-master-latest-linux64-gpl.tar.xz"
)

# Fallback menor e mais rápido (só o binário, sem ffprobe/ffplay)
_FFMPEG_URL_FALLBACK = (
    "https://github.com/eugeneware/ffmpeg-static/releases/download/"
    "b6.0/ffmpeg-linux-x64"
)

# Onde salvar localmente
_BIN_DIR = Path(__file__).parent.parent / "bin"
_FFMPEG_PATH = _BIN_DIR / "ffmpeg"


def get_ffmpeg_path() -> str:
    """
    Retorna o caminho do ffmpeg disponível.
    Prioridade: PATH do sistema > ./bin/ffmpeg já baixado.
    Retorna 'ffmpeg' como fallback (deixa o SO tentar).
    """
    # 1) No PATH do sistema?
    system_ffmpeg = shutil.which("ffmpeg")
    if system_ffmpeg:
        return system_ffmpeg

    # 2) Já baixamos antes?
    if _FFMPEG_PATH.exists() and os.access(_FFMPEG_PATH, os.X_OK):
        return str(_FFMPEG_PATH)

    # 3) Não encontrado — retorna string pra tentar mesmo assim
    return "ffmpeg"


async def ensure_ffmpeg() -> str:
    """
    Garante que o ffmpeg está disponível, baixando se necessário.
    Retorna o caminho do executável.
    Deve ser chamado uma vez no startup (ex: main.py setup_hook).
    """
    # Já disponível?
    system_ffmpeg = shutil.which("ffmpeg")
    if system_ffmpeg:
        logger.info(f"✓ ffmpeg encontrado no sistema: {system_ffmpeg}")
        return system_ffmpeg

    if _FFMPEG_PATH.exists() and os.access(_FFMPEG_PATH, os.X_OK):
        logger.info(f"✓ ffmpeg local encontrado: {_FFMPEG_PATH}")
        return str(_FFMPEG_PATH)

    # Precisa baixar
    logger.info("⬇ ffmpeg não encontrado — baixando binário estático...")
    _BIN_DIR.mkdir(parents=True, exist_ok=True)

    try:
        path = await _download_ffmpeg_direct()
        if path:
            logger.info(f"✓ ffmpeg baixado com sucesso: {path}")
            return path
    except Exception as e:
        logger.error(f"Erro ao baixar ffmpeg (método direto): {e}")

    logger.error("✗ Não foi possível obter o ffmpeg. Voz pode não funcionar.")
    return "ffmpeg"


async def _download_ffmpeg_direct() -> str | None:
    """
    Baixa o binário direto (um arquivo só, sem tar).
    Método mais simples e rápido para ambientes de hospedagem.
    """
    tmp_path = _BIN_DIR / "ffmpeg.tmp"
    try:
        async with aiohttp.ClientSession() as session:
            logger.info(f"Baixando de: {_FFMPEG_URL_FALLBACK}")
            async with session.get(
                _FFMPEG_URL_FALLBACK,
                timeout=aiohttp.ClientTimeout(total=120),
                allow_redirects=True,
            ) as resp:
                if resp.status != 200:
                    logger.error(f"HTTP {resp.status} ao baixar ffmpeg")
                    return None

                total = int(resp.headers.get("Content-Length", 0))
                downloaded = 0
                with open(tmp_path, "wb") as f:
                    async for chunk in resp.content.iter_chunked(65536):
                        f.write(chunk)
                        downloaded += len(chunk)
                        if total:
                            pct = downloaded * 100 // total
                            if pct % 20 == 0:
                                logger.info(f"  ffmpeg download: {pct}% ({downloaded}/{total} bytes)")

        # Tornar executável
        tmp_path.rename(_FFMPEG_PATH)
        _FFMPEG_PATH.chmod(_FFMPEG_PATH.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)

        # Teste rápido
        proc = await asyncio.create_subprocess_exec(
            str(_FFMPEG_PATH), "-version",
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.wait(), timeout=10)
        if proc.returncode == 0:
            return str(_FFMPEG_PATH)
        else:
            logger.error("ffmpeg baixado mas falhou no teste de versão")
            return None

    except Exception as e:
        logger.error(f"_download_ffmpeg_direct falhou: {e}")
        if tmp_path.exists():
            tmp_path.unlink(missing_ok=True)
        return None
