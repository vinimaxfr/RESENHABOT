"""
Fila de processamento para áudio com lock para evitar processamento simultâneo.
"""

import asyncio
from typing import Optional, Callable, Any
from utils.logger import setup_logger

logger = setup_logger(__name__)


class VoiceQueue:
    """Fila de processamento de áudio com controle de simultaneidade."""

    def __init__(self):
        """Inicializa a fila."""
        self.queue: asyncio.Queue = asyncio.Queue()
        self.processing = False
        self.lock = asyncio.Lock()

    async def add_task(
        self,
        task_id: str,
        coroutine: Callable,
        *args: Any,
        **kwargs: Any
    ) -> None:
        """
        Adiciona uma tarefa à fila.

        Args:
            task_id: ID único da tarefa
            coroutine: Função corrotina a executar
            args: Argumentos posicionais
            kwargs: Argumentos nomeados
        """
        await self.queue.put({
            "id": task_id,
            "coroutine": coroutine,
            "args": args,
            "kwargs": kwargs,
        })

    async def process_queue(self) -> None:
        """Processa tarefas da fila sequencialmente."""
        while True:
            try:
                task = await self.queue.get()

                async with self.lock:
                    try:
                        logger.info(f"Processando tarefa: {task['id']}")
                        await task["coroutine"](*task["args"], **task["kwargs"])
                        logger.info(f"✓ Tarefa concluída: {task['id']}")
                    except Exception as e:
                        logger.error(f"✗ Erro na tarefa {task['id']}: {e}")
                    finally:
                        self.queue.task_done()

            except asyncio.CancelledError:
                logger.info("Fila de voz encerrada")
                break
            except Exception as e:
                logger.error(f"Erro no processamento da fila: {e}")

    async def is_processing(self) -> bool:
        """Verifica se há processamento em andamento."""
        return self.lock.locked()

    async def clear(self) -> None:
        """Limpa a fila."""
        while not self.queue.empty():
            try:
                self.queue.get_nowait()
            except asyncio.QueueEmpty:
                break
