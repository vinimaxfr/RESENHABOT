"""
DEPLOYMENT GUIDE - Resenha Bot

PASSO A PASSO PARA PRODUÇÃO:

1. PREPARAÇÃO (5 min)
====================

Clonar/preparar servidor:
  mkdir MaxBot
  cd MaxBot
  git clone [seu_repo]
  cd MaxBot

2. INSTALAR DEPENDÊNCIAS (3 min)
===============================

pip install -r requirements.txt

Se FFmpeg não estiver:
  Windows: https://www.gyan.dev/ffmpeg/builds/
  Linux: sudo apt-get install ffmpeg
  macOS: brew install ffmpeg

3. CONFIGURAR ENVIRONMENT (2 min)
================================

Criar .env na raiz:
  
DISCORD_TOKEN=seu_token_aqui
OPENAI_API_KEY=sk-seu_key_aqui
DATABASE_PATH=./data/resenhabot.db

4. INICIAR BOT (1 min)
====================

python main.py

Verifique:
  ✓ "✅ Bot inicializado com sucesso!"
  ✓ "🟢 [BotName] está online!"
  ✓ Comandos sincronizados

5. DASHBOARD (Opcional)
======================

Em outro terminal:

pip install flask
python run_dashboard.py

Acesse: http://localhost:5000

6. MONITORAMENTO
===============

Verificar logs:
  tail -f logs/resenhabot.log

Backups automáticos:
  ls -la backups/

7. ESCALABILIDADE
================

Para produção 24/7:

Option A: Linux screen
  screen -S resenhabot
  python main.py
  Ctrl+A D

Option B: systemd service
  [criar arquivo .service]

Option C: Docker
  [criar Dockerfile]

Option D: Cloud (Heroku, Railway, etc)
  [setup variáveis de ambiente]

STATUS: ✅ READY TO DEPLOY

Bot está pronto para ser usado em produção!
"""
