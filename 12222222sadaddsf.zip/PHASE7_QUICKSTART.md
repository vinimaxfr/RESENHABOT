"""
QUICK START - PHASE 7 VOICE

Instruções rápidas para começar.

1. INSTALAR DEPENDÊNCIAS (5 min)
==================================

Windows PowerShell:
  cd c:\Users\vinimaxfr\Documents\MaxBot
  pip install -r requirements.txt

Aguarde conclusão (pydub + faster-whisper podem demorar)

2. CONFIGURAR FFmpeg (10 min)
==============================

Windows:
  1. Download: https://www.gyan.dev/ffmpeg/builds/
  2. Escolha: ffmpeg-master-latest-win64-gpl.zip
  3. Extraia em: C:\\Program Files\\ffmpeg
  4. Abra Variáveis de Ambiente (Windows+X > Settings)
  5. System Variables > Path > Edit > New
  6. Adicione: C:\\Program Files\\ffmpeg\\bin
  7. OK > OK > Restart PowerShell

Verificar:
  ffmpeg -version
  (deve mostrar versão)

Linux:
  sudo apt-get update
  sudo apt-get install ffmpeg libopus-dev libsodium-dev

macOS:
  brew install ffmpeg opus libsodium

3. VERIFICAR .env (1 min)
==========================

c:\Users\vinimaxfr\Documents\MaxBot\.env

Certifique-se de ter:
  DISCORD_TOKEN=seu_token_aqui
  OPENAI_API_KEY=sk-seu_api_key_aqui

4. INICIAR BOT (1 min)
======================

PowerShell:
  python main.py

Aguarde:
  ✅ Bot inicializado com sucesso!

5. TESTAR VVOZ (5 min)
======================

Discord:
  1. Entre em um canal de voz
  2. Digite: /entrar
  3. Bot entra no canal
  4. Fale: "Oi bot, tudo bem?"
  5. Bot responde em voz em ~5 segundos
  6. Digite: /sair
  7. Bot sai

Se funcionou → Fase 7 OK ✅

PRÓXIMAS FASES:
===============

FASE 8: Moderation (kicks, bans, mutes)
FASE 9: Leaderboards avançadas
FASE 10: Dashboard web

PRECISA DE AJUDA?
=================

❌ FFmpeg não encontrado?
  → Reinstale e adicione ao PATH
  → Ou leia: cogs/voice/FFMPEG_SETUP.md

❌ Bot não responde?
  → Verifique logs: logs/resenhabot.log
  → Ou leia: cogs/voice/VOICE_TESTING.md

❌ Erro de API?
  → Verifique OPENAI_API_KEY em .env
  → Verifique sua quota no dashboard OpenAI

❌ Primeira execução demora?
  → Faster Whisper baixa modelo (~100MB)
  → Aguarde pacientemente

DOCUMENTAÇÃO COMPLETA:
======================

cogs/voice/VOICE_GUIDE.md → Guia completo
cogs/voice/FFMPEG_SETUP.md → Setup FFmpeg
cogs/voice/VOICE_TESTING.md → Testes detalhados
cogs/voice/PHASE7_SUMMARY.md → Resumo técnico
cogs/voice/FILES_STRUCTURE.md → Estrutura de arquivos

Pronto para começar? ✨

Dúvidas? Leia a documentação ou peça ajuda!
"""
