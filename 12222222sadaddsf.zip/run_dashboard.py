"""
Script para iniciar o dashboard web.
Executar em terminal separado: python run_dashboard.py
"""

import asyncio
import sys
from pathlib import Path
from config.settings import Settings
from database.manager import DatabaseManager
from dashboard.dashboard import ResenhaDashboard
from dashboard.templates_builder import create_templates
from utils.logger import setup_logger

logger = setup_logger(__name__)


async def main():
    """Inicia o dashboard."""
    try:
        # Criar templates
        create_templates()
        logger.info("✓ Templates criados")

        # Conectar BD
        db = DatabaseManager(Settings.DATABASE_PATH)
        await db.connect()
        logger.info("✓ Banco de dados conectado")

        # Criar dashboard
        dashboard = ResenhaDashboard(db)
        logger.info("✓ Dashboard criado")

        # Rodar
        print("\n" + "="*50)
        print("🌐 Resenha Bot Dashboard")
        print("="*50)
        print("Acesse: http://127.0.0.1:5000")
        print("="*50 + "\n")

        dashboard.run(host="127.0.0.1", port=5000, debug=False)

    except Exception as e:
        logger.error(f"❌ Erro ao iniciar dashboard: {e}")
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n\nDashboard encerrado")
        sys.exit(0)
